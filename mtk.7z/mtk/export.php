    <?php
// export.php
session_start();
require_once('config/connect.php');

// ตรวจสอบสิทธิ์
if (!isset($_SESSION['logged_in'])) {
    die("Access Denied");
}

$mode = isset($_GET['mode']) ? $_GET['mode'] : '';
$filename = "hotspot_users_" . date('Ymd_His') . ".csv";
$data_rows = [];

// --- โหมด 1: Export เฉพาะที่เพิ่งสร้าง (Batch) ---
if ($mode == 'batch') {
    if (isset($_SESSION['print_data']) && count($_SESSION['print_data']) > 0) {
        $data_rows = $_SESSION['print_data'];
    } else {
        die("ไม่มีข้อมูลคูปองล่าสุดใน Session");
    }
} 

// --- โหมด 2: Export ทั้งหมดจาก MikroTik (All) ---
elseif ($mode == 'all') {
    if ($API->connect($_SESSION['router_ip'], $_SESSION['router_user'], $_SESSION['router_pass'])) {
        $mikrotik_users = $API->comm("/ip/hotspot/user/print");
        $API->disconnect();

        // จัด Format ข้อมูลให้เหมือนกับ Session
        foreach ($mikrotik_users as $u) {
            // ข้าม default user
            if ($u['name'] == 'default') continue;

            $data_rows[] = [
                'user'    => $u['name'],
                'pass'    => isset($u['password']) ? $u['password'] : '',
                'profile' => isset($u['profile']) ? $u['profile'] : '-',
                'price'   => isset($u['comment']) ? $u['comment'] : '-' // พยายามดึงราคาจาก comment
            ];
        }
    } else {
        die("เชื่อมต่อ Router ไม่ได้");
    }
} else {
    die("Invalid Mode");
}

// --- เริ่มกระบวนการส่งไฟล์ CSV ---

// 1. ตั้งค่า Header ให้ Browser รู้ว่าเป็นไฟล์ดาวน์โหลด
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');

// 2. เปิด Output Stream
$output = fopen('php://output', 'w');

// 3. ใส่ BOM เพื่อให้ Excel อ่านภาษาไทยออก (ถ้ามี)
fputs($output, "\xEF\xBB\xBF");

// 4. เขียนหัวตาราง (Column Headers)
fputcsv($output, array('Username', 'Password', 'Profile', 'Price'));

// 5. วนลูปเขียนข้อมูลทีละแถว
foreach ($data_rows as $row) {
    // เช็คค่าว่างก่อนเขียน
    $u = isset($row['user']) ? $row['user'] : '';
    $p = isset($row['pass']) ? $row['pass'] : '';
    $pf = isset($row['profile']) ? $row['profile'] : '';
    $pr = isset($row['price']) ? $row['price'] : '';

    fputcsv($output, array($u, $p, $pf, $pr));
}

fclose($output);
exit;
?>