<?php
// config/connect.php
require_once __DIR__ . '/../core/routeros_api.class.php';

$API = new RouterosAPI();
$API->debug = false;

// ตรวจสอบว่ามีการ Login เข้ามาหรือยัง?
if (isset($_SESSION['router_ip']) && isset($_SESSION['router_user']) && isset($_SESSION['router_pass'])) {
    
    $ip_router   = $_SESSION['router_ip'];
    $user_router = $_SESSION['router_user'];
    $pass_router = $_SESSION['router_pass'];
    
    // พยายามเชื่อมต่อ
    if (!$API->connect($ip_router, $user_router, $pass_router)) {
        // ถ้า Session ค้างแต่ต่อ Router ไม่ได้ (เช่นเปลี่ยนรหัส) ให้เคลียร์ทิ้ง
        session_destroy();
    }
}
?>