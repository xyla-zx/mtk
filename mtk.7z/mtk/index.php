<?php
// index.php (อัปเดตใหม่)
session_start();
ob_start();

// --- 1. เช็คสถานะ Login ---
// ถ้าไม่มี Session logged_in หรือ เป็นเท็จ
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    // ให้เรียกหน้า Login มาแสดงแทน
    require_once 'view/login.php';
    exit; // จบการทำงาน ไม่รันส่วนอื่นต่อ
}

// --- 2. จัดการ Logout ---
if (isset($_GET['action']) && $_GET['action'] == 'logout') {
    session_destroy();
    header("Location: index.php");
    exit;
}

// --- 3. ส่วนทำงานปกติ (ถ้า Login ผ่านแล้ว) ---
require_once 'config/connect.php';

$page = isset($_GET['page']) ? $_GET['page'] : 'dashboard';
$view_path = "view/" . $page . ".php";

if (file_exists('view/header.php')) { include 'view/header.php'; }

if (file_exists($view_path)) {
    include $view_path;
} else {
    echo "<div class='card' style='text-align:center; padding:50px;'>... 404 Error ...</div>";
}

if (file_exists('view/footer.php')) { include 'view/footer.php'; }
// Flush output buffer if started
if (ob_get_level()) ob_end_flush();
?>