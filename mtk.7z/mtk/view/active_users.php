<?php
// view/active_users.php

$active_users = [];
$hosts = [];

if ($API->connect($ip_router, $user_router, $pass_router)) {
    // ดึงข้อมูล Active
    $active_users = $API->comm("/ip/hotspot/active/print");
    // ดึงข้อมูล Host (คนที่เกาะ WiFi แต่ยังไม่ Login ก็มี)
    $hosts = $API->comm("/ip/hotspot/host/print");
    
    $API->disconnect();
}
?>

<div class="card">
    <div class="card-header">
        <h3><i class="fas fa-users"></i> ผู้ใช้งานที่ Login อยู่ (Active Users)</h3>
    </div>
    
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>User</th>
                <th>IP Address</th>
                <th>Uptime</th>
                <th>Data (DL/UL)</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (count($active_users) > 0) {
                $i = 1;
                foreach ($active_users as $user) {
                    $b_in = isset($user['bytes-in']) ? round($user['bytes-in']/1048576, 2) : 0;
                    $b_out = isset($user['bytes-out']) ? round($user['bytes-out']/1048576, 2) : 0;
                    echo "<tr>";
                    echo "<td>{$i}</td>";
                    echo "<td><b>{$user['user']}</b></td>";
                    echo "<td>{$user['address']}</td>";
                    echo "<td>{$user['uptime']}</td>";
                    echo "<td>📉 {$b_out} MB / 📈 {$b_in} MB</td>";
                    echo "<td><button class='btn btn-danger' style='padding:5px 10px; font-size:12px;'>Kick</button></td>";
                    echo "</tr>";
                    $i++;
                }
            } else {
                echo "<tr><td colspan='6' style='text-align:center; color:red;'>-- ไม่มีผู้ใช้งาน Online --</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<div class="card" style="margin-top:20px;">
    <div class="card-header" style="border-bottom:none; color:#888;">
        <small><i class="fas fa-mobile-alt"></i> อุปกรณ์ที่เชื่อมต่อ WiFi (Hosts)</small>
    </div>
    <table>
        <thead>
            <tr style="background:#eee; color:#555;">
                <th>Mac Address</th>
                <th>IP Address</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (count($hosts) > 0) {
                foreach ($hosts as $h) {
                    $status = ($h['authorized'] == 'true') ? "<span style='color:green'>Login แล้ว</span>" : "<span style='color:orange'>ยังไม่ Login</span>";
                    echo "<tr>";
                    echo "<td>".(isset($h['mac-address'])?$h['mac-address']:'-')."</td>";
                    echo "<td>".(isset($h['address'])?$h['address']:'-')."</td>";
                    echo "<td>{$status}</td>";
                    echo "</tr>";
                }
            }
            ?>
        </tbody>
    </table>
</div>