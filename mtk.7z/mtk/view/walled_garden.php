<?php
// view/walled_garden.php

// --- Helper Functions ---

function getPresetDomains($app) {
    switch ($app) {
        case 'line': return ['*.line.me', '*.naver.jp', '*.line-cdn.net'];
        case 'facebook': return ['*.facebook.com', '*.fbcdn.net', '*.messenger.com'];
        case 'kplus': return ['*.kasikornbank.com', 'mobile.kasikornbank.com'];
        case 'scb': return ['*.scb.co.th', 'fasteasy.scb.co.th'];
        case 'truemoney': return ['*.truemoney.com', 'mobile-api-gateway.truemoney.com'];
        default: return [];
    }
}

// ฟังก์ชัน Redirect ที่ปลอดภัย (รองรับทั้ง Header และ JS)
function safe_redirect($url) {
    if (!headers_sent()) {
        header('Location: ' . $url);
        exit;
    }
    echo "<script>window.location.href='" . htmlspecialchars($url, ENT_QUOTES) . "';</script>";
    echo "<noscript><meta http-equiv=\"refresh\" content=\"0;url=" . htmlspecialchars($url, ENT_QUOTES) . "\"></noscript>";
    exit;
}

// --- 1. จัดการคำสั่งเพิ่ม (Add) ---
if (isset($_POST['btn_add'])) {
    if ($API->connect($ip_router, $user_router, $pass_router)) {
        
        // 1.1 เพิ่มแบบ Preset (เลือกแอป)
        if (isset($_POST['preset_app'])) {
            // ถ้ามีการเลือกโดเมนย่อยมาจาก Modal
            if (isset($_POST['preset_domains']) && is_array($_POST['preset_domains']) && count($_POST['preset_domains']) > 0) {
                $domains = $_POST['preset_domains'];
            } else {
                $domains = getPresetDomains($_POST['preset_app']);
            }
            $comment = "Allow " . strtoupper($_POST['preset_app']);
            
            foreach ($domains as $dst) {
                // เช็คซ้ำก่อนบันทึก
                $check = $API->comm("/ip/hotspot/walled-garden/print", array("?dst-host" => $dst));
                if (count($check) == 0) {
                    $API->comm("/ip/hotspot/walled-garden/add", array(
                        "dst-host" => $dst,
                        "action"   => "allow",
                        "comment"  => $comment
                    ));
                }
            }
            $_SESSION['swal_title'] = 'เพิ่ม Preset สำเร็จ';
            $_SESSION['swal_text'] = 'อนุญาตแอป ' . strtoupper($_POST['preset_app']) . ' เรียบร้อยแล้ว';
        } 
        // 1.2 เพิ่มเอง (Manual)
        else {
            $dst = $_POST['dst_host'];
            $API->comm("/ip/hotspot/walled-garden/add", array(
                "dst-host" => $dst,
                "action"   => "allow",
                "comment"  => $_POST['comment']
            ));
            $_SESSION['swal_title'] = 'เพิ่มสำเร็จ';
            $_SESSION['swal_text'] = 'อนุญาตเว็บ ' . $dst . ' เรียบร้อย';
        }
        
        $API->disconnect();
        $_SESSION['swal_icon'] = 'success';
        safe_redirect('index.php?page=walled_garden');
    }
}

// --- 2. จัดการคำสั่งลบทีละรายการ (Delete Single) ---
if (isset($_POST['btn_delete'])) {
    $id = $_POST['del_id'];
    if ($API->connect($ip_router, $user_router, $pass_router)) {
        $API->comm("/ip/hotspot/walled-garden/remove", array(".id" => $id));
        $API->disconnect();
        $_SESSION['swal_icon'] = 'success';
        $_SESSION['swal_title'] = 'ลบสำเร็จ';
        safe_redirect('index.php?page=walled_garden');
    }
}

// --- 3. จัดการคำสั่งลบหลายรายการ (Bulk Delete) ---
// แก้ไข: ใช้ Form Submit ธรรมดา ไม่ใช้ AJAX แล้ว
if (isset($_POST['btn_delete_multiple'])) {
    $ids = isset($_POST['del_ids']) ? $_POST['del_ids'] : [];
    
    // แปลงเป็น Array ถ้ามาตัวเดียว
    if(!is_array($ids)) $ids = [$ids];
    
    $removed = 0;
    if (count($ids) > 0 && $API->connect($ip_router, $user_router, $pass_router)) {
        foreach($ids as $id) {
            $id = trim($id);
            if($id === '') continue;
            // สั่งลบทีละ ID
            $API->comm("/ip/hotspot/walled-garden/remove", array('.id' => $id));
            $removed++;
        }
        $API->disconnect();
    }

    // ส่ง Session Alert แล้ว Redirect
    $_SESSION['swal_icon'] = 'success';
    $_SESSION['swal_title'] = 'ลบสำเร็จ';
    $_SESSION['swal_text'] = 'ลบออกทั้งหมด ' . intval($removed) . ' รายการ';
    safe_redirect('index.php?page=walled_garden');
}

// --- 4. ดึงข้อมูลมาแสดงผล ---
$garden_list = [];
if ($API->connect($ip_router, $user_router, $pass_router)) {
    $garden_list = $API->comm("/ip/hotspot/walled-garden/print");
    $API->disconnect();
}
?>

<style>
    /* CSS เฉพาะหน้า Walled Garden */
    .walled-row { display:flex; flex-wrap:wrap; gap:20px; align-items:stretch; }
    .walled-row > [class*="col-"] { display:flex; flex-direction:column; }
    .walled-row .card { width:100%; box-sizing:border-box; }
    .preset-grid { display:grid; grid-template-columns:repeat(2,1fr); gap:10px; }
    .preset-grid .btn { white-space:nowrap; display:inline-flex; align-items:center; gap:8px; }
    .table-actions { display:flex; gap:10px; align-items:center; }
    .table-actions .search-input { min-width:220px; }
    
    /* ธีมสีปุ่ม Preset */
    :root { --wg-scb: #4e2a84; --wg-kplus: #00a950; --wg-tm: #ff9f43; }
    .btn-scb { background: var(--wg-scb); color: #fff; border: none; }
    .btn-kplus { background: var(--wg-kplus); color: #fff; border: none; }
    .btn-tm { background: var(--wg-tm); color: #fff; border: none; }
    
    @media (max-width:768px){ .walled-row{gap:12px;} .preset-grid{grid-template-columns:1fr 1fr;} }

    /* Modal Styling */
    .wg-modal { position:fixed; inset:0; z-index:1500; display:flex; align-items:center; justify-content:center; }
    .wg-modal-backdrop{ position:absolute; inset:0; background:rgba(0,0,0,0.4); }
    .wg-modal-dialog{ position:relative; background:#fff; border-radius:8px; width:640px; max-width:95%; box-shadow:0 10px 30px rgba(0,0,0,0.2); overflow:hidden; }
    .wg-modal-header{ padding:12px 16px; border-bottom:1px solid #f1f1f1; display:flex; justify-content:space-between; align-items:center; }
    .wg-modal-body{ padding:16px; max-height:320px; overflow:auto; display:grid; grid-template-columns:1fr 1fr; gap:8px; }
    .wg-modal-footer{ padding:12px 16px; border-top:1px solid #f1f1f1; }
    .wg-domain-item{ background:#f8f9fa; padding:8px 10px; border-radius:6px; display:flex; align-items:center; gap:8px; }
</style>

<div class="row walled-row">
    <div class="col-md-4">
        
        <div class="card mb-3 border-primary">
            <div class="card-header bg-primary text-white">
                <i class="fas fa-bolt"></i> ทางด่วน (Quick Presets)
            </div>
            <div class="card-body">
                <p class="small text-muted">กดปุ่มเพื่ออนุญาตแอปเหล่านี้ทันที:</p>
                <div class="preset-grid">
                    <button type="button" data-app="line" class="btn btn-success btn-sm w-100 preset-launch"><i class="fab fa-line"></i> Line</button>
                    <button type="button" data-app="facebook" class="btn btn-primary btn-sm w-100 preset-launch"><i class="fab fa-facebook"></i> Facebook</button>
                    <button type="button" data-app="kplus" class="btn btn-sm w-100 preset-launch btn-kplus"><i class="fas fa-university"></i> K-Plus</button>
                    <button type="button" data-app="scb" class="btn btn-sm w-100 preset-launch btn-scb"><i class="fas fa-university"></i> SCB</button>
                    <button type="button" data-app="truemoney" class="btn btn-warning btn-sm w-100 preset-launch btn-tm"><i class="fas fa-wallet"></i> TrueMoney</button>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <i class="fas fa-plus"></i> เพิ่มเอง (Manual)
            </div>
            <div class="card-body">
                <form method="post">
                    <input type="hidden" name="btn_add" value="1">
                    <div class="form-group mb-2">
                        <label>Domain (ใส่ * นำหน้า):</label>
                        <input type="text" name="dst_host" class="form-control" placeholder="*.google.com" required>
                    </div>
                    <div class="form-group mb-3">
                        <label>Comment:</label>
                        <input type="text" name="comment" class="form-control" placeholder="เช่น Allow Google">
                    </div>
                    <button type="submit" class="btn btn-secondary w-100">บันทึก</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-8">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <div>รายการที่อนุญาต (<?php echo count($garden_list); ?>)</div>
                <div class="table-actions">
                    <input type="search" id="filterDomain" class="form-control form-control-sm search-input" placeholder="ค้นหา domain หรือ comment">
                    
                    <button id="exportJson" class="btn btn-outline-secondary btn-sm" title="ส่งออกเป็นไฟล์ JSON"><i class="fas fa-file-export"></i> Export</button>
                    
                    <button id="deleteMultiple" class="btn btn-danger btn-sm" disabled><i class="fas fa-trash"></i> ลบที่เลือก</button>
                    
                    <form id="delMultipleForm" method="post" style="display:none;">
                        <input type="hidden" name="btn_delete_multiple" value="1">
                    </form>
                </div>
            </div>
            <div class="table-responsive">
                <table id="wg-table" class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th style="width:36px;"><input type="checkbox" id="selectAllWG"></th>
                            <th>Domain (Dst. Host)</th>
                            <th>Action</th>
                            <th>Comment</th>
                            <th width="50">ลบ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($garden_list as $g): ?>
                        <tr>
                            <td><input type="checkbox" class="wg-select" value="<?php echo $g['.id']; ?>"></td>
                            <td style="color:#2980b9; font-weight:bold;"><?php echo isset($g['dst-host']) ? $g['dst-host'] : '*'; ?></td>
                            <td><span class="badge badge-success">Allow</span></td>
                            <td><small class="text-muted"><?php echo isset($g['comment']) ? $g['comment'] : ''; ?></small></td>
                            <td>
                                <form method="post" onsubmit="return confirm('ลบรายการนี้?');">
                                    <input type="hidden" name="btn_delete" value="1">
                                    <input type="hidden" name="del_id" value="<?php echo $g['.id']; ?>">
                                    <button class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(count($garden_list)==0) echo "<tr><td colspan='5' class='text-center'>ว่างเปล่า</td></tr>"; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div id="presetModal" class="wg-modal" aria-hidden="true" style="display:none;">
    <div class="wg-modal-backdrop"></div>
    <div class="wg-modal-dialog">
        <div class="wg-modal-header">
            <h5 id="modalTitle">Preset</h5>
            <button type="button" id="modalClose" class="btn btn-sm btn-light">Close</button>
        </div>
        <form id="presetForm" method="post">
            <input type="hidden" name="btn_add" value="1">
            <input type="hidden" name="preset_app" id="modalPresetApp" value="">
            <div class="wg-modal-body" id="presetBody">
                </div>
            <div class="wg-modal-footer" style="display:flex; gap:8px; justify-content:flex-end;">
                <button type="button" id="presetSelectAll" class="btn btn-sm btn-outline-secondary">Select all</button>
                <button type="submit" class="btn btn-primary btn-sm">Add selected</button>
            </div>
        </form>
    </div>
</div>

<script>
    // --- JavaScript Logic ---
    (function(){
        // 1. Logic Checkbox Select All
        var selectAll = document.getElementById('selectAllWG');
        var deleteBtn = document.getElementById('deleteMultiple');

        function updateDeleteState(){
            var any = document.querySelectorAll('.wg-select:checked').length > 0;
            if(deleteBtn) deleteBtn.disabled = !any;
        }

        if(selectAll){
            selectAll.addEventListener('change', function(){
                var checked = this.checked;
                document.querySelectorAll('.wg-select').forEach(function(cb){ cb.checked = checked; });
                updateDeleteState();
            });
        }

        document.addEventListener('change', function(e){
            if(e.target && e.target.classList && e.target.classList.contains('wg-select')){
                updateDeleteState();
                if(!e.target.checked && selectAll) selectAll.checked = false;
            }
        });

        // 2. Logic Bulk Delete (แก้ไขใหม่: ใช้ Form Submit)
        if(deleteBtn){
            deleteBtn.addEventListener('click', function(){
                // หา ID ที่ถูกติ๊ก
                var checked = Array.from(document.querySelectorAll('.wg-select:checked')).map(function(cb){return cb.value;});
                if(checked.length === 0) return;
                
                // ใช้ Swal ถามยืนยัน
                Swal.fire({
                    title: 'ยืนยันการลบ?',
                    text: "ต้องการลบ " + checked.length + " รายการที่เลือกหรือไม่?",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    confirmButtonText: 'ลบเลย!',
                    cancelButtonText: 'ยกเลิก'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // เตรียมฟอร์มสำหรับส่งค่า
                        var form = document.getElementById('delMultipleForm');
                        // เคลียร์ input เก่า (ถ้ามี)
                        form.innerHTML = '<input type="hidden" name="btn_delete_multiple" value="1">';
                        
                        // สร้าง input hidden ตามจำนวน ID ที่เลือก
                        checked.forEach(function(id){
                            var input = document.createElement('input');
                            input.type = 'hidden';
                            input.name = 'del_ids[]';
                            input.value = id;
                            form.appendChild(input);
                        });

                        // ส่งฟอร์ม (หน้าเว็บจะรีเฟรชเอง)
                        form.submit();
                    }
                });
            });
        }

        // 3. Logic Preset Modal
        var modal = document.getElementById('presetModal');
        var modalTitle = document.getElementById('modalTitle');
        var modalPresetApp = document.getElementById('modalPresetApp');
        var presetBody = document.getElementById('presetBody');
        var modalClose = document.getElementById('modalClose');
        var presetSelectAll = document.getElementById('presetSelectAll');

        var presetMap = {
            'line': ['*.line.me','*.naver.jp','*.line-cdn.net'],
            'facebook': ['*.facebook.com','*.fbcdn.net','*.messenger.com'],
            'kplus': ['*.kasikornbank.com','mobile.kasikornbank.com'],
            'scb': ['*.scb.co.th','fasteasy.scb.co.th'],
            'truemoney': ['*.truemoney.com','mobile-api-gateway.truemoney.com']
        };

        function openPreset(app){
            if(!modal) return;
            modal.style.display='flex'; modal.setAttribute('aria-hidden','false');
            modalTitle.innerText = 'Preset: ' + app.toUpperCase();
            modalPresetApp.value = app;
            presetBody.innerHTML = '';
            var domains = presetMap[app] || [];
            domains.forEach(function(d){
                var el = document.createElement('label'); el.className='wg-domain-item';
                var cb = document.createElement('input'); cb.type='checkbox'; cb.name='preset_domains[]'; cb.value=d; cb.checked=true;
                var span = document.createElement('span'); span.innerText = d;
                el.appendChild(cb); el.appendChild(span);
                presetBody.appendChild(el);
            });
        }

        document.querySelectorAll('.preset-launch').forEach(function(b){
            b.addEventListener('click', function(){ openPreset(this.getAttribute('data-app')); });
        });

        if(modalClose) modalClose.addEventListener('click', function(){ modal.style.display='none'; modal.setAttribute('aria-hidden','true'); });
        
        if(presetSelectAll) presetSelectAll.addEventListener('click', function(){
            var checks = presetBody.querySelectorAll('input[type="checkbox"]');
            var anyUnchecked = Array.from(checks).some(function(c){ return !c.checked; });
            checks.forEach(function(c){ c.checked = anyUnchecked; });
        });

        // 4. Logic Search Filter
        var input = document.getElementById('filterDomain');
        var table = document.getElementById('wg-table');
        if(input && table){
            input.addEventListener('input', function(){
                var q = this.value.trim().toLowerCase();
                Array.from(table.tBodies[0].rows).forEach(function(row){
                    var text = row.innerText.toLowerCase();
                    row.style.display = text.indexOf(q) !== -1 ? '' : 'none';
                });
            });
        }

        // 5. Logic Export JSON
        var exportBtn = document.getElementById('exportJson');
        if(exportBtn && table){
            exportBtn.addEventListener('click', function(){
                var data = [];
                Array.from(table.tBodies[0].rows).forEach(function(row){
                    if(row.style.display === 'none') return; // ข้ามแถวที่ถูกกรองทิ้ง
                    var cols = row.querySelectorAll('td');
                    if(cols.length < 4) return;
                    data.push({
                        dst: cols[1].innerText.trim(),
                        action: cols[2].innerText.trim(),
                        comment: cols[3].innerText.trim()
                    });
                });
                var blob = new Blob([JSON.stringify(data, null, 2)], {type: 'application/json'});
                var url = URL.createObjectURL(blob);
                var a = document.createElement('a'); a.href = url; a.download = 'walled_garden_export.json'; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
            });
        }
    })();
</script>