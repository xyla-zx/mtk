<?php
// view/login.php

// 1. โหลดการตั้งค่า
$settings = ['login_title'=>'MikroTik Manager', 'login_subtitle'=>'System Login', 'login_bg'=>'', 'login_logo'=>''];
if (file_exists('config/settings.json')) {
    $temp = json_decode(file_get_contents('config/settings.json'), true);
    if($temp) $settings = array_merge($settings, $temp); // รวมค่า Default กับค่าจริง
}

$swal_script = ""; 

if (isset($_POST['btn_login'])) {
    // ... (ส่วน Login Logic เหมือนเดิม เป๊ะๆ ไม่ต้องแก้) ...
    $ip   = $_POST['ip'];
    $user = $_POST['user'];
    $pass = $_POST['pass'];

    require_once 'core/routeros_api.class.php';
    $TestAPI = new RouterosAPI();
    $TestAPI->debug = false;

    if ($TestAPI->connect($ip, $user, $pass)) {
        $_SESSION['logged_in'] = true;
        $_SESSION['router_ip'] = $ip;
        $_SESSION['router_user'] = $user;
        $_SESSION['router_pass'] = $pass;
        $TestAPI->disconnect();
        header("Location: index.php");
        exit;
    } else {
        $swal_script = "
        <script>
            Swal.fire({ icon: 'error', title: 'เข้าสู่ระบบไม่สำเร็จ', text: 'IP, Username หรือ Password ไม่ถูกต้อง', confirmButtonColor: '#d33' });
        </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title><?php echo $settings['login_title']; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <style>
        body {
            /* ✅ ใช้ภาพพื้นหลังถ้ามี ถ้าไม่มีให้ใช้สี Gradient เดิม */
            <?php if($settings['login_bg']): ?>
                background: url('assets/img/<?php echo $settings['login_bg']; ?>') no-repeat center center fixed;
                background-size: cover;
            <?php else: ?>
                background: linear-gradient(135deg, #2c3e50, #4ca1af);
            <?php endif; ?>
            
            height: 100vh; display: flex; justify-content: center; align-items: center;
            font-family: 'Sarabun', sans-serif; margin: 0;
            
            /* เพิ่ม Overlay สีดำจางๆ ให้พื้นหลังอ่านง่ายขึ้น */
            position: relative;
        }
        /* Overlay */
        body::before {
            content: ""; position: absolute; top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0, 0, 0, 0.4); /* ความมืด 40% */
            z-index: -1;
        }

        .login-card {
            background: rgba(255, 255, 255, 0.95); /* โปร่งแสงนิดๆ ให้ดูหรู */
            padding: 40px; border-radius: 15px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.3); 
            width: 100%; max-width: 400px; text-align: center;
            backdrop-filter: blur(10px); /* เอฟเฟกต์กระจกเบลอ */
        }
        .login-logo { max-height: 80px; margin-bottom: 15px; }
        
        .form-group { margin-bottom: 15px; text-align: left; }
        .form-control { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 5px; box-sizing: border-box; }
        .btn-login { width: 100%; padding: 12px; background: #3498db; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 18px; font-weight: bold; }
        .btn-login:hover { background: #2980b9; }
    </style>
</head>
<body>

    <div class="login-card">
        <?php if($settings['login_logo']): ?>
            <img src="assets/img/<?php echo $settings['login_logo']; ?>" class="login-logo">
        <?php else: ?>
            <i class="fas fa-wifi" style="font-size: 50px; color: #3498db; margin-bottom: 10px;"></i>
        <?php endif; ?>

        <h2 style="margin: 0; color: #333;"><?php echo $settings['login_title']; ?></h2>
        <p style="color: #666; margin-top: 5px; margin-bottom: 20px;"><?php echo $settings['login_subtitle']; ?></p>
        
        <form method="post">
            <div class="form-group">
                <label>IP Address:</label>
                <input type="text" name="ip" class="form-control" value="xyla.cloud" required>
            </div>
            <div class="form-group">
                <label>Username:</label>
                <input type="text" name="user" class="form-control" value="x1" required>
            </div>
            <div class="form-group">
                <label>Password:</label>
                <input type="password" name="pass" class="form-control" placeholder="Enter Password">
            </div>
            <button type="submit" name="btn_login" class="btn-login">เข้าสู่ระบบ</button>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <?php echo $swal_script; ?>

</body>
</html>