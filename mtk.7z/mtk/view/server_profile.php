<?php
// view/server_profile.php

// -- 1. สั่งบันทึกการแก้ไข --
if (isset($_POST['btn_save'])) {
    $id_hex = $_POST['edit_id'];
    $real_id = hex2bin($id_hex); // แปลง ID กลับ

    $dns_name = $_POST['dns_name'];
    $html_dir = $_POST['html_dir'];
    
    // จัดการ Checkbox Login By (ต้องส่งเป็น Array หรือ String แล้วแต่ Version API)
    // สำหรับ Class RouterOS API นี้ มักจะรับเป็น Comma separated string
    $login_by = [];
    if(isset($_POST['login_cookie'])) $login_by[] = 'cookie';
    if(isset($_POST['login_http_chap'])) $login_by[] = 'http-chap';
    if(isset($_POST['login_trial'])) $login_by[] = 'trial';
    
    // แปลง array เป็น string เช่น "cookie,http-chap"
    $login_by_str = implode(',', $login_by);

    $trial_uptime = $_POST['trial_uptime'];
    $trial_reset = $_POST['trial_reset'];

    if ($API->connect($ip_router, $user_router, $pass_router)) {
        
        $API->comm("/ip/hotspot/profile/set", array(
            ".id"           => $real_id,
            "dns-name"      => $dns_name,
            "html-directory"=> $html_dir,
            "login-by"      => $login_by_str,
            "trial-uptime"  => $trial_uptime,
            "trial-user-profile" => "default" // บังคับใช้ default สำหรับ trial
        ));
        
        $API->disconnect();
        
        $_SESSION['swal_icon'] = 'success';
        $_SESSION['swal_title'] = 'บันทึกสำเร็จ';
        $_SESSION['swal_text'] = 'อัปเดต Server Profile เรียบร้อยแล้ว';
        header("Location: index.php?page=server_profile");
        exit;
    }
}

// -- 2. ดึงข้อมูล Server Profile --
$profiles = [];
if ($API->connect($ip_router, $user_router, $pass_router)) {
    $profiles = $API->comm("/ip/hotspot/profile/print");
    $API->disconnect();
}
?>

<div class="card">
    <div class="card-header">
        <h3><i class="fas fa-server"></i> โปรไฟล์เซิร์ฟเวอร์ (Server Profiles)</h3>
        <small class="text-muted">ตั้งค่า DNS, หน้า Login, และโหมดทดลองใช้ (Trial)</small>
    </div>

    <div style="overflow-x:auto;">
        <table class="table-hover">
            <thead>
                <tr>
                    <th>ชื่อ Profile</th>
                    <th>DNS Name</th>
                    <th>HTML Directory</th>
                    <th>โหมดล็อกอิน (Login By)</th>
                    <th>Trial (เวลาเล่น)</th>
                    <th>จัดการ</th>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($profiles as $p) {
                    $p_id = $p['.id'];
                    $p_id_safe = bin2hex($p_id);
                    $name = $p['name'];
                    $dns = isset($p['dns-name']) ? $p['dns-name'] : '-';
                    $html = isset($p['html-directory']) ? $p['html-directory'] : '-';
                    $login_by = isset($p['login-by']) ? $p['login-by'] : '-';
                    
                    // Trial Status
                    $is_trial = (strpos($login_by, 'trial') !== false);
                    $trial_uptime = isset($p['trial-uptime']) ? $p['trial-uptime'] : '-';
                    
                    $trial_badge = $is_trial 
                        ? "<span class='badge' style='background:#27ae60;'>ON ($trial_uptime)</span>" 
                        : "<span class='badge' style='background:#ccc; color:#333;'>OFF</span>";

                    echo "<tr>";
                    echo "<td><b>$name</b></td>";
                    echo "<td style='color:#2980b9;'>$dns</td>";
                    echo "<td>$html</td>";
                    echo "<td><small>$login_by</small></td>";
                    echo "<td>$trial_badge</td>";
                    echo "<td>";
                    ?>
                    <button type="button" onclick="openEditModal('<?php echo $p_id_safe; ?>', '<?php echo $name; ?>', '<?php echo $dns; ?>', '<?php echo $html; ?>', '<?php echo $login_by; ?>', '<?php echo $trial_uptime; ?>')" class="btn btn-warning" style="padding:5px 10px; font-size:12px; color:#333;">
                        <i class="fas fa-edit"></i> แก้ไข
                    </button>
                    <?php
                    echo "</td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<div id="editModal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:9999; justify-content:center; align-items:center;">
    <div style="background:white; width:90%; max-width:500px; padding:20px; border-radius:10px; box-shadow:0 5px 15px rgba(0,0,0,0.3); animation: slideDown 0.3s;">
        
        <div style="display:flex; justify-content:space-between; margin-bottom:15px; border-bottom:1px solid #eee; padding-bottom:10px;">
            <h4 style="margin:0;">✏️ แก้ไข Profile: <span id="modal_title_name" style="color:#2980b9;"></span></h4>
            <button onclick="closeEditModal()" style="border:none; background:none; font-size:20px; cursor:pointer;">&times;</button>
        </div>

        <form method="post">
            <input type="hidden" name="edit_id" id="modal_id">
            
            <div class="form-group">
                <label>DNS Name (ชื่อเว็บตอน Login):</label>
                <input type="text" name="dns_name" id="modal_dns" class="form-control" placeholder="เช่น login.net">
            </div>

            <div class="form-group">
                <label>HTML Directory (โฟลเดอร์หน้าเว็บ):</label>
                <input type="text" name="html_dir" id="modal_html" class="form-control" required>
            </div>

            <div class="form-group">
                <label>Login By (เลือกวิธีการยืนยันตัวตน):</label>
                <div style="display:flex; gap:15px; flex-wrap:wrap;">
                    <label style="cursor:pointer;"><input type="checkbox" name="login_http_chap" id="chk_chap" value="yes"> HTTP CHAP (มาตรฐาน)</label>
                    <label style="cursor:pointer;"><input type="checkbox" name="login_cookie" id="chk_cookie" value="yes"> Cookie (จำรหัส)</label>
                    <label style="cursor:pointer;"><input type="checkbox" name="login_trial" id="chk_trial" value="yes"> Trial (ทดลองใช้ฟรี)</label>
                </div>
            </div>

            <div class="form-group" style="background:#f9f9f9; padding:10px; border-radius:5px;">
                <label><i class="fas fa-clock"></i> ตั้งค่า Trial (ถ้าเปิด):</label>
                <div style="display:flex; gap:10px;">
                    <div style="flex:1;">
                        <small>Uptime (เล่นได้นาน):</small>
                        <input type="text" name="trial_uptime" id="modal_trial_uptime" class="form-control" placeholder="30m">
                    </div>
                    <div style="flex:1;">
                        <small>Reset (เล่นใหม่ได้ทุก):</small>
                        <input type="text" name="trial_reset" value="1d" class="form-control" readonly style="background:#eee; cursor:not-allowed;" title="ค่า Default 1 วัน">
                    </div>
                </div>
            </div>

            <hr>
            <div style="text-align:right;">
                <button type="button" onclick="closeEditModal()" class="btn" style="background:#ccc; color:#333; margin-right:5px;">ยกเลิก</button>
                <button type="submit" name="btn_save" class="btn btn-primary">บันทึกการเปลี่ยนแปลง</button>
            </div>
        </form>
    </div>
</div>

<style>
    @keyframes slideDown {
        from { transform: translateY(-50px); opacity: 0; }
        to { transform: translateY(0); opacity: 1; }
    }
    .table-hover tbody tr:hover { background-color: #f1f2f6; }
</style>

<script>
    function openEditModal(id, name, dns, html, loginby, trial_uptime) {
        document.getElementById('editModal').style.display = 'flex';
        
        document.getElementById('modal_id').value = id;
        document.getElementById('modal_title_name').innerText = name;
        document.getElementById('modal_dns').value = dns;
        document.getElementById('modal_html').value = html;
        document.getElementById('modal_trial_uptime').value = trial_uptime;

        // Set Checkbox
        document.getElementById('chk_chap').checked = loginby.includes('http-chap');
        document.getElementById('chk_cookie').checked = loginby.includes('cookie');
        document.getElementById('chk_trial').checked = loginby.includes('trial');
    }

    function closeEditModal() {
        document.getElementById('editModal').style.display = 'none';
    }
    
    // ปิด Modal เมื่อคลิกพื้นหลัง
    window.onclick = function(event) {
        if (event.target == document.getElementById('editModal')) {
            closeEditModal();
        }
    }
</script>