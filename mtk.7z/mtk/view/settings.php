<?php
// view/settings.php
$json_file = 'config/settings.json';

if (isset($_POST['btn_save'])) {
    $new_settings = [
        'app_name' => $_POST['app_name'],
        'theme'    => $_POST['theme'],
        'currency' => $_POST['currency']
    ];
    
    if (file_put_contents($json_file, json_encode($new_settings, JSON_PRETTY_PRINT))) {
        // ✅ Alert Success
        $_SESSION['swal_icon'] = 'success';
        $_SESSION['swal_title'] = 'บันทึกสำเร็จ!';
        $_SESSION['swal_text'] = 'การตั้งค่าของคุณถูกอัปเดตแล้ว';
        header("Location: index.php?page=settings");
        exit;
    } else {
        // ✅ Alert Error
        $_SESSION['swal_icon'] = 'error';
        $_SESSION['swal_title'] = 'บันทึกไม่สำเร็จ';
        $_SESSION['swal_text'] = 'กรุณาเช็ค Permission ไฟล์';
    }
}

$settings = ['app_name' => 'MyHotspot', 'theme' => 'blue', 'currency' => 'THB'];
if (file_exists($json_file)) {
    $settings = json_decode(file_get_contents($json_file), true);
}
?>

<div class="card">
    <div class="card-header">
        <h3><i class="fas fa-cogs"></i> ตั้งค่าระบบ (System Settings)</h3>
    </div>
    
    <div class="card-body">
        <form method="post">
            <div class="form-group">
                <label>ชื่อระบบ / ชื่อร้าน (App Name):</label>
                <input type="text" name="app_name" value="<?php echo $settings['app_name']; ?>" class="form-control" required>
            </div>
            <div class="form-group">
                <label>ธีมสี (Theme Color):</label>
                <select name="theme" class="form-control">
                    <option value="blue" <?php echo ($settings['theme']=='blue')?'selected':''; ?>>🔵 Midnight Blue</option>
                    <option value="dark" <?php echo ($settings['theme']=='dark')?'selected':''; ?>>⚫ Dark Mode</option>
                    <option value="red"  <?php echo ($settings['theme']=='red')?'selected':''; ?>>🔴 Red Hot</option>
                    <option value="green" <?php echo ($settings['theme']=='green')?'selected':''; ?>>🟢 Green Nature</option>
                    <option value="purple" <?php echo ($settings['theme']=='purple')?'selected':''; ?>>🟣 Purple Cyber</option>
                </select>
            </div>
            <div class="form-group">
                <label>สกุลเงิน (Currency):</label>
                <input type="text" name="currency" value="<?php echo $settings['currency']; ?>" class="form-control">
            </div>
            <hr>
            <button type="submit" name="btn_save" class="btn btn-primary">
                <i class="fas fa-save"></i> บันทึกการตั้งค่า
            </button>
        </form>
    </div>
</div>