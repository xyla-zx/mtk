<?php
// view/add_user.php
$status_msg = "";

if ($API->connect($ip_router, $user_router, $pass_router)) {
    
    // 1. ถ้ามีการกดปุ่ม Save (POST)
    if (isset($_POST['btn_add'])) {
        $API->comm("/ip/hotspot/user/add", array(
            "name"     => $_POST['u_name'],
            "password" => $_POST['u_pass'],
            "profile"  => $_POST['u_profile'],
            "comment"  => $_POST['u_comment']
        ));
        $status_msg = "<div style='background:#d4edda; color:#155724; padding:10px; border-radius:5px; margin-bottom:15px;'>✅ สร้าง User สำเร็จแล้ว!</div>";
    }

    // 2. ดึง Profile เพื่อมาใส่ใน Select Option
    $profiles = $API->comm("/ip/hotspot/user/profile/print");
    
    $API->disconnect();
}
?>

<div class="card">
    <div class="card-header">
        <h3><i class="fas fa-user-plus"></i> เพิ่มผู้ใช้งานใหม่ (Add User)</h3>
    </div>

    <?php echo $status_msg; ?>

    <form method="post" action="">
        <div class="form-group">
            <label>Username (ชื่อผู้ใช้)</label>
            <input type="text" name="u_name" required placeholder="กรอกชื่อผู้ใช้..." class="form-control">
        </div>

        <div class="form-group">
            <label>Password (รหัสผ่าน)</label>
            <input type="text" name="u_pass" required placeholder="กรอกรหัสผ่าน..." class="form-control">
        </div>

        <div class="form-group">
            <label>Profile (แพ็กเกจ)</label>
            <select name="u_profile" class="form-control">
                <?php
                if(isset($profiles)){
                    foreach ($profiles as $p) {
                        echo "<option value='".$p['name']."'>".$p['name']."</option>";
                    }
                }
                ?>
            </select>
        </div>

        <div class="form-group">
            <label>หมายเหตุ (Comment)</label>
            <input type="text" name="u_comment" value="Created by Web UI" class="form-control">
        </div>

        <button type="submit" name="btn_add" class="btn btn-primary">
            <i class="fas fa-save"></i> บันทึกข้อมูล
        </button>
    </form>
</div>