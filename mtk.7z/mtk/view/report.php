<?php
// view/report.php

$total_money = 0;
$total_users = 0;
$report_data = []; // เก็บข้อมูลเพื่อเอาไปวนลูปแสดงผล

if ($API->connect($ip_router, $user_router, $pass_router)) {
    
    // 1. ดึงข้อมูล Profile และราคา (จาก Comment)
    $profiles = $API->comm("/ip/hotspot/user/profile/print");
    $price_list = []; // เก็บราคา key=ชื่อแพ็กเกจ, value=ราคา
    
    foreach ($profiles as $p) {
        $name = $p['name'];
        // แปลง comment เป็นตัวเลข (ถ้าไม่มีหรือเป็นตัวหนังสือจะได้ 0)
        $price = isset($p['comment']) ? intval($p['comment']) : 0;
        $price_list[$name] = $price;
    }

    // 2. ดึงข้อมูล User ทั้งหมด
    $users = $API->comm("/ip/hotspot/user/print");
    $total_users = count($users);

    // 3. วนลูปนับจำนวน User แยกตาม Profile
    $count_list = []; // key=ชื่อแพ็กเกจ, value=จำนวนคน
    
    foreach ($users as $u) {
        $u_profile = isset($u['profile']) ? $u['profile'] : 'unknown';
        
        if (!isset($count_list[$u_profile])) {
            $count_list[$u_profile] = 0;
        }
        $count_list[$u_profile]++;
    }
    
    // 4. รวมร่างข้อมูล (จำนวน x ราคา)
    foreach ($price_list as $p_name => $p_price) {
        // จำนวนคนในแพ็กเกจนี้ (ถ้าไม่มีคือ 0)
        $count = isset($count_list[$p_name]) ? $count_list[$p_name] : 0;
        $sum = $count * $p_price;
        
        $total_money += $sum;
        
        // เก็บใส่ Array ไว้แสดงผล
        $report_data[] = [
            'name' => $p_name,
            'price' => $p_price,
            'count' => $count,
            'total' => $sum
        ];
    }

    $API->disconnect();
}

// ดึงสกุลเงินจาก Settings
$currency = 'THB';
if(file_exists('config/settings.json')) {
    $s = json_decode(file_get_contents('config/settings.json'), true);
    if(isset($s['currency'])) $currency = $s['currency'];
}
?>

<div class="card-header">
    <h3><i class="fas fa-chart-pie"></i> รายงานสรุปยอดขาย (Sales Report)</h3>
</div>

<div class="row">
    <div class="col-3" style="flex: 0 0 50%; max-width: 50%;">
        <div class="card" style="background: #27ae60; color: white;">
            <div class="card-body" style="display:flex; align-items:center;">
                <i class="fas fa-coins" style="font-size: 50px; opacity: 0.5; margin-right: 20px;"></i>
                <div>
                    <h4 style="margin:0; font-weight:normal;">ยอดขายรวมโดยประมาณ</h4>
                    <h1 style="margin:0; font-size: 40px;">
                        <?php echo number_format($total_money); ?> <small style="font-size:20px;"><?php echo $currency; ?></small>
                    </h1>
                </div>
            </div>
        </div>
    </div>

    <div class="col-3" style="flex: 0 0 50%; max-width: 50%;">
        <div class="card" style="background: #2980b9; color: white;">
            <div class="card-body" style="display:flex; align-items:center;">
                <i class="fas fa-users" style="font-size: 50px; opacity: 0.5; margin-right: 20px;"></i>
                <div>
                    <h4 style="margin:0; font-weight:normal;">จำนวนคูปองทั้งหมด</h4>
                    <h1 style="margin:0; font-size: 40px;">
                        <?php echo number_format($total_users); ?> <small style="font-size:20px;">ใบ</small>
                    </h1>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card" style="margin-top: 20px;">
    <div class="card-header">
        แยกตามแพ็กเกจ (By Profile)
    </div>
    <div style="overflow-x:auto;">
        <table>
            <thead>
                <tr>
                    <th>ชื่อแพ็กเกจ</th>
                    <th style="text-align:right;">ราคาต่อใบ</th>
                    <th style="text-align:center;">จำนวนที่สร้าง (ใบ)</th>
                    <th style="text-align:right;">รวมเป็นเงิน</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($report_data as $row): ?>
                <?php if($row['name'] == 'default' && $row['count'] == 0) continue; ?>
                
                <tr>
                    <td>
                        <b><?php echo $row['name']; ?></b>
                        <?php if($row['price'] == 0): ?>
                            <span class="badge" style="background:#ccc; color:#333;">ฟรี / ไม่ระบุราคา</span>
                        <?php endif; ?>
                    </td>
                    <td style="text-align:right; color:#666;">
                        <?php echo number_format($row['price']); ?>
                    </td>
                    <td style="text-align:center;">
                        <span class="badge" style="background:#3498db; font-size:14px;">
                            <?php echo number_format($row['count']); ?>
                        </span>
                    </td>
                    <td style="text-align:right; font-weight:bold; color:#27ae60;">
                        <?php echo number_format($row['total']); ?> <?php echo $currency; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                
                <tr style="background-color:#f9f9f9; font-weight:bold;">
                    <td colspan="2" style="text-align:right;">รวมทั้งสิ้น:</td>
                    <td style="text-align:center;"><?php echo number_format($total_users); ?></td>
                    <td style="text-align:right; color:#27ae60; font-size:18px;">
                        <?php echo number_format($total_money); ?> <?php echo $currency; ?>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>