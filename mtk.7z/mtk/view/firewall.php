<?php
/**
 * View: Firewall Manager
 * Structure: 
 * 1. Logic (Connect API & Fetch Data)
 * 2. Style (CSS Overrides)
 * 3. UI (Form & Table)
 */

// --- 1. Logic Section ---
$firewall_list = [];
$api_status = false;

if ($API->connect($ip_router, $user_router, $pass_router)) {
    $api_status = true;
    // ดึงข้อมูลพร้อม Stats (bytes, packets)
    $firewall_list = $API->comm("/ip/firewall/filter/print", array("stats" => ""));
    $API->disconnect();
}

// Function แปลงหน่วย Byte ให้สวยงาม
function formatSize($bytes) {
    if ($bytes >= 1073741824) return number_format($bytes / 1073741824, 2) . ' GB';
    if ($bytes >= 1048576) return number_format($bytes / 1048576, 2) . ' MB';
    if ($bytes >= 1024) return number_format($bytes / 1024, 2) . ' KB';
    return $bytes . ' B';
}
?>

<style>
    .dash-card {
        background: #fff;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        padding: 20px;
        margin-bottom: 20px;
        border: 1px solid #eaeaea;
    }
    .form-section {
        background: #f8f9fa;
        padding: 20px;
        border-radius: 8px;
        border: 1px dashed #ced4da;
        margin-bottom: 25px;
    }
    .status-disabled {
        background-color: #f1f1f1 !important;
        color: #999 !important;
    }
    .status-disabled td {
        color: #999;
    }
    .badge-chain { font-size: 12px; background: #34495e; color: #fff; padding: 3px 8px; border-radius: 4px; }
    .badge-action-drop { background: #e74c3c; color: white; }
    .badge-action-accept { background: #27ae60; color: white; }
    .table-responsive { overflow-x: auto; }
</style>

<div class="container-fluid">
    
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
        <h3 style="margin:0; color:#2c3e50;"><i class="fas fa-shield-alt"></i> Firewall Manager</h3>
        <span class="badge <?php echo $api_status ? 'badge-success' : 'badge-danger'; ?>">
            API: <?php echo $api_status ? 'Connected' : 'Disconnected'; ?>
        </span>
    </div>

    <div class="dash-card">
        
        <button class="btn btn-primary btn-sm mb-3" type="button" onclick="document.getElementById('addRuleForm').style.display = (document.getElementById('addRuleForm').style.display === 'none' ? 'block' : 'none');">
            <i class="fas fa-plus-circle"></i> สร้างกฎใหม่ (Add New Rule)
        </button>

        <div id="addRuleForm" class="form-section" style="display: none;">
            <form action="post/handler_firewall.php" method="POST">
                <input type="hidden" name="action" value="add_rule">
                
                <h5 style="border-bottom:1px solid #ddd; padding-bottom:10px; margin-bottom:15px;">กำหนดค่า (Configuration)</h5>
                
                <div class="row">
                    <div class="col-md-3 mb-2">
                        <label>Chain <span style="color:red">*</span></label>
                        <select name="chain" class="form-control" required>
                            <option value="forward">forward (ผ่านเราเตอร์)</option>
                            <option value="input">input (เข้าตัวเราเตอร์)</option>
                            <option value="output">output (ออกจากเราเตอร์)</option>
                        </select>
                    </div>
                    <div class="col-md-3 mb-2">
                        <label>Action <span style="color:red">*</span></label>
                        <select name="action_type" class="form-control" required>
                            <option value="accept">Accept (อนุญาต)</option>
                            <option value="drop">Drop (บล็อก)</option>
                            <option value="passthrough">Passthrough</option>
                        </select>
                    </div>
                    <div class="col-md-3 mb-2">
                        <label>Protocol</label>
                        <select name="protocol" class="form-control">
                            <option value="">Any</option>
                            <option value="tcp">TCP</option>
                            <option value="udp">UDP</option>
                            <option value="icmp">ICMP (Ping)</option>
                        </select>
                    </div>
                    <div class="col-md-3 mb-2">
                        <label>Dst. Port</label>
                        <input type="text" name="dst_port" class="form-control" placeholder="เช่น 80, 443">
                    </div>
                    <div class="col-md-6 mb-2">
                        <label>Src. Address (IP ต้นทาง)</label>
                        <input type="text" name="src_address" class="form-control" placeholder="เช่น 192.168.1.50 หรือ 192.168.1.0/24">
                    </div>
                    <div class="col-md-6 mb-2">
                        <label>Comment (หมายเหตุ)</label>
                        <input type="text" name="comment" class="form-control" placeholder="เช่น Block YouTube">
                    </div>
                </div>
                <div class="text-right mt-3">
                    <button type="submit" class="btn btn-success"><i class="fas fa-save"></i> บันทึกกฎ (Save Rule)</button>
                </div>
            </form>
        </div>

        <div class="table-responsive">
            <table class="table table-hover table-bordered" style="font-size: 14px;">
                <thead style="background: #f1f2f6; color: #555;">
                    <tr>
                        <th width="5%" class="text-center">#</th>
                        <th width="10%">Chain</th>
                        <th width="25%">Condition (เงื่อนไข)</th>
                        <th width="10%" class="text-center">Action</th>
                        <th width="15%" class="text-right">Bytes</th>
                        <th width="15%" class="text-right">Packets</th>
                        <th width="20%" class="text-center">Tools</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($firewall_list) > 0): ?>
                        <?php foreach ($firewall_list as $index => $rule): 
                            // เช็คสถานะ Disabled
                            $isDisabled = (isset($rule['disabled']) && $rule['disabled'] == 'true');
                            $rowClass = $isDisabled ? 'status-disabled' : '';
                            
                            // ดึงค่า Action เพื่อเลือกสี
                            $act = isset($rule['action']) ? $rule['action'] : '-';
                            $badgeClass = ($act == 'drop') ? 'badge-action-drop' : (($act == 'accept') ? 'badge-action-accept' : 'badge-secondary');
                        ?>
                        <tr class="<?php echo $rowClass; ?>">
                            <td class="text-center"><?php echo $index + 1; ?></td>
                            
                            <td>
                                <span class="badge-chain"><?php echo isset($rule['chain']) ? $rule['chain'] : '-'; ?></span>
                                <?php if(isset($rule['comment'])): ?>
                                    <div style="font-size:11px; color:#e67e22; margin-top:2px;">
                                        <i class="fas fa-comment-dots"></i> <?php echo $rule['comment']; ?>
                                    </div>
                                <?php endif; ?>
                            </td>

                            <td>
                                <?php 
                                    $cond = [];
                                    if(isset($rule['protocol'])) $cond[] = "Proto: <b>".$rule['protocol']."</b>";
                                    if(isset($rule['dst-port'])) $cond[] = "Port: <b>".$rule['dst-port']."</b>";
                                    if(isset($rule['src-address'])) $cond[] = "Src: <b>".$rule['src-address']."</b>";
                                    if(isset($rule['dst-address'])) $cond[] = "Dst: <b>".$rule['dst-address']."</b>";
                                    
                                    echo empty($cond) ? '<span style="color:#aaa;">Any</span>' : implode("<br>", $cond);
                                ?>
                            </td>

                            <td class="text-center">
                                <span class="badge <?php echo $badgeClass; ?>" style="padding: 5px 10px;">
                                    <?php echo strtoupper($act); ?>
                                </span>
                            </td>

                            <td class="text-right" style="font-family:monospace;">
                                <?php echo isset($rule['bytes']) ? formatSize($rule['bytes']) : '0 B'; ?>
                            </td>

                            <td class="text-right" style="font-family:monospace;">
                                <?php echo isset($rule['packets']) ? number_format($rule['packets']) : '0'; ?>
                            </td>

                            <td class="text-center">
                                <div class="btn-group btn-group-sm">
                                    <form action="post/handler_firewall.php" method="POST" style="display:inline;">
                                        <input type="hidden" name="action" value="toggle_rule">
                                        <input type="hidden" name="id" value="<?php echo $rule['.id']; ?>">
                                        <input type="hidden" name="current_status" value="<?php echo $isDisabled ? 'true' : 'false'; ?>">
                                        <button type="submit" class="btn <?php echo $isDisabled ? 'btn-secondary' : 'btn-warning'; ?>" title="<?php echo $isDisabled ? 'Enable' : 'Disable'; ?>">
                                            <i class="fas <?php echo $isDisabled ? 'fa-play' : 'fa-pause'; ?>"></i>
                                        </button>
                                    </form>

                                    <button onclick="confirmDelete('<?php echo $rule['.id']; ?>')" class="btn btn-danger" title="Delete">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                </div>

                                <form id="del-form-<?php echo $rule['.id']; ?>" action="post/handler_firewall.php" method="POST" style="display:none;">
                                    <input type="hidden" name="action" value="delete_rule">
                                    <input type="hidden" name="id" value="<?php echo $rule['.id']; ?>">
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="7" class="text-center p-4 text-muted">-- ไม่พบกฎ Firewall ในระบบ --</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    </div>
</div>