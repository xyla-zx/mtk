<?php
// view/system.php

// -- 1. สั่ง Reboot --
if (isset($_POST['action']) && $_POST['action'] == 'reboot') {
    if ($API->connect($ip_router, $user_router, $pass_router)) {
        $API->comm("/system/reboot");
        $API->disconnect();
        session_destroy();
        echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
        <script>Swal.fire({icon:'info',title:'กำลังรีบูต...',text:'รอสักครู่...',showConfirmButton:false,timer:5000,willClose:()=>{window.location='index.php';}});</script>";
        exit;
    }
}

// -- 2. สั่ง Shutdown --
if (isset($_POST['action']) && $_POST['action'] == 'shutdown') {
    if ($API->connect($ip_router, $user_router, $pass_router)) {
        $API->comm("/system/shutdown");
        $API->disconnect();
        session_destroy();
        echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
        <script>Swal.fire({icon:'warning',title:'ปิดเครื่องแล้ว',text:'ต้องเปิดใหม่ที่หน้าเครื่อง',confirmButtonText:'OK',willClose:()=>{window.location='index.php';}});</script>";
        exit;
    }
}
?>

<style>
    /* CSS ตกแต่งให้สวยงาม */
    .stat-label { font-size: 14px; color: #666; margin-bottom: 5px; display: flex; justify-content: space-between; }
    .progress { background: #eee; border-radius: 10px; height: 10px; width: 100%; overflow: hidden; margin-bottom: 20px; }
    .progress-bar { height: 100%; border-radius: 10px; transition: width 0.5s ease; } /* Transition ทำให้หลอดขยับนุ่มนวล */
    .bg-cpu { background: linear-gradient(90deg, #ff9966, #ff5e62); }
    .bg-ram { background: linear-gradient(90deg, #56ab2f, #a8e063); }
    .bg-hdd { background: linear-gradient(90deg, #4568dc, #b06ab3); }
    
    .detail-item { padding: 10px 0; border-bottom: 1px solid #f0f0f0; display: flex; justify-content: space-between; }
    .detail-item:last-child { border-bottom: none; }
    .detail-icon { width: 30px; text-align: center; color: var(--accent-color); margin-right: 10px; }
    
    .uptime-box { background: #f8f9fa; padding: 15px; border-radius: 8px; text-align: center; margin-bottom: 20px; border: 1px dashed #ccc; }
    .uptime-time { font-size: 24px; font-weight: bold; color: #2c3e50; font-family: monospace; }
    
    .power-btn { 
        display: block; width: 100%; padding: 20px; margin-bottom: 15px; 
        border: none; border-radius: 12px; color: white; font-size: 16px; cursor: pointer; 
        transition: transform 0.2s, box-shadow 0.2s; text-align: left; position: relative; overflow: hidden;
    }
    .power-btn:hover { transform: translateY(-3px); box-shadow: 0 5px 15px rgba(0,0,0,0.2); }
    .power-btn i { font-size: 30px; position: absolute; right: 20px; top: 50%; transform: translateY(-50%); opacity: 0.3; }
    .btn-reboot { background: linear-gradient(135deg, #f09819, #edde5d); color: #444; font-weight:bold;}
    .btn-shutdown { background: linear-gradient(135deg, #cb2d3e, #ef473a); }
</style>

<div class="row">
    <div class="col-3" style="flex: 0 0 60%; max-width: 60%; padding-right:15px;">
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-microchip"></i> สถานะทรัพยากร (Real-time Health)</h3>
            </div>
            <div class="card-body">
                
                <div class="uptime-box">
                    <div style="font-size:12px; color:#888; margin-bottom:5px;">เปิดใช้งานต่อเนื่อง (Uptime)</div>
                    <div class="uptime-time"><i class="fas fa-clock"></i> <span id="val-uptime">...</span></div>
                </div>

                <div class="stat-label">
                    <span><i class="fas fa-tachometer-alt"></i> CPU Load</span>
                    <strong id="val-cpu">0%</strong>
                </div>
                <div class="progress"><div id="bar-cpu" class="progress-bar bg-cpu" style="width: 0%;"></div></div>

                <div class="stat-label">
                    <span><i class="fas fa-memory"></i> RAM Usage</span>
                    <small id="val-ram">...</small>
                </div>
                <div class="progress"><div id="bar-ram" class="progress-bar bg-ram" style="width: 0%;"></div></div>

                <div class="stat-label">
                    <span><i class="fas fa-hdd"></i> HDD Storage</span>
                    <small id="val-hdd">...</small>
                </div>
                <div class="progress"><div id="bar-hdd" class="progress-bar bg-hdd" style="width: 0%;"></div></div>

                <hr>

                <div class="detail-item">
                    <span><i class="fas fa-tag detail-icon"></i> Identity Name</span>
                    <b id="val-identity">...</b>
                </div>
                <div class="detail-item">
                    <span><i class="fas fa-server detail-icon"></i> Board Model</span>
                    <span id="val-model">...</span>
                </div>
                <div class="detail-item">
                    <span><i class="fas fa-code-branch detail-icon"></i> RouterOS Version</span>
                    <span class="badge" style="background:#3498db;" id="val-version">...</span>
                </div>
                <div class="detail-item">
                    <span><i class="fas fa-microchip detail-icon"></i> CPU Info</span>
                    <span id="val-cpu-info" style="font-size:12px;">...</span>
                </div>

            </div>
        </div>
    </div>

    <div class="col-3" style="flex: 0 0 40%; max-width: 40%;">
        
        <div class="card" style="border-left: 5px solid #e74c3c;">
            <div class="card-header" style="border-bottom:none;">
                <h3 style="color:#c0392b;"><i class="fas fa-power-off"></i> แผงควบคุม (Power)</h3>
            </div>
            <div class="card-body">
                <div style="background:#fff3cd; color:#856404; padding:10px; border-radius:5px; font-size:13px; margin-bottom:20px; border:1px solid #ffeeba;">
                    <i class="fas fa-exclamation-triangle"></i> <b>คำเตือน:</b> การสั่งงานในหน้านี้จะทำให้การเชื่อมต่ออินเทอร์เน็ตหลุดทันที โปรดระวัง!
                </div>

                <form method="post" id="form-reboot">
                    <input type="hidden" name="action" value="reboot">
                    <button type="button" onclick="confirmReboot()" class="power-btn btn-reboot">
                        <b><i class="fas fa-sync-alt"></i> Reboot System</b><br>
                        <span style="font-size:12px; opacity:0.8;">รีสตาร์ทเครื่องใหม่ (เริ่มระบบใหม่)</span>
                        <i class="fas fa-sync-alt"></i>
                    </button>
                </form>

                <form method="post" id="form-shutdown">
                    <input type="hidden" name="action" value="shutdown">
                    <button type="button" onclick="confirmShutdown()" class="power-btn btn-shutdown">
                        <b><i class="fas fa-power-off"></i> Shutdown System</b><br>
                        <span style="font-size:12px; opacity:0.8;">ปิดเครื่องทันที (ต้องเปิดเองหน้างาน)</span>
                        <i class="fas fa-power-off"></i>
                    </button>
                </form>
            </div>
        </div>

        <div class="card" style="margin-top:20px; text-align:center; opacity:0.7;">
            <div class="card-body">
                <i class="fas fa-wifi" style="font-size:40px; color:#ddd; margin-bottom:10px;"></i>
                <div style="font-size:12px;">MikroTik API Manager v1.0</div>
            </div>
        </div>

    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    // ฟังก์ชันดึงข้อมูล Real-time
    function loadSystemHealth() {
        $.ajax({
            url: "get/get_system_health.php",
            type: "GET",
            dataType: "json",
            success: function(data) {
                if(data.status === 'success') {
                    // อัปเดตตัวเลขและข้อความ
                    $("#val-uptime").text(data.uptime);
                    $("#val-cpu").text(data.cpu_load + "%");
                    $("#val-ram").text(data.mem_text);
                    $("#val-hdd").text(data.hdd_text);
                    
                    $("#val-identity").text(data.identity);
                    $("#val-model").text(data.board_name);
                    $("#val-version").text(data.version);
                    $("#val-cpu-info").text(data.cpu_info);

                    // อัปเดตความกว้างหลอดพลัง (CSS Width)
                    $("#bar-cpu").css("width", data.cpu_load + "%");
                    $("#bar-ram").css("width", data.mem_percent + "%");
                    $("#bar-hdd").css("width", data.hdd_percent + "%");
                }
            }
        });
    }

    // เริ่มทำงานเมื่อโหลดหน้าเสร็จ
    $(document).ready(function() {
        loadSystemHealth(); // เรียกครั้งแรกทันที
        setInterval(loadSystemHealth, 2000); // เรียกซ้ำทุก 2 วินาที
    });

    // ปุ่ม Reboot/Shutdown
    function confirmReboot() {
        Swal.fire({
            title: 'ยืนยันการรีบูต?',
            text: "ระบบจะทำการเริ่มใหม่ เน็ตจะตัดชั่วคราว",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#f39c12',
            confirmButtonText: 'ใช่, รีบูตเลย!',
            cancelButtonText: 'ยกเลิก'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('form-reboot').submit();
            }
        })
    }

    function confirmShutdown() {
        Swal.fire({
            title: 'ปิดเครื่องจริงเหรอ?',
            text: "⚠️ คุณต้องไปเปิดเครื่องเองที่หน้างานนะ! สั่งเปิดผ่านเว็บไม่ได้!",
            icon: 'error',
            showCancelButton: true,
            confirmButtonColor: '#c0392b',
            confirmButtonText: 'รู้แล้ว, ปิดเลย!',
            cancelButtonText: 'ไม่เอา'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('form-shutdown').submit();
            }
        })
    }
</script>