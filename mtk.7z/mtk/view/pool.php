<?php
// view/pool.php

// -- 1. สั่งเพิ่ม Pool --
if (isset($_POST['btn_add'])) {
    $name = $_POST['name'];
    $ranges = $_POST['ranges'];
    $next_pool = $_POST['next_pool'] == 'none' ? '' : $_POST['next_pool'];

    if ($API->connect($ip_router, $user_router, $pass_router)) {
        $API->comm("/ip/pool/add", array(
            "name"      => $name,
            "ranges"    => $ranges,
            "next-pool" => $next_pool
        ));
        $API->disconnect();
        
        $_SESSION['swal_icon'] = 'success';
        $_SESSION['swal_title'] = 'เพิ่มสำเร็จ';
        $_SESSION['swal_text'] = 'เพิ่ม IP Pool: ' . $name . ' เรียบร้อย';
        header("Location: index.php?page=pool");
        exit;
    }
}

// -- 2. สั่งลบ Pool --
if (isset($_POST['btn_delete'])) {
    $id_hex = $_POST['del_id'];
    $real_id = hex2bin($id_hex);

    if ($API->connect($ip_router, $user_router, $pass_router)) {
        $API->comm("/ip/pool/remove", array(".id" => $real_id));
        $API->disconnect();
        
        $_SESSION['swal_icon'] = 'success';
        $_SESSION['swal_title'] = 'ลบสำเร็จ';
        $_SESSION['swal_text'] = 'ลบ IP Pool เรียบร้อยแล้ว';
        header("Location: index.php?page=pool");
        exit;
    }
}

// -- 3. ดึงข้อมูล --
$pools = [];
if ($API->connect($ip_router, $user_router, $pass_router)) {
    $pools = $API->comm("/ip/pool/print");
    $API->disconnect();
}
?>

<div class="row">
    <div class="col-3" style="flex: 0 0 35%; max-width: 35%;">
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-swimming-pool"></i> สร้างกลุ่มไอพี (Add IP Pool)</h3>
            </div>
            <div class="card-body">
                <form method="post">
                    
                    <div class="form-group">
                        <label>ชื่อกลุ่ม (Name):</label>
                        <input type="text" name="name" class="form-control" placeholder="เช่น hs-pool-2" required>
                    </div>

                    <div class="form-group">
                        <label>ช่วงไอพี (Ranges):</label>
                        <input type="text" name="ranges" class="form-control" placeholder="192.168.88.10-192.168.88.254" required>
                        <small class="text-muted">รูปแบบ: IP เริ่มต้น - IP สิ้นสุด</small>
                    </div>

                    <div class="form-group">
                        <label>Next Pool (ถ้าเต็มให้ไปใช้):</label>
                        <select name="next_pool" class="form-control">
                            <option value="none">-- ไม่มี (None) --</option>
                            <?php foreach($pools as $p): ?>
                                <option value="<?php echo $p['name']; ?>"><?php echo $p['name']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <hr>
                    <button type="submit" name="btn_add" class="btn btn-primary" style="width:100%;">
                        <i class="fas fa-save"></i> บันทึกข้อมูล
                    </button>
                </form>
            </div>
        </div>
        
        <div class="card" style="margin-top:20px; background:#e3f2fd; border:1px solid #90caf9;">
            <div class="card-body" style="font-size:13px; color:#1565c0;">
                <i class="fas fa-info-circle"></i> <b>Tips:</b><br>
                หากลูกค้าเชื่อมต่อไม่ได้เพราะ IP เต็ม ให้ลองเพิ่ม Pool ใหม่ แล้วตั้งค่า <b>Next Pool</b> ของอันเดิมมาชี้ที่อันใหม่ครับ
            </div>
        </div>
    </div>

    <div class="col-3" style="flex: 0 0 65%; max-width: 65%; padding-left:15px;">
        <div class="card">
            <div class="card-header">
                รายการ IP Pools ทั้งหมด (<?php echo count($pools); ?>)
            </div>
            <div style="overflow-x:auto;">
                <table>
                    <thead>
                        <tr>
                            <th>ชื่อ (Name)</th>
                            <th>ช่วงไอพี (Ranges)</th>
                            <th>Next Pool</th>
                            <th>จัดการ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i = 0;
                        foreach ($pools as $pool) {
                            $i++;
                            $id = $pool['.id'];
                            $id_safe = bin2hex($id);
                            
                            $name = $pool['name'];
                            $ranges = isset($pool['ranges']) ? $pool['ranges'] : '-';
                            $next = isset($pool['next-pool']) ? $pool['next-pool'] : '-';

                            echo "<tr>";
                            echo "<td><b>$name</b></td>";
                            echo "<td style='font-family:monospace; color:#2c3e50;'>$ranges</td>";
                            
                            // แต่งสี Next Pool
                            if($next != '-') {
                                echo "<td><span class='badge' style='background:#f39c12;'>$next</span></td>";
                            } else {
                                echo "<td style='color:#ccc;'>-</td>";
                            }

                            echo "<td>";
                            ?>
                            <form method="post" id="del-pool-<?php echo $i; ?>">
                                <input type="hidden" name="del_id" value="<?php echo $id_safe; ?>">
                                <input type="hidden" name="btn_delete" value="yes">
                                <button type="button" onclick="confirmDeletePool(<?php echo $i; ?>)" class="btn btn-danger" style="padding:5px 10px; font-size:12px;">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                            <?php
                            echo "</td>";
                            echo "</tr>";
                        }
                        
                        if(count($pools) == 0) {
                            echo "<tr><td colspan='4' style='text-align:center; padding:20px; color:#999;'>-- ไม่พบข้อมูล Pool --</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    function confirmDeletePool(index) {
        Swal.fire({
            title: 'ลบ IP Pool?',
            text: "ระวัง! หาก Pool นี้ถูกใช้งานอยู่ ระบบอาจมีปัญหาได้",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            confirmButtonText: 'ยืนยันลบ',
            cancelButtonText: 'ยกเลิก'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('del-pool-' + index).submit();
            }
        })
    }
</script>