<?php
// view/add_router.php
require_once 'config/database.php';

if (isset($_POST['btn_save'])) {
    $name = $_POST['name'];
    $ip = $_POST['ip'];
    $user = $_POST['user'];
    $pass = $_POST['pass']; // ควรเข้ารหัสใน Production
    $owner = $_SESSION['cloud_user_id'];

    $sql = "INSERT INTO tb_routers (owner_id, router_name, ip_address, api_user, api_pass) VALUES (:owner, :name, :ip, :user, :pass)";
    $stmt = $pdo->prepare($sql);
    if ($stmt->execute(['owner'=>$owner, 'name'=>$name, 'ip'=>$ip, 'user'=>$user, 'pass'=>$pass])) {
        header("Location: index.php?page=router_list");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>Add Router</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body { background: #f4f6f9; font-family: 'Sarabun', sans-serif; display:flex; justify-content:center; padding-top:50px;}
        .card { width: 400px; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
        input { width: 100%; padding: 10px; margin-bottom: 15px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box;}
        button { width: 100%; padding: 10px; background: #2ecc71; color: white; border: none; cursor: pointer; border-radius: 4px; font-weight:bold;}
    </style>
</head>
<body>
    <div class="card">
        <h3><i class="fas fa-plus-circle"></i> เพิ่ม Router ใหม่</h3>
        <form method="post">
            <label>ชื่อเรียก (เช่น หอพัก A)</label>
            <input type="text" name="name" required>
            
            <label>IP Address / Domain (DDNS)</label>
            <input type="text" name="ip" required>
            
            <label>API Username</label>
            <input type="text" name="user" required>
            
            <label>API Password</label>
            <input type="password" name="pass">
            
            <button type="submit" name="btn_save">บันทึกข้อมูล</button>
            <a href="index.php?page=router_list" style="display:block; text-align:center; margin-top:15px; text-decoration:none; color:#777;">ย้อนกลับ</a>
        </form>
    </div>
</body>
</html>