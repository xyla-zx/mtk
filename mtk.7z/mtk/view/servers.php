<?php
// view/servers.php

// -- 1. สั่งแก้ไข Server --
if (isset($_POST['btn_save'])) {
    $id_hex = $_POST['edit_id'];
    $real_id = hex2bin($id_hex);
    
    $name = $_POST['name'];
    $interface = $_POST['interface'];
    $pool = $_POST['pool'];
    $profile = $_POST['profile'];

    if ($API->connect($ip_router, $user_router, $pass_router)) {
        $API->comm("/ip/hotspot/set", array(
            ".id"           => $real_id,
            "name"          => $name,
            "interface"     => $interface,
            "address-pool"  => $pool,
            "profile"       => $profile
        ));
        $API->disconnect();
        
        $_SESSION['swal_icon'] = 'success';
        $_SESSION['swal_title'] = 'บันทึกสำเร็จ';
        $_SESSION['swal_text'] = 'แก้ไขการตั้งค่า Server เรียบร้อย';
        header("Location: index.php?page=servers");
        exit;
    }
}

// -- 2. สั่งเปิด/ปิด (Toggle) --
if (isset($_POST['btn_toggle'])) {
    $id_hex = $_POST['toggle_id'];
    $real_id = hex2bin($id_hex);
    $state = $_POST['current_state']; // true=disabled
    $cmd = ($state == 'true') ? 'enable' : 'disable';

    if ($API->connect($ip_router, $user_router, $pass_router)) {
        $API->comm("/ip/hotspot/" . $cmd, array(".id" => $real_id));
        $API->disconnect();
        header("Location: index.php?page=servers");
        exit;
    }
}

// -- 3. ดึงข้อมูลจำเป็น (Servers, Interfaces, Pools, Profiles) --
$servers = [];
$interfaces = [];
$pools = [];
$profiles = [];

if ($API->connect($ip_router, $user_router, $pass_router)) {
    $servers = $API->comm("/ip/hotspot/print");
    $interfaces = $API->comm("/interface/print"); // เอาไว้เลือกพอร์ต
    $pools = $API->comm("/ip/pool/print"); // เอาไว้เลือกวง IP
    $profiles = $API->comm("/ip/hotspot/profile/print"); // เอาไว้เลือกหน้าเว็บ
    $API->disconnect();
}
?>

<div class="card">
    <div class="card-header">
        <h3><i class="fas fa-broadcast-tower"></i> จัดการจุดปล่อยสัญญาณ (Hotspot Servers)</h3>
        <small class="text-muted">ตั้งค่า Interface และ Profile ของระบบ Hotspot</small>
    </div>

    <div style="overflow-x:auto;">
        <table>
            <thead>
                <tr>
                    <th>ชื่อ Server</th>
                    <th>พอร์ต (Interface)</th>
                    <th>วงไอพี (Address Pool)</th>
                    <th>โปรไฟล์ (Profile)</th>
                    <th>สถานะ</th>
                    <th>จัดการ</th>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($servers as $s) {
                    $s_id = $s['.id'];
                    $s_id_safe = bin2hex($s_id);
                    
                    $name = $s['name'];
                    $interface = isset($s['interface']) ? $s['interface'] : '-';
                    $pool = isset($s['address-pool']) ? $s['address-pool'] : 'none';
                    $profile = isset($s['profile']) ? $s['profile'] : 'default';
                    $disabled = $s['disabled']; // true / false

                    // สถานะ
                    $status_badge = ($disabled == 'true') 
                        ? "<span class='badge' style='background:#95a5a6;'>Disabled (ปิด)</span>" 
                        : "<span class='badge' style='background:#27ae60;'>Running (เปิด)</span>";

                    echo "<tr>";
                    echo "<td><b>$name</b></td>";
                    echo "<td><i class='fas fa-ethernet' style='color:#555;'></i> $interface</td>";
                    echo "<td>$pool</td>";
                    echo "<td><span class='badge' style='background:#3498db;'>$profile</span></td>";
                    echo "<td>$status_badge</td>";
                    echo "<td>";
                    
                    // ปุ่ม Toggle
                    $btn_icon = ($disabled == 'true') ? 'fa-play' : 'fa-pause';
                    $btn_cls = ($disabled == 'true') ? 'btn-success' : 'btn-warning';
                    ?>
                    
                    <div style="display:flex; gap:5px;">
                        <form method="post" style="margin:0;">
                            <input type="hidden" name="toggle_id" value="<?php echo $s_id_safe; ?>">
                            <input type="hidden" name="current_state" value="<?php echo $disabled; ?>">
                            <input type="hidden" name="btn_toggle" value="yes">
                            <button type="submit" class="btn <?php echo $btn_cls; ?>" style="padding:5px 8px; font-size:12px;">
                                <i class="fas <?php echo $btn_icon; ?>"></i>
                            </button>
                        </form>

                        <button type="button" onclick="openServerModal('<?php echo $s_id_safe; ?>', '<?php echo $name; ?>', '<?php echo $interface; ?>', '<?php echo $pool; ?>', '<?php echo $profile; ?>')" class="btn btn-primary" style="padding:5px 8px; font-size:12px;">
                            <i class="fas fa-edit"></i>
                        </button>
                    </div>

                    <?php
                    echo "</td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<div id="serverModal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:9999; justify-content:center; align-items:center;">
    <div style="background:white; width:90%; max-width:500px; padding:20px; border-radius:10px; box-shadow:0 5px 15px rgba(0,0,0,0.3); animation: slideDown 0.3s;">
        
        <div style="display:flex; justify-content:space-between; margin-bottom:15px; border-bottom:1px solid #eee; padding-bottom:10px;">
            <h4 style="margin:0;">✏️ แก้ไข Server: <span id="modal_title" style="color:#2980b9;"></span></h4>
            <button onclick="closeServerModal()" style="border:none; background:none; font-size:20px; cursor:pointer;">&times;</button>
        </div>

        <form method="post">
            <input type="hidden" name="edit_id" id="modal_id">
            
            <div class="form-group">
                <label>ชื่อ Server (Name):</label>
                <input type="text" name="name" id="modal_name" class="form-control" required>
            </div>

            <div class="form-group">
                <label>อินเทอร์เฟซ (Interface):</label>
                <select name="interface" id="modal_interface" class="form-control">
                    <?php foreach($interfaces as $iface): ?>
                        <option value="<?php echo $iface['name']; ?>"><?php echo $iface['name']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label>วงไอพี (Address Pool):</label>
                <select name="pool" id="modal_pool" class="form-control">
                    <option value="none">-- ไม่มี (None) --</option>
                    <?php foreach($pools as $pl): ?>
                        <option value="<?php echo $pl['name']; ?>"><?php echo $pl['name']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label>โปรไฟล์เซิร์ฟเวอร์ (Server Profile):</label>
                <select name="profile" id="modal_profile" class="form-control">
                    <?php foreach($profiles as $pf): ?>
                        <option value="<?php echo $pf['name']; ?>"><?php echo $pf['name']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <hr>
            <div style="text-align:right;">
                <button type="button" onclick="closeServerModal()" class="btn" style="background:#ccc; color:#333; margin-right:5px;">ยกเลิก</button>
                <button type="submit" name="btn_save" class="btn btn-primary">บันทึก</button>
            </div>
        </form>
    </div>
</div>

<style>
    @keyframes slideDown { from { transform: translateY(-50px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
</style>

<script>
    function openServerModal(id, name, iface, pool, profile) {
        document.getElementById('serverModal').style.display = 'flex';
        document.getElementById('modal_id').value = id;
        document.getElementById('modal_name').value = name;
        document.getElementById('modal_title').innerText = name;
        
        // เลือกค่าใน Dropdown ให้ตรง
        document.getElementById('modal_interface').value = iface;
        document.getElementById('modal_pool').value = pool;
        document.getElementById('modal_profile').value = profile;
    }

    function closeServerModal() {
        document.getElementById('serverModal').style.display = 'none';
    }
    
    window.onclick = function(event) {
        if (event.target == document.getElementById('serverModal')) {
            closeServerModal();
        }
    }
</script>