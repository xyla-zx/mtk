<?php
// view/backup.php

// -- 1. สั่งสร้าง Backup --
if (isset($_POST['btn_create'])) {
    $name = $_POST['backup_name'];
    // ถ้าไม่ตั้งชื่อ ให้ใช้ชื่อ Default (Auto-Time)
    if(empty($name)) $name = "backup-" . date("Ymd-His");

    if ($API->connect($ip_router, $user_router, $pass_router)) {
        // สั่ง Backup (คำสั่งนี้จะสร้างไฟล์ .backup ใน Router)
        $API->comm("/system/backup/save", array("name" => $name));
        $API->disconnect();
        
        $_SESSION['swal_icon'] = 'success';
        $_SESSION['swal_title'] = 'Backup สำเร็จ';
        $_SESSION['swal_text'] = 'สร้างไฟล์ ' . $name . '.backup เรียบร้อยแล้ว';
        header("Location: index.php?page=backup");
        exit;
    }
}

// -- 2. สั่งลบไฟล์ --
if (isset($_POST['btn_delete'])) {
    $id_hex = $_POST['del_id'];
    $real_id = hex2bin($id_hex);

    if ($API->connect($ip_router, $user_router, $pass_router)) {
        $API->comm("/file/remove", array(".id" => $real_id));
        $API->disconnect();
        
        $_SESSION['swal_icon'] = 'success';
        $_SESSION['swal_title'] = 'ลบสำเร็จ';
        $_SESSION['swal_text'] = 'ลบไฟล์ Backup เรียบร้อยแล้ว';
        header("Location: index.php?page=backup");
        exit;
    }
}

// -- 3. สั่ง Restore (กู้คืน) --
if (isset($_POST['btn_restore'])) {
    $filename = $_POST['restore_name'];

    if ($API->connect($ip_router, $user_router, $pass_router)) {
        // คำสั่ง Load Backup (Router จะ Reboot เองทันที)
        // เราใช้ dont-encrypt เพื่อความชัวร์ในบางรุ่น
        $API->comm("/system/backup/load", array("name" => $filename));
        $API->disconnect();
        
        // เคลียร์ Session เพราะ Router จะรีบูต
        session_destroy();
        echo "
        <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
        <script>
            Swal.fire({
                icon: 'info',
                title: 'กำลังกู้คืนระบบ...',
                text: 'Router กำลังรีบูตเพื่อคืนค่าเดิม กรุณารอสักครู่...',
                showConfirmButton: false,
                timer: 10000,
                willClose: () => { window.location = 'index.php'; }
            });
        </script>";
        exit;
    }
}

// -- 4. ดึงรายชื่อไฟล์ --
$backups = [];
if ($API->connect($ip_router, $user_router, $pass_router)) {
    // ดึงไฟล์ทั้งหมด แล้วค่อยมาคัดเฉพาะ .backup ใน PHP
    // หรือใช้ ?type=backup (แต่บางรุ่น type อาจไม่ใช่ backup เป๊ะๆ)
    $all_files = $API->comm("/file/print");
    $API->disconnect();

    // กรองเอาเฉพาะไฟล์ที่ลงท้ายด้วย .backup
    foreach ($all_files as $f) {
        if (isset($f['name']) && strpos($f['name'], '.backup') !== false) {
            $backups[] = $f;
        }
    }
    
    // เรียงจากใหม่ไปเก่า (Creation Time)
    $backups = array_reverse($backups);
}

function formatBytesFile($bytes, $precision = 2) { 
    $units = array('B', 'KB', 'MB', 'GB'); 
    $bytes = max($bytes, 0); 
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024)); 
    $pow = min($pow, count($units) - 1); 
    $bytes /= pow(1024, $pow); 
    return round($bytes, $precision) . ' ' . $units[$pow]; 
}
?>

<div class="row">
    <div class="col-3" style="flex: 0 0 35%; max-width: 35%;">
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-save"></i> สำรองข้อมูล (Create Backup)</h3>
            </div>
            <div class="card-body">
                <form method="post">
                    <div class="form-group">
                        <label>ตั้งชื่อไฟล์ Backup:</label>
                        <input type="text" name="backup_name" class="form-control" placeholder="เช่น before-change-ip">
                        <small class="text-muted">ถ้าไม่ใส่ จะใช้วันเวลาปัจจุบัน</small>
                    </div>
                    
                    <div style="background:#e3f2fd; padding:10px; border-radius:5px; font-size:13px; color:#0d47a1; margin-bottom:15px;">
                        <i class="fas fa-info-circle"></i> ไฟล์จะถูกเก็บไว้ในหน่วยความจำของ Router (.backup)
                    </div>

                    <button type="submit" name="btn_create" class="btn btn-primary" style="width:100%;">
                        <i class="fas fa-plus-circle"></i> สร้างไฟล์ Backup เดี๋ยวนี้
                    </button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-3" style="flex: 0 0 65%; max-width: 65%; padding-left:15px;">
        <div class="card">
            <div class="card-header">
                รายการไฟล์ Backup ในเครื่อง (<?php echo count($backups); ?>)
            </div>
            <div style="overflow-x:auto;">
                <table>
                    <thead>
                        <tr>
                            <th>ชื่อไฟล์</th>
                            <th>วันที่สร้าง</th>
                            <th>ขนาด</th>
                            <th>จัดการ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i = 0;
                        foreach ($backups as $b) {
                            $i++;
                            $b_id = $b['.id'];
                            $b_id_safe = bin2hex($b_id);
                            $name = $b['name'];
                            $size = isset($b['size']) ? formatBytesFile($b['size']) : '0 B';
                            $time = isset($b['creation-time']) ? $b['creation-time'] : '-';

                            echo "<tr>";
                            echo "<td><i class='fas fa-file-archive' style='color:#f39c12; margin-right:5px;'></i> <b>$name</b></td>";
                            echo "<td style='color:#666; font-size:13px;'>$time</td>";
                            echo "<td><span class='badge' style='background:#eee; color:#333;'>$size</span></td>";
                            echo "<td>";
                            ?>
                            <div style="display:flex; gap:5px;">
                                <form method="post" id="restore-<?php echo $i; ?>" style="margin:0;">
                                    <input type="hidden" name="restore_name" value="<?php echo $name; ?>">
                                    <input type="hidden" name="btn_restore" value="yes">
                                    <button type="button" onclick="confirmRestore(<?php echo $i; ?>, '<?php echo $name; ?>')" class="btn" style="background:#27ae60; color:white; padding:5px 10px; font-size:12px;" title="กู้คืนค่าจากไฟล์นี้">
                                        <i class="fas fa-undo"></i>
                                    </button>
                                </form>

                                <form method="post" id="del-bak-<?php echo $i; ?>" style="margin:0;">
                                    <input type="hidden" name="del_id" value="<?php echo $b_id_safe; ?>">
                                    <input type="hidden" name="btn_delete" value="yes">
                                    <button type="button" onclick="confirmDeleteBackup(<?php echo $i; ?>)" class="btn btn-danger" style="padding:5px 10px; font-size:12px;">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                            <?php
                            echo "</td>";
                            echo "</tr>";
                        }
                        
                        if(count($backups) == 0) {
                            echo "<tr><td colspan='4' style='text-align:center; padding:20px; color:#999;'>-- ไม่พบไฟล์ Backup --</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    function confirmDeleteBackup(index) {
        Swal.fire({
            title: 'ลบไฟล์นี้?',
            text: "ไฟล์นี้จะหายไปจาก Router ถาวร",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            confirmButtonText: 'ลบเลย'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('del-bak-' + index).submit();
            }
        })
    }

    function confirmRestore(index, name) {
        Swal.fire({
            title: '⚠️ ยืนยันการกู้คืนระบบ?',
            text: "Router จะทำการโหลดค่าจากไฟล์ '" + name + "' และจะรีบูตตัวเองทันที! การตั้งค่าปัจจุบันอาจหายไป",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#27ae60',
            confirmButtonText: 'ยืนยัน Restore',
            cancelButtonText: 'ยกเลิก'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('restore-' + index).submit();
            }
        })
    }
</script>