<?php
// view/list_users.php

// -- ส่วนจัดการคำสั่ง "ลบ" --
// เช็คว่ามีการส่งค่า btn_delete มาหรือไม่
if (isset($_POST['btn_delete'])) {
    if ($API->connect($ip_router, $user_router, $pass_router)) {
        $id_to_delete = $_POST['delete_id'];
        
        // ส่งคำสั่งลบ (RouterOS v7 รองรับการลบด้วย .id แบบนี้ปกติครับ)
        $API->comm("/ip/hotspot/user/remove", array(".id" => $id_to_delete));
        $API->disconnect();
        
        // ✅ ส่งค่าเข้า Session Alert
        $_SESSION['swal_icon'] = 'success';
        $_SESSION['swal_title'] = 'ลบเรียบร้อย';
        $_SESSION['swal_text'] = 'ผู้ใช้งานถูกลบออกจากระบบแล้ว';
        
        // Refresh หน้าจอ
        header("Location: index.php?page=list_users");
        exit;
    }
}

// -- ส่วนดึงข้อมูล --
$users = [];
if ($API->connect($ip_router, $user_router, $pass_router)) {
    $users = $API->comm("/ip/hotspot/user/print");
    $API->disconnect();
}
?>

<div class="card">
<div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
    <h3><i class="fas fa-address-book"></i> รายชื่อผู้ใช้งานทั้งหมด (<?php echo count($users); ?>)</h3>
    
    <div>
        <a href="export.php?mode=all" target="_blank" class="btn" style="background:#27ae60; color:white; text-decoration:none; margin-right:5px; font-size:14px;">
            <i class="fas fa-file-download"></i> Export ทั้งหมด
        </a>

        <a href="index.php?page=add_user" class="btn btn-primary" style="text-decoration:none; font-size:14px;">
            <i class="fas fa-plus-circle"></i> เพิ่มคนใหม่
        </a>
    </div>
</div>

    <div style="overflow-x:auto;">
        <table>
            <thead>
                <tr>
                    <th>ลำดับ</th>
                    <th>ชื่อผู้ใช้</th>
                    <th>รหัสผ่าน</th>
                    <th>แพ็กเกจ</th>
                    <th>หมายเหตุ</th>
                    <th width="10%">จัดการ</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $users = array_reverse($users); // เรียงใหม่ไปเก่า
                
                if (count($users) > 0) {
                    $i = 0; // ตัวนับลำดับ
                    
                    foreach ($users as $u) {
                        $i++; 
                        
                        $u_name = isset($u['name']) ? $u['name'] : '-';
                        $u_pass = isset($u['password']) ? $u['password'] : '';
                        $u_profile = isset($u['profile']) ? $u['profile'] : '-';
                        $u_comment = isset($u['comment']) ? $u['comment'] : '';
                        $u_id = $u['.id']; // ID จริงของ MikroTik

                        // เช็คสถานะ Disabled
                        $row_style = (isset($u['disabled']) && $u['disabled'] == 'true') ? "background:#ffecec; color:#999;" : "";

                        echo "<tr style='{$row_style}'>";
                        echo "<td>{$i}</td>";
                        echo "<td><b>{$u_name}</b></td>";
                        echo "<td>{$u_pass}</td>";
                        echo "<td><span class='badge'>{$u_profile}</span></td>";
                        echo "<td>{$u_comment}</td>";
                        echo "<td>";
                        ?>
                        
                        <form method="post" id="del-user-form-<?php echo $i; ?>">
                            <input type="hidden" name="delete_id" value="<?php echo $u_id; ?>">
                            <input type="hidden" name="btn_delete" value="yes">
                            
                            <button type="button" onclick="confirmDeleteUser(<?php echo $i; ?>)" class="btn btn-danger" style="padding:5px 10px; font-size:12px;">
                                <i class="fas fa-trash"></i> ลบ
                            </button>
                        </form>

                        <?php
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='6' style='text-align:center; padding:20px; color:#999;'>-- ยังไม่มีข้อมูล User ในระบบ --</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    // ✅ เปลี่ยนชื่อฟังก์ชันเป็น confirmDeleteUser (ไม่ให้ซ้ำกับ Footer)
    function confirmDeleteUser(index) {
        Swal.fire({
            title: 'ยืนยันการลบ?',
            text: "คุณแน่ใจหรือไม่ที่จะลบ User นี้?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'ใช่, ลบเลย!',
            cancelButtonText: 'ยกเลิก'
        }).then((result) => {
            if (result.isConfirmed) {
                // สั่ง Submit Form ตามหมายเลข index ที่ส่งมา
                // ต้องตรงกับ ID ใน <form> ด้านบน
                document.getElementById('del-user-form-' + index).submit();
            }
        })
    }
</script>