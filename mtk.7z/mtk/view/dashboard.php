<?php
// view/dashboard.php

// 1. คำนวณยอดขายรวม (Total Income)
$total_money = 0;
$price_file = 'config/prices.json';
$local_prices = [];

if (file_exists($price_file)) {
    $local_prices = json_decode(file_get_contents($price_file), true);
}

// เชื่อมต่อครั้งเดียวเพื่อดึงข้อมูลเริ่มต้น (Initial Data)
$initial_active = 0;
$initial_users = 0;
$logs = [];

if ($API->connect($ip_router, $user_router, $pass_router)) {
    // Users & Active
    $all_users = $API->comm("/ip/hotspot/user/print");
    $initial_users = count($all_users);
    $act = $API->comm("/ip/hotspot/active/print", array("count-only"=> ""));
    $initial_active = $act;

    // คำนวณเงินจากราคาที่เราบันทึกไว้
    foreach ($all_users as $u) {
        $p_name = isset($u['profile']) ? $u['profile'] : '';
        if (isset($local_prices[$p_name])) {
            $total_money += intval($local_prices[$p_name]);
        }
    }

    // ดึง Log ล่าสุด 5 บรรทัด
    $logs = $API->comm("/log/print", array("?topics" => "hotspot,info", "count" => 5));
    $logs = array_reverse($logs);

    $API->disconnect();
}
?>

<style>
    /* --- Layout System (Grid) --- */
    .dashboard-container {
        display: flex;
        flex-direction: column;
        gap: 20px;
        max-width: 100%;
        overflow-x: hidden; /* ป้องกันแนวนอนล้น */
    }

    /* แถวบน: สถิติ 4 ช่อง */
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 20px;
    }

    /* แถวกลาง: กราฟ + System Info */
    .main-grid {
        display: grid;
        /* แบ่งสัดส่วน: กราฟ 3 ส่วน / ข้อมูลเครื่อง 1 ส่วน */
        grid-template-columns: 3fr 1fr; 
        gap: 20px;
        align-items: stretch;
    }

    /* --- Card Style --- */
    .dash-card {
        background: #fff;
        border-radius: 12px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.02), 0 10px 20px rgba(0,0,0,0.04);
        padding: 20px;
        display: flex;
        flex-direction: column;
        border: 1px solid #f1f1f1;
        
        /* ✅ แก้บั๊กกราฟล้น: สำคัญมากสำหรับ CSS Grid */
        min-width: 0;
    }

    /* Stat Items (กล่อง 4 อันบน) */
    .stat-item {
        display: flex;
        flex-direction: row;
        align-items: center;
        gap: 15px;
    }
    .stat-icon-box {
        width: 50px; height: 50px;
        border-radius: 12px;
        display: flex; align-items: center; justify-content: center;
        font-size: 20px;
        flex-shrink: 0;
    }
    .stat-text {
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
    }
    .stat-text h3 { margin: 0; font-size: 24px; font-weight: 700; color: #2d3436; }
    .stat-text p { margin: 0; font-size: 13px; color: #636e72; font-weight: 500; }

    /* Theme Colors */
    .bg-soft-green { background: #e3f9e5; color: #27ae60; }
    .bg-soft-blue { background: #e3f2fd; color: #3498db; }
    .bg-soft-orange { background: #fff3e0; color: #f39c12; }
    .bg-soft-red { background: #fce4ec; color: #e91e63; }

    /* --- Graph & System Section --- */
    .card-header {
        display: flex; justify-content: space-between; align-items: center;
        margin-bottom: 20px; padding-bottom: 15px; border-bottom: 1px solid #f5f5f5;
    }
    .card-title { font-size: 16px; font-weight: 600; color: #2d3436; display: flex; align-items: center; gap: 10px; }
    
    /* System Health Progress Bars */
    .health-container { display: flex; flex-direction: column; gap: 15px; }
    .res-row { margin-bottom: 5px; }
    .res-meta { display: flex; justify-content: space-between; font-size: 13px; margin-bottom: 5px; color: #636e72; }
    .progress-track { background: #f1f2f6; height: 8px; border-radius: 4px; overflow: hidden; }
    .progress-fill { height: 100%; border-radius: 4px; transition: width 0.5s ease; }

    /* Device Info Footer */
    .device-info {
        background: #f8f9fa; padding: 15px; border-radius: 8px;
        font-size: 12px; color: #636e72; margin-top: 20px;
    }
    .device-info div { margin-bottom: 4px; display: flex; justify-content: space-between; }

    /* --- Logs Table --- */
    .log-table { width: 100%; border-collapse: collapse; font-size: 13px; table-layout: fixed; }
    .log-table th { text-align: left; padding: 12px; background: #f8f9fa; color: #636e72; font-weight: 600; border-bottom: 2px solid #eee; }
    .log-table td { padding: 10px 12px; border-bottom: 1px solid #f5f5f5; color: #2d3436; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .log-table tr:last-child td { border-bottom: none; }
    .log-time { color: #999; font-family: monospace; width: 150px; }

    /* --- Responsive (ปรับหน้าจอให้ไม่ซ้อน) --- */
    @media (max-width: 1400px) {
        .stats-grid { grid-template-columns: repeat(2, 1fr); }
        .main-grid { grid-template-columns: 2fr 1fr; }
    }
    @media (max-width: 992px) {
        /* จอ Tablet หรือเล็กกว่า: ยุบ Grid กลางเป็นคอลัมน์เดียว */
        .main-grid { grid-template-columns: 1fr; } 
    }
    @media (max-width: 576px) {
        /* จอมือถือ: ทุกอย่างเรียงเดี่ยว */
        .stats-grid { grid-template-columns: 1fr; }
        .stat-item { padding: 15px; }
    }
</style>

<div class="dashboard-container">

    <div style="display: flex; justify-content: space-between; align-items: center;">
        <h2 style="margin:0; color:#2d3436;"><i class="fas fa-th-large"></i> Dashboard</h2>
        <div style="font-size:13px; color:#636e72; background:#fff; padding:5px 15px; border-radius:20px; border:1px solid #eee;">
            <span id="api-status"><i class="fas fa-circle" style="color:orange; font-size:10px;"></i> Connecting...</span>
            <span style="margin:0 10px; color:#ddd;">|</span>
            Server: <b><?php echo $_SESSION['router_ip']; ?></b>
        </div>
    </div>

    <div class="stats-grid">
        <div class="dash-card stat-item">
            <div class="stat-text">
                <p>Online Users</p>
                <h3 id="val-active"><?php echo $initial_active; ?></h3>
            </div>
            <div class="stat-icon-box bg-soft-green"><i class="fas fa-wifi"></i></div>
        </div>
        <div class="dash-card stat-item">
            <div class="stat-text">
                <p>Total Users</p>
                <h3 id="val-users"><?php echo $initial_users; ?></h3>
            </div>
            <div class="stat-icon-box bg-soft-blue"><i class="fas fa-users"></i></div>
        </div>
        <div class="dash-card stat-item">
            <div class="stat-text">
                <p>Total Income</p>
                <h3 style="color:#f39c12;"><?php echo number_format($total_money); ?></h3>
            </div>
            <div class="stat-icon-box bg-soft-orange"><i class="fas fa-coins"></i></div>
        </div>
        <div class="dash-card stat-item">
            <div class="stat-text">
                <p>Uptime</p>
                <h3 id="val-uptime" style="font-size:18px;">...</h3>
            </div>
            <div class="stat-icon-box bg-soft-red"><i class="fas fa-clock"></i></div>
        </div>
    </div>

    <div class="main-grid">
        
        <div class="dash-card">
            <div class="card-header">
                <div class="card-title"><i class="fas fa-chart-area" style="color:#3498db;"></i> Real-time Traffic</div>
                <small id="traffic-speed" style="font-family:monospace; color:#2980b9; background:#e3f2fd; padding:3px 8px; border-radius:4px;">0 bps</small>
            </div>
            <div id="trafficChart" style="width:100%; height:320px;"></div>
        </div>

        <div class="dash-card">
            <div class="card-header">
                <div class="card-title"><i class="fas fa-server" style="color:#636e72;"></i> System Health</div>
                <div id="cpu-badge" style="font-size:11px; background:#eee; padding:2px 6px; border-radius:4px;">CPU: 0%</div>
            </div>
            
            <div class="health-container">
                <div class="res-row">
                    <div class="res-meta"><span>CPU Load</span> <b id="cpu-percent">0%</b></div>
                    <div class="progress-track"><div id="bar-cpu" class="progress-fill" style="width:0%; background:linear-gradient(90deg, #ff9966, #ff5e62);"></div></div>
                </div>
                <div class="res-row">
                    <div class="res-meta"><span>RAM Usage</span> <span id="ram-text">...</span></div>
                    <div class="progress-track"><div id="bar-ram" class="progress-fill" style="width:0%; background:linear-gradient(90deg, #56ab2f, #a8e063);"></div></div>
                </div>
                <div class="res-row">
                    <div class="res-meta"><span>HDD Usage</span> <span id="hdd-text">...</span></div>
                    <div class="progress-track"><div id="bar-hdd" class="progress-fill" style="width:0%; background:linear-gradient(90deg, #4568dc, #b06ab3);"></div></div>
                </div>

                <div class="device-info">
                    <div><span>Model:</span> <b id="val-model">...</b></div>
                    <div><span>Version:</span> <b id="val-version">...</b></div>
                    <div><span>Arch:</span> <span id="val-arch">...</span></div>
                </div>
            </div>
        </div>
    </div>

    <div class="dash-card" style="padding:0; overflow:hidden;">
        <div class="card-header" style="margin:20px 20px 0; border-bottom:none;">
            <div class="card-title"><i class="fas fa-history" style="color:#636e72;"></i> Recent Logs (ล่าสุด)</div>
            <a href="index.php?page=log" style="font-size:13px; text-decoration:none; color:#3498db;">ดูทั้งหมด &rarr;</a>
        </div>
        <div style="overflow-x:auto;">
            <table class="log-table">
                <thead>
                    <tr>
                        <th width="160">Time</th>
                        <th>Message</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($logs) > 0): ?>
                        <?php foreach($logs as $log): 
                            $msg = isset($log['message']) ? $log['message'] : '';
                            $time = isset($log['time']) ? $log['time'] : '';
                            $color = "#2d3436";
                            if(strpos($msg, 'logged in')) $color = "#27ae60";
                            if(strpos($msg, 'logged out')) $color = "#e67e22";
                            if(strpos($msg, 'failed') || strpos($msg, 'error')) $color = "#c0392b";
                        ?>
                        <tr>
                            <td class="log-time"><?php echo $time; ?></td>
                            <td style="color:<?php echo $color; ?>;"><?php echo $msg; ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="2" style="text-align:center; padding:20px; color:#999;">-- ไม่มีข้อมูล Log --</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://code.highcharts.com/highcharts.js"></script>

<script>
    var chart;

    // --- Format Speed Helper ---
    function formatSpeed(bytes) {
        var sizes = ['bps', 'Kbps', 'Mbps', 'Gbps'];
        if (bytes == 0) return '0 bps';
        var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
        return Math.round(bytes / Math.pow(1024, i), 2) + ' ' + sizes[i];
    }

    // --- 1. Load Traffic (AJAX) ---
    function requestTrafficData() {
        $.ajax({
            url: 'get/get_traffic.php',
            success: function(point) {
                var series_rx = chart.series[0];
                var series_tx = chart.series[1];
                var x = (new Date()).getTime();
                
                // Shift data points if > 20
                var shift_rx = series_rx.data.length > 20;
                series_rx.addPoint([x, point.rx], true, shift_rx);
                var shift_tx = series_tx.data.length > 20;
                series_tx.addPoint([x, point.tx], true, shift_tx);
                
                // Update Text
                $("#traffic-speed").html('<span style="color:#27ae60">▼ ' + formatSpeed(point.rx) + '</span> &nbsp; <span style="color:#2980b9">▲ ' + formatSpeed(point.tx) + '</span>');
                
                setTimeout(requestTrafficData, 3000);
            },
            cache: false
        });
    }

    // --- 2. Load System Stats (AJAX) ---
    function loadSystemStats() {
        $.ajax({
            url: "get/get_system_health.php",
            type: "GET",
            dataType: "json",
            success: function(data) {
                if(data.status === 'success') {
                    $("#val-uptime").text(data.uptime);
                    $("#val-active").text(data.active);
                    
                    $("#val-model").text(data.board_name);
                    $("#val-version").text(data.version);
                    $("#val-arch").text(data.arch);
                    
                    $("#cpu-percent").text(data.cpu_load + "%");
                    $("#cpu-badge").text("CPU: " + data.cpu_load + "%");
                    $("#bar-cpu").css("width", data.cpu_load + "%");

                    $("#ram-text").text(data.mem_percent + "%");
                    $("#bar-ram").css("width", data.mem_percent + "%");

                    $("#hdd-text").text(data.hdd_percent + "%");
                    $("#bar-hdd").css("width", data.hdd_percent + "%");

                    $("#api-status").html('<i class="fas fa-circle" style="color:#27ae60; font-size:10px;"></i> Connected');
                }
            },
            error: function() {
                $("#api-status").html('<i class="fas fa-circle" style="color:#c0392b; font-size:10px;"></i> Reconnecting...');
            }
        });
    }

    $(document).ready(function() {
        // Init Highcharts (Clean Style)
        Highcharts.setOptions({ global: { useUTC: false } });
        chart = new Highcharts.Chart({
            chart: {
                renderTo: 'trafficChart',
                type: 'areaspline',
                events: { load: requestTrafficData },
                backgroundColor: 'transparent',
                style: { fontFamily: "'Sarabun', sans-serif" },
                marginTop: 20
            },
            title: { text: null },
            xAxis: { type: 'datetime', tickPixelInterval: 150, maxZoom: 20 * 1000, visible: false }, 
            yAxis: { title: { text: null }, gridLineColor: '#f5f5f5', labels: { style: {color: '#b2bec3', fontSize:'10px'} } },
            series: [
                { name: 'DL', data: [], color: '#2ecc71', lineWidth: 2, marker: { enabled: false }, fillOpacity: 0.2 },
                { name: 'UL', data: [], color: '#3498db', lineWidth: 2, marker: { enabled: false }, fillOpacity: 0.2 }
            ],
            credits: { enabled: false },
            legend: { enabled: false },
            tooltip: { shared: true, borderRadius: 8, backgroundColor: 'rgba(255,255,255,0.9)', shadow: true }
        });

        loadSystemStats();
        setInterval(loadSystemStats, 2000);
    });
</script>