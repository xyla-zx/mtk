<?php
// view/queues.php

// -- สั่งลบคิว (Reset Queue) --
if (isset($_POST['btn_delete'])) {
    $id_hex = $_POST['del_id'];
    $real_id = hex2bin($id_hex);

    if ($API->connect($ip_router, $user_router, $pass_router)) {
        $API->comm("/queue/simple/remove", array(".id" => $real_id));
        $API->disconnect();
        
        $_SESSION['swal_icon'] = 'success';
        $_SESSION['swal_title'] = 'ลบสำเร็จ';
        $_SESSION['swal_text'] = 'รีเซ็ตคิวรายการนี้แล้ว';
        header("Location: index.php?page=queues");
        exit;
    }
}

// -- ดึงข้อมูล Queue --
$queues = [];
if ($API->connect($ip_router, $user_router, $pass_router)) {
    $queues = $API->comm("/queue/simple/print");
    $API->disconnect();
}

// ฟังก์ชันแปลงหน่วย (10M -> 10,000,000)
function parseSpeed($str) {
    // MikroTik format: upload/download (e.g. 5M/10M)
    // หรือค่าดิบที่เป็นตัวเลข (e.g. 5000000/10000000)
    return $str; 
}

function formatBits($bits) {
    if ($bits < 1000) return $bits . " bps";
    if ($bits < 1000000) return round($bits / 1000, 1) . " Kbps";
    return round($bits / 1000000, 1) . " Mbps";
}
?>

<div class="card">
    <div class="card-header" style="display:flex; justify-content:space-between; align-items:center;">
        <h3><i class="fas fa-tachometer-alt"></i> ตรวจสอบความเร็วรายคน (Simple Queues)</h3>
        <button onclick="window.location.reload();" class="btn btn-primary" style="font-size:14px;">
            <i class="fas fa-sync"></i> รีเฟรช (Refresh)
        </button>
    </div>

    <div style="overflow-x:auto;">
        <table>
            <thead>
                <tr>
                    <th width="20%">ชื่อ (User / Target)</th>
                    <th>ความเร็วสูงสุด (Max Limit)</th>
                    <th width="30%">การใช้งานจริง (Real-time Usage)</th>
                    <th width="10%">จัดการ</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $i = 0;
                foreach ($queues as $q) {
                    // ข้าม Queue ของระบบ (Hotspot Dummy)
                    if ($q['name'] == 'hs-microtik') continue;

                    $i++;
                    $id = $q['.id'];
                    $id_safe = bin2hex($id);
                    $name = $q['name'];
                    $target = isset($q['target']) ? $q['target'] : '-';
                    
                    // Max Limit (Upload/Download) เช่น 5M/10M
                    $max = isset($q['max-limit']) ? $q['max-limit'] : '0/0';
                    $max_parts = explode('/', $max);
                    $max_up = intval($max_parts[0]);
                    $max_down = isset($max_parts[1]) ? intval($max_parts[1]) : 0;

                    // Rate (Current Speed) เช่น 123k/4.5M
                    $rate = isset($q['rate']) ? $q['rate'] : '0/0';
                    $rate_parts = explode('/', $rate);
                    $cur_up = intval($rate_parts[0]);
                    $cur_down = isset($rate_parts[1]) ? intval($rate_parts[1]) : 0;

                    // คำนวณ % การใช้งาน (Download)
                    $percent_down = 0;
                    if ($max_down > 0) {
                        $percent_down = ($cur_down / $max_down) * 100;
                    }
                    
                    // เลือกสีหลอด (เขียว -> เหลือง -> แดง)
                    $bar_color = "#27ae60"; // เขียว
                    if ($percent_down > 50) $bar_color = "#f39c12"; // เหลือง
                    if ($percent_down > 80) $bar_color = "#c0392b"; // แดง

                    echo "<tr>";
                    echo "<td><b>$name</b><br><small style='color:gray; font-family:monospace;'>$target</small></td>";
                    
                    echo "<td>";
                    echo "<i class='fas fa-arrow-up' style='color:#3498db;'></i> " . formatBits($max_up) . " &nbsp; ";
                    echo "<i class='fas fa-arrow-down' style='color:#27ae60;'></i> " . formatBits($max_down);
                    echo "</td>";
                    
                    echo "<td>";
                    echo "<div style='display:flex; justify-content:space-between; font-size:12px; margin-bottom:2px;'>";
                    echo "<span>Cur: <b>".formatBits($cur_down)."</b></span>";
                    echo "<span>".number_format($percent_down, 0)."%</span>";
                    echo "</div>";
                    echo "<div style='background:#eee; height:8px; border-radius:4px; overflow:hidden;'>";
                    echo "<div style='width:{$percent_down}%; background:$bar_color; height:100%; transition:width 0.5s;'></div>";
                    echo "</div>";
                    echo "</td>";

                    echo "<td>";
                    ?>
                    <form method="post" id="del-queue-<?php echo $i; ?>">
                        <input type="hidden" name="del_id" value="<?php echo $id_safe; ?>">
                        <input type="hidden" name="btn_delete" value="yes">
                        <button type="button" onclick="confirmDeleteQueue(<?php echo $i; ?>)" class="btn btn-danger" style="padding:5px 10px; font-size:12px;">
                            <i class="fas fa-trash"></i>
                        </button>
                    </form>
                    <?php
                    echo "</td>";
                    echo "</tr>";
                }
                
                if($i == 0) {
                    echo "<tr><td colspan='4' style='text-align:center; padding:20px; color:#999;'>-- ไม่มีการใช้งาน (Queue ว่าง) --</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    function confirmDeleteQueue(index) {
        Swal.fire({
            title: 'ลบคิวนี้?',
            text: "หากลบแล้ว User อาจได้ความเร็วเต็มท่อชั่วคราว (จนกว่าจะ Login ใหม่)",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            confirmButtonText: 'ลบเลย'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('del-queue-' + index).submit();
            }
        })
    }
</script>