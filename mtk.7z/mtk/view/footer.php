</div> <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <script>
        // 1. เช็คว่า PHP ฝากข้อความมาแจ้งเตือนหรือไม่
        <?php if(isset($_SESSION['swal_icon']) && isset($_SESSION['swal_title'])): ?>
            Swal.fire({
                icon: '<?php echo $_SESSION['swal_icon']; ?>',
                title: '<?php echo $_SESSION['swal_title']; ?>',
                text: '<?php echo isset($_SESSION['swal_text']) ? $_SESSION['swal_text'] : ''; ?>',
                confirmButtonColor: '#3498db',
                confirmButtonText: 'ตกลง'
            });
            <?php
            // แสดงเสร็จแล้วลบทิ้งทันที
            unset($_SESSION['swal_icon']);
            unset($_SESSION['swal_title']);
            unset($_SESSION['swal_text']);
            ?>
        <?php endif; ?>

        // 2. ฟังก์ชันสำหรับปุ่มลบ (ให้หน้า list_users เรียกใช้)
        function confirmDelete(id) {
            Swal.fire({
                title: 'ยืนยันการลบ?',
                text: "คุณแน่ใจหรือไม่ที่จะลบรายการนี้? ทำแล้วย้อนกลับไม่ได้นะ",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'ใช่, ลบเลย!',
                cancelButtonText: 'ยกเลิก'
            }).then((result) => {
                if (result.isConfirmed) {
                    // ถ้ากดยืนยัน ให้ส่งค่า Form ที่มี id ตรงกัน
                    document.getElementById('del-form-' + id).submit();
                }
            })
        }
    </script>
</body>
</html>