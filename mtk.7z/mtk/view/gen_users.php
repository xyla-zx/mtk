<?php
// view/gen_users.php

// ฟังก์ชันสุ่มตัวอักษร
function randText($length) {
    $chars = "abcdefhkmnpqrstuvwxyz23456789";
    return substr(str_shuffle($chars), 0, $length);
}

$generated_users = [];

if ($API->connect($ip_router, $user_router, $pass_router)) {

    // ถ้ามีการกดปุ่มสร้าง (POST)
    if (isset($_POST['btn_gen'])) {
        $qty = $_POST['qty'];
        $prefix = $_POST['prefix'];
        $u_len = $_POST['u_len'];
        $profile = $_POST['profile'];
        $comment = $_POST['comment']; 
        
        for ($i = 0; $i < $qty; $i++) {
            $rand_u = randText($u_len);
            $rand_p = randText($u_len);
            $username = $prefix . $rand_u;
            $password = $rand_p;

            $API->comm("/ip/hotspot/user/add", array(
                "name"     => $username,
                "password" => $password,
                "profile"  => $profile,
                "comment"  => $comment
            ));

            $generated_users[] = [
                'user' => $username,
                'pass' => $password,
                'profile' => $profile
            ];
        }
        
        // บันทึก Session สำหรับไปหน้าพิมพ์
        $_SESSION['print_data'] = $generated_users;
        
        echo "<script>alert('✅ สร้างคูปอง $qty ใบ เรียบร้อยแล้ว!');</script>";
    }

    // ดึง Profile มาใส่ Dropdown
    $profiles = $API->comm("/ip/hotspot/user/profile/print");
    $API->disconnect();
}
?>

<div class="row">
    
    <div style="flex: 0 0 40%; max-width: 40%; padding-right: 15px; box-sizing: border-box;">
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-magic"></i> ตั้งค่าการสร้างคูปอง</h3>
            </div>
            
            <form method="post">
                <div class="form-group">
                    <label>จำนวนที่จะสร้าง (Qty):</label>
                    <input type="number" name="qty" value="10" min="1" max="100" required class="form-control">
                </div>

                <div class="form-group">
                    <label>คำนำหน้าชื่อ (Prefix):</label>
                    <input type="text" name="prefix" placeholder="เช่น WIFI-" class="form-control">
                    <small style="color:gray;">(ใส่หรือไม่ใส่ก็ได้)</small>
                </div>

                <div class="form-group">
                    <label>ความยาวตัวอักษรสุ่ม:</label>
                    <select name="u_len" class="form-control">
                        <option value="3">3 ตัวอักษร</option>
                        <option value="4" selected>4 ตัวอักษร</option>
                        <option value="5">5 ตัวอักษร</option>
                        <option value="6">6 ตัวอักษร</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>เลือกแพ็กเกจ (Profile):</label>
                    <select name="profile" class="form-control">
                        <?php
                        if(isset($profiles)){
                            foreach ($profiles as $p) {
                                echo "<option value='".$p['name']."'>".$p['name']."</option>";
                            }
                        }
                        ?>
                    </select>
                </div>

                <div class="form-group">
                    <label>หมายเหตุ (Comment):</label>
                    <input type="text" name="comment" value="Batch Gen <?php echo date('d/m/Y'); ?>" class="form-control">
                </div>

                <button type="submit" name="btn_gen" class="btn btn-primary" style="width:100%;">
                    <i class="fas fa-cogs"></i> เริ่มสร้างคูปอง
                </button>
            </form>
        </div>
    </div>

    <div style="flex: 0 0 60%; max-width: 60%; padding-left: 15px; box-sizing: border-box;">
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-list"></i> รายการที่สร้างล่าสุด</h3>
            </div>

            <?php if(count($generated_users) > 0): ?>
                <div style="background:#d4edda; color:#155724; padding:10px; margin-bottom:10px; border-radius:4px;">
                    สร้างเสร็จแล้ว <?php echo count($generated_users); ?> รายการ
                </div>
                
<div style="margin-bottom:15px; text-align:right;">
    <a href="export.php?mode=batch" target="_blank" class="btn" style="background:#27ae60; color:white; text-decoration:none; margin-right:5px;">
        <i class="fas fa-file-excel"></i> Export CSV
    </a>
    
    <a href="print_voucher.php" target="_blank" class="btn btn-primary">
        <i class="fas fa-print"></i> พิมพ์คูปอง (Thermal/A4)
    </a>
</div>

                <table style="font-size:14px;">
                    <thead>
                        <tr><th>#</th><th>Username</th><th>Password</th><th>Profile</th></tr>
                    </thead>
                    <tbody>
                        <?php 
                        $n=1;
                        foreach($generated_users as $u){
                            echo "<tr><td>{$n}</td><td><b>{$u['user']}</b></td><td>{$u['pass']}</td><td>{$u['profile']}</td></tr>";
                            $n++;
                        } 
                        ?>
                    </tbody>
                </table>

            <?php else: ?>
                <div style="text-align:center; padding:50px; color:#aaa;">
                    <i class="fas fa-box-open" style="font-size:40px; margin-bottom:10px;"></i><br>
                    ยังไม่ได้สร้างคูปอง<br>
                    กรอกข้อมูลฝั่งซ้ายแล้วกดปุ่มสร้างได้เลย
                </div>
            <?php endif; ?>
        </div>
    </div>

</div>