<?php
// view/log.php

// รับคำค้นหา
$search_query = isset($_GET['q']) ? $_GET['q'] : '';

// -- ส่วนดึงข้อมูล Log --
$logs = [];
if ($API->connect($ip_router, $user_router, $pass_router)) {
    
    // ดึงมา 200 บรรทัดเหมือนเดิม
    $all_logs = $API->comm("/log/print", array(
        "?topics" => "hotspot,info", 
        "count" => 200 
    ));
    
    $logs = array_reverse($all_logs); 
    $API->disconnect();
}
?>

<div class="card">
    <div class="card-header">
        <div class="row" style="align-items: center;">
            <div class="col-6">
                <h3 style="margin:0;"><i class="fas fa-history"></i> บันทึก (Logs)</h3>
            </div>
            <div class="col-6" style="text-align:right;">
                <form method="get" action="index.php" style="display:flex; justify-content:flex-end; gap:5px;">
                    <input type="hidden" name="page" value="log">
                    <input type="text" name="q" class="form-control" placeholder="ค้นหา... (เช่น error, admin)" value="<?php echo $search_query; ?>" style="width:200px; display:inline-block;">
                    
                    <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i></button>
                    
                    <?php if($search_query != ''): ?>
                        <a href="index.php?page=log" class="btn btn-danger" title="ล้างค่า"><i class="fas fa-times"></i></a>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </div>

    <div style="overflow-x:auto;">
        <table id="logTable">
            <thead>
                <tr>
                    <th width="20%">เวลา (Time)</th>
                    <th>รายละเอียด (Message)</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $count = 0;
                $found_data = false;

                foreach ($logs as $log) {
                    $topics = isset($log['topics']) ? $log['topics'] : '';
                    $msg  = isset($log['message']) ? $log['message'] : '-';
                    $time = isset($log['time']) ? $log['time'] : '-';

                    // 1. กรอง Topics พื้นฐาน
                    if (strpos($topics, 'hotspot') === false && strpos($topics, 'info') === false) {
                         continue; 
                    }

                    // 2. ระบบค้นหา (Search Logic)
                    // ถ้ามีการค้นหา และ คำค้นหา ไม่ปรากฏในข้อความ -> ข้าม
                    if ($search_query != '' && stripos($msg, $search_query) === false) {
                        continue;
                    }

                    $found_data = true;

                    // ตกแต่งสีข้อความ
                    $color = "#333";
                    $icon = "<i class='fas fa-info-circle' style='color:#aaa;'></i>";

                    if (strpos($msg, 'logged in') !== false) {
                        $color = "#27ae60"; // เขียว
                        $icon = "<i class='fas fa-sign-in-alt'></i>";
                    } 
                    elseif (strpos($msg, 'logged out') !== false) {
                        $color = "#e67e22"; // ส้ม
                        $icon = "<i class='fas fa-sign-out-alt'></i>";
                    }
                    elseif (strpos($msg, 'failed') !== false || strpos($msg, 'invalid') !== false) {
                        $color = "#c0392b"; // แดง
                        $icon = "<i class='fas fa-exclamation-circle'></i>";
                    }

                    echo "<tr>";
                    echo "<td><small>{$time}</small></td>";
                    echo "<td style='color:{$color};'>{$icon} {$msg}</td>";
                    echo "</tr>";
                    
                    $count++;
                    if($count >= 50) break; // แสดงผลลัพธ์สูงสุด 50 บรรทัดต่อหน้า
                }

                if (!$found_data) {
                    echo "<tr><td colspan='2' style='text-align:center; padding:30px; color:#999;'>";
                    echo "<i class='fas fa-search' style='font-size:30px; margin-bottom:10px;'></i><br>";
                    echo "ไม่พบข้อมูลที่ค้นหา";
                    echo "</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>