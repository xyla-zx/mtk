<?php
// view/about.php
?>

<style>
    .about-card {
        background: white;
        border-radius: 15px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        overflow: hidden;
        text-align: center;
        padding-bottom: 20px;
        border: 1px solid #eee;
    }
    
    .cover-photo {
        height: 180px;
        background: linear-gradient(135deg, #2c3e50, #3498db);
        position: relative;
    }
    
    .profile-photo {
        width: 160px;
        height: 160px;
        border-radius: 50%;
        border: 6px solid white;
        margin: -80px auto 20px; /* ดันขึ้นไปทับ cover */
        background-color: #fff;
        object-fit: cover;
        box-shadow: 0 8px 20px rgba(0,0,0,0.2);
    }

    .dev-name { font-size: 28px; font-weight: bold; color: #2c3e50; margin: 10px 0 0; }
    .dev-role { font-size: 18px; color: #3498db; font-weight: 600; margin-top: 8px; margin-bottom: 20px; }
    .dev-desc { color: #555; font-size: 14px; margin: 20px auto; max-width: 700px; line-height: 1.8; padding: 0 30px; }

    .info-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 25px;
        margin-top: 40px;
        text-align: left;
        padding: 0 40px;
    }

    .info-item {
        background: #f8f9fa;
        padding: 25px;
        border-radius: 10px;
        border-left: 5px solid #3498db;
        transition: all 0.3s ease;
    }
    .info-item:hover {
        background: #fff;
        box-shadow: 0 4px 15px rgba(52, 152, 219, 0.1);
        transform: translateY(-2px);
    }
    .info-item h4 { margin: 0 0 12px; color: #2c3e50; font-size: 16px; font-weight: 600; }
    .info-item p { margin: 0; color: #666; font-size: 14px; line-height: 1.5; }
    .info-item i { color: #3498db; margin-right: 10px; font-size: 18px; }

    /* Social Links */
    .social-links { margin-top: 35px; padding: 30px 0; border-top: 1px solid #eee; }
    .social-btn {
        display: inline-block; width: 45px; height: 45px; line-height: 45px;
        border-radius: 50%; background: #ecf0f1; color: #2c3e50;
        margin: 0 8px; transition: 0.3s; font-size: 18px; text-decoration: none;
    }
    .social-btn:hover { background: #3498db; color: white; transform: translateY(-4px); box-shadow: 0 6px 15px rgba(52, 152, 219, 0.3); }
</style>

<div class="row" style="justify-content: center;">
    <div class="col-3" style="flex: 0 0 80%; max-width: 80%;">
        
        <div class="about-card">
            <div class="cover-photo"></div>
            
            <img src="assets/img/profile.jpg" class="profile-photo" onerror="this.src='https://ui-avatars.com/api/?name=Mana+Chaisangkh&size=200&background=random';">
            
            <h2 class="dev-name">นายมานะ ฉายสังข์ (แชมป์)</h2>
            <div class="dev-role">Developer & Network Admin</div>
            
            <p class="dev-desc">
                โปรเจกต์นี้เป็นส่วนหนึ่งของการศึกษาในระดับประกาศนียบัตรวิชาชีพชั้นสูง (ปวส.)<br>
                สาขาวิชาเครือข่ายคอมพิวเตอร์และความปลอดภัย วิทยาลัยเทคนิคสัตหีบ<br>
                พัฒนาระบบบริหารจัดการ MikroTik Hotspot API ด้วยภาษา PHP
            </p>

            <div class="info-grid">
                <div class="info-item">
                    <h4><i class="fas fa-university"></i> สถาบันการศึกษา</h4>
                    <p>วิทยาลัยเทคนิคสัตหีบ (Sattahip Technical College)</p>
                </div>
                <div class="info-item">
                    <h4><i class="fas fa-graduation-cap"></i> สาขาวิชา</h4>
                    <p>เทคโนโลยีคอมพิวเตอร์ (Computer Networking & Security)</p>
                </div>
                <div class="info-item">
                    <h4><i class="fas fa-code"></i> ทักษะการพัฒนา</h4>
                    <p>PHP, MikroTik API, HTML/CSS, MySQL</p>
                </div>
                <div class="info-item">
                    <h4><i class="fas fa-envelope"></i> ติดต่อ</h4>
                    <p>manachaisangkh@gmail.com (ตัวอย่าง)</p>
                </div>
            </div>

            <div class="social-links">
                <a href="#" class="social-btn"><i class="fab fa-facebook-f"></i></a>
                <a href="#" class="social-btn"><i class="fab fa-line"></i></a>
                <a href="#" class="social-btn"><i class="fab fa-github"></i></a>
            </div>
        </div>

        <div style="text-align:center; margin-top:20px; color:#999; font-size:12px;">
            &copy; <?php echo date('Y'); ?> MikroTik Manager Project. All rights reserved.
        </div>

    </div>
</div>