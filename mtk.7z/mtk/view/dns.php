<?php
// view/dns.php

// -- 1. สั่งเพิ่ม DNS Static --
if (isset($_POST['btn_add'])) {
    $name = $_POST['name'];
    $address = $_POST['address'];
    $ttl = $_POST['ttl'];
    $comment = $_POST['comment'];

    if ($API->connect($ip_router, $user_router, $pass_router)) {
        $API->comm("/ip/dns/static/add", array(
            "name"    => $name,
            "address" => $address,
            "ttl"     => $ttl,
            "comment" => $comment
        ));
        $API->disconnect();
        
        $_SESSION['swal_icon'] = 'success';
        $_SESSION['swal_title'] = 'เพิ่มสำเร็จ';
        $_SESSION['swal_text'] = 'เพิ่ม DNS: ' . $name . ' ชี้ไปที่ ' . $address;
        header("Location: index.php?page=dns");
        exit;
    }
}

// -- 2. สั่งลบ DNS --
if (isset($_POST['btn_delete'])) {
    $id_hex = $_POST['del_id'];
    $real_id = hex2bin($id_hex);

    if ($API->connect($ip_router, $user_router, $pass_router)) {
        $API->comm("/ip/dns/static/remove", array(".id" => $real_id));
        $API->disconnect();
        
        $_SESSION['swal_icon'] = 'success';
        $_SESSION['swal_title'] = 'ลบสำเร็จ';
        $_SESSION['swal_text'] = 'ลบรายการ DNS เรียบร้อย';
        header("Location: index.php?page=dns");
        exit;
    }
}

// -- 3. ดึงข้อมูล --
$dns_list = [];
if ($API->connect($ip_router, $user_router, $pass_router)) {
    $dns_list = $API->comm("/ip/dns/static/print");
    $API->disconnect();
}
?>

<div class="row">
    <div class="col-3" style="flex: 0 0 35%; max-width: 35%;">
        
        <div class="card" style="margin-bottom:20px; background:#fff3cd; border:1px solid #ffeeba;">
            <div class="card-body" style="font-size:13px; color:#856404;">
                <i class="fas fa-lightbulb"></i> <b>Tip:</b><br>
                ใช้สำหรับตั้งชื่อเว็บ Login (เช่น <b>wifi.com</b>) ให้ชี้มาที่ IP Router (เช่น <b>192.168.88.1</b>)
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-globe-asia"></i> เพิ่มชื่อโดเมน (DNS Static)</h3>
            </div>
            <div class="card-body">
                <form method="post">
                    
                    <div class="form-group">
                        <label>ชื่อโดเมน (Name):</label>
                        <input type="text" name="name" class="form-control" placeholder="เช่น wifi.login" required>
                    </div>

                    <div class="form-group">
                        <label>ชี้ไปที่ไอพี (Address):</label>
                        <input type="text" name="address" class="form-control" value="<?php echo $_SESSION['router_ip']; ?>" required>
                        <small class="text-muted">ใส่ 127.0.0.1 หากต้องการบล็อกเว็บนี้</small>
                    </div>

                    <div class="form-group">
                        <label>TTL (Time To Live):</label>
                        <input type="text" name="ttl" class="form-control" value="1d" required>
                    </div>

                    <div class="form-group">
                        <label>หมายเหตุ (Comment):</label>
                        <input type="text" name="comment" class="form-control" placeholder="เช่น Hotspot Login">
                    </div>

                    <hr>
                    <button type="submit" name="btn_add" class="btn btn-primary" style="width:100%;">
                        <i class="fas fa-plus"></i> บันทึก
                    </button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-3" style="flex: 0 0 65%; max-width: 65%; padding-left:15px;">
        <div class="card">
            <div class="card-header">
                รายการ DNS Static (<?php echo count($dns_list); ?>)
            </div>
            <div style="overflow-x:auto;">
                <table>
                    <thead>
                        <tr>
                            <th>ชื่อโดเมน (Name)</th>
                            <th>ไอพีปลายทาง (Address)</th>
                            <th>TTL</th>
                            <th>จัดการ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i = 0;
                        foreach ($dns_list as $dns) {
                            $i++;
                            $id = $dns['.id'];
                            $id_safe = bin2hex($id);
                            
                            $name = $dns['name'];
                            $addr = isset($dns['address']) ? $dns['address'] : '-';
                            $ttl = isset($dns['ttl']) ? $dns['ttl'] : '-';
                            $comment = isset($dns['comment']) ? $dns['comment'] : '';

                            echo "<tr>";
                            echo "<td><b>$name</b><br><small style='color:gray;'>$comment</small></td>";
                            echo "<td style='color:#2980b9; font-family:monospace;'>$addr</td>";
                            echo "<td>$ttl</td>";
                            echo "<td>";
                            ?>
                            <form method="post" id="del-dns-<?php echo $i; ?>">
                                <input type="hidden" name="del_id" value="<?php echo $id_safe; ?>">
                                <input type="hidden" name="btn_delete" value="yes">
                                <button type="button" onclick="confirmDeleteDNS(<?php echo $i; ?>)" class="btn btn-danger" style="padding:5px 10px; font-size:12px;">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                            <?php
                            echo "</td>";
                            echo "</tr>";
                        }
                        
                        if(count($dns_list) == 0) {
                            echo "<tr><td colspan='4' style='text-align:center; padding:20px; color:#999;'>-- ไม่พบข้อมูล --</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    function confirmDeleteDNS(index) {
        Swal.fire({
            title: 'ลบ DNS นี้?',
            text: "หากลบแล้ว ลูกค้าอาจเข้าเว็บด้วยชื่อเดิมไม่ได้",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            confirmButtonText: 'ลบเลย'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('del-dns-' + index).submit();
            }
        })
    }
</script>