<?php
// view/profiles.php

$price_file = 'config/prices.json';

// -- ส่วนจัดการลบ Profile --
if (isset($_POST['btn_delete'])) {
    
    // รับค่าที่ส่งมา
    $id_hex = $_POST['del_id'];       // ID แบบเข้ารหัส (เอาไว้ลบใน Router)
    $name_to_delete = $_POST['del_name']; // ชื่อ (เอาไว้ลบใน JSON)

    // แปลง ID กลับเป็นรูปแบบ MikroTik (เช่น 2a31 -> *1A)
    $real_id = hex2bin($id_hex);

    if ($API->connect($ip_router, $user_router, $pass_router)) {
        
        // 1. สั่งลบออกจาก MikroTik ด้วย ID โดยตรง
        $API->comm("/ip/hotspot/user/profile/remove", array(".id" => $real_id));
        $API->disconnect();

        // 2. ลบราคาออกจากไฟล์ JSON ของเรา
        if (file_exists($price_file)) {
            $prices = json_decode(file_get_contents($price_file), true);
            if (isset($prices[$name_to_delete])) {
                unset($prices[$name_to_delete]); // ลบราคาทิ้ง
                file_put_contents($price_file, json_encode($prices, JSON_PRETTY_PRINT));
            }
        }
        
        $_SESSION['swal_icon'] = 'success';
        $_SESSION['swal_title'] = 'ลบสำเร็จ';
        $_SESSION['swal_text'] = 'ลบแพ็กเกจ ' . $name_to_delete . ' เรียบร้อยแล้ว';
        
        header("Location: index.php?page=profiles");
        exit;
    }
}

// -- ดึงข้อมูล Profile จาก MikroTik --
$profiles = [];
if ($API->connect($ip_router, $user_router, $pass_router)) {
    $profiles = $API->comm("/ip/hotspot/user/profile/print");
    $API->disconnect();
}

// -- ดึงราคาจากไฟล์ JSON ของเรา --
$local_prices = [];
if (file_exists($price_file)) {
    $local_prices = json_decode(file_get_contents($price_file), true);
}
?>

<div class="card">
    <div class="card-header" style="display:flex; justify-content:space-between; align-items:center;">
        <h3><i class="fas fa-box-open"></i> แพ็กเกจอินเทอร์เน็ต (User Profiles)</h3>
        <a href="index.php?page=add_profile" class="btn btn-primary">
            <i class="fas fa-plus-circle"></i> สร้างแพ็กเกจใหม่
        </a>
    </div>

    <div style="overflow-x:auto;">
        <table>
            <thead>
                <tr>
                    <th>ชื่อแพ็กเกจ</th>
                    <th>ความเร็ว (Rx/Tx)</th>
                    <th>ใช้งานได้นาน (Uptime)</th>
                    <th>แชร์ได้ (เครื่อง)</th>
                    <th>ราคา (บาท)</th>
                    <th>จัดการ</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $i = 0;
                foreach ($profiles as $p) {
                    $i++;
                    $p_id = $p['.id']; // ID ดิบๆ (เช่น *1A)
                    
                    // ✅ แปลง ID เป็นรหัส Hex เพื่อความปลอดภัยเวลาส่งผ่าน HTML
                    $p_id_safe = bin2hex($p_id); 

                    $p_name = $p['name'];
                    $rate = isset($p['rate-limit']) ? $p['rate-limit'] : 'ไม่จำกัด';
                    $shared = isset($p['shared-users']) ? $p['shared-users'] : 'default';
                    $uptime = isset($p['session-timeout']) ? $p['session-timeout'] : '-';
                    
                    // ✅ อ่านราคาจากไฟล์ JSON ของเรา (เทียบชื่อให้ตรงกัน)
                    $price = isset($local_prices[$p_name]) ? $local_prices[$p_name] : '-';
                    if($p_name == 'default') $price = '-';

                    echo "<tr>";
                    echo "<td><b>$p_name</b></td>";
                    echo "<td><span class='badge'>$rate</span></td>";
                    echo "<td>$uptime</td>";
                    echo "<td>$shared</td>";
                    echo "<td><b style='color:green'>$price</b></td>";
                    echo "<td>";
                    
                    if($p_name != 'default'){
                        ?>
                        <form method="post" id="del-prof-<?php echo $i; ?>">
                            <input type="hidden" name="del_id" value="<?php echo $p_id_safe; ?>">
                            
                            <input type="hidden" name="del_name" value="<?php echo $p_name; ?>">
                            
                            <input type="hidden" name="btn_delete" value="yes">
                            
                            <button type="button" onclick="confirmDeleteProfile(<?php echo $i; ?>)" class="btn btn-danger" style="padding:5px 10px; font-size:12px;">
                                <i class="fas fa-trash"></i> ลบ
                            </button>
                        </form>
                        <?php
                    } else {
                        echo "<span style='color:#aaa; font-size:12px;'>Default</span>";
                    }
                    echo "</td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    // ✅ เปลี่ยนชื่อฟังก์ชันเป็น confirmDeleteProfile เพื่อไม่ให้ตีกับ Footer
    function confirmDeleteProfile(index) {
        Swal.fire({
            title: 'ยืนยันการลบ?',
            text: "ต้องการลบแพ็กเกจนี้ใช่ไหม?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            confirmButtonText: 'ลบเลย'
        }).then((result) => {
            if (result.isConfirmed) {
                // เรียก ID ให้ตรงกับ Form ด้านบน (del-prof-)
                document.getElementById('del-prof-' + index).submit();
            }
        })
    }
</script>