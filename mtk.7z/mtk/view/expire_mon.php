<?php
// view/expire_mon.php

// ฟังก์ชันแปลงเวลา MikroTik (เช่น 1w2d3h) เป็นวินาที
function mtik_time_to_sec($time_str) {
    $seconds = 0;
    if (preg_match('/(\d+)w/', $time_str, $matches)) $seconds += $matches[1] * 604800;
    if (preg_match('/(\d+)d/', $time_str, $matches)) $seconds += $matches[1] * 86400;
    if (preg_match('/(\d+)h/', $time_str, $matches)) $seconds += $matches[1] * 3600;
    if (preg_match('/(\d+)m/', $time_str, $matches)) $seconds += $matches[1] * 60;
    if (preg_match('/(\d+)s/', $time_str, $matches)) $seconds += $matches[1];
    // กรณีไม่มีหน่วย (เป็นวินาทีล้วนๆ บางทีเจอใน API)
    if (is_numeric($time_str)) $seconds = $time_str;
    return $seconds;
}

// -- ส่วนสั่งลบ User ที่หมดอายุ --
if (isset($_POST['btn_clear_expired'])) {
    if ($API->connect($ip_router, $user_router, $pass_router)) {
        
        // รับรายการ ID ที่ส่งมา (เป็น Array)
        $ids_to_remove = isset($_POST['remove_ids']) ? explode(',', $_POST['remove_ids']) : [];
        $count = 0;

        foreach ($ids_to_remove as $id) {
            $API->comm("/ip/hotspot/user/remove", array(".id" => $id));
            $count++;
        }
        
        $API->disconnect();
        
        $_SESSION['swal_icon'] = 'success';
        $_SESSION['swal_title'] = 'ล้างข้อมูลสำเร็จ';
        $_SESSION['swal_text'] = 'ลบผู้ใช้งานที่หมดอายุไปแล้ว ' . $count . ' รายการ';
        header("Location: index.php?page=expire_mon");
        exit;
    }
}

// -- ดึงข้อมูล User --
$users = [];
$expired_ids = []; // เก็บ ID คนหมดอายุเอาไว้ส่งไปลบ
if ($API->connect($ip_router, $user_router, $pass_router)) {
    $users = $API->comm("/ip/hotspot/user/print");
    $API->disconnect();
}
?>

<div class="card">
    <div class="card-header" style="display:flex; justify-content:space-between; align-items:center;">
        <h3><i class="fas fa-clock"></i> ตรวจสอบวันหมดอายุ (Expire Monitor)</h3>
        
        <form method="post" id="clearForm" style="display:none;">
            <input type="hidden" name="remove_ids" id="remove_ids_input">
            <button type="button" onclick="confirmClearExpired()" name="btn_clear_expired" class="btn btn-danger">
                <i class="fas fa-trash-alt"></i> ล้าง User ที่หมดอายุทั้งหมด
            </button>
        </form>
    </div>

    <div style="overflow-x:auto;">
        <table>
            <thead>
                <tr>
                    <th>ชื่อผู้ใช้</th>
                    <th>แพ็กเกจ</th>
                    <th>เวลาที่ใช้ / จำกัดเวลา</th>
                    <th>สถานะ</th>
                    <th>จัดการ</th>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($users as $u) {
                    // ข้าม default
                    if($u['name'] == 'default') continue;

                    $u_id = $u['.id'];
                    $name = $u['name'];
                    $profile = isset($u['profile']) ? $u['profile'] : '-';
                    $uptime = isset($u['uptime']) ? $u['uptime'] : '0s';
                    $limit_uptime = isset($u['limit-uptime']) ? $u['limit-uptime'] : '';
                    
                    // คำนวณสถานะ
                    $status_html = "<span class='badge' style='background:#27ae60;'>ใช้งานได้</span>";
                    $is_expired = false;

                    if ($limit_uptime != '') {
                        $used_sec = mtik_time_to_sec($uptime);
                        $limit_sec = mtik_time_to_sec($limit_uptime);
                        
                        // คำนวณ %
                        $percent = 0;
                        if($limit_sec > 0) {
                            $percent = ($used_sec / $limit_sec) * 100;
                        }

                        // ถ้าใช้เกิน หรือ เท่ากับ Limit
                        if ($used_sec >= $limit_sec) {
                            $is_expired = true;
                            $status_html = "<span class='badge' style='background:#c0392b;'>หมดเวลา (Expired)</span>";
                            $expired_ids[] = $u_id; // เก็บ ID ไว้ลบ
                        } else {
                            // แสดง Progress Bar ถ้ายังไม่หมด
                            $status_html = "
                                <div style='font-size:12px; margin-bottom:2px;'>ใช้ไป ".number_format($percent, 1)."%</div>
                                <div style='background:#eee; height:5px; width:100%; border-radius:3px;'>
                                    <div style='background:#2980b9; height:100%; width:{$percent}%; border-radius:3px;'></div>
                                </div>
                            ";
                        }
                    } else {
                        $limit_uptime = "∞ (ไม่จำกัด)";
                    }

                    echo "<tr>";
                    echo "<td><b>$name</b></td>";
                    echo "<td>$profile</td>";
                    echo "<td><small>$uptime / $limit_uptime</small></td>";
                    echo "<td>$status_html</td>";
                    echo "<td>";
                    
                    if ($is_expired) {
                         // ปุ่มลบรายคน (สำหรับคนหมดอายุ)
                         ?>
                        <form method="post" id="del-exp-<?php echo md5($u_id); ?>">
                            <input type="hidden" name="remove_ids" value="<?php echo $u_id; ?>">
                            <input type="hidden" name="btn_clear_expired" value="yes">
                            <button type="button" onclick="confirmDeleteUser('<?php echo md5($u_id); ?>')" class="btn btn-sm btn-danger" style="padding:2px 5px; font-size:10px;">
                                ลบ
                            </button>
                        </form>
                         <?php
                    } else {
                        echo "-";
                    }
                    
                    echo "</td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    // ตรวจสอบว่ามีคนหมดอายุกี่คน เพื่อโชว์ปุ่มล้างทั้งหมด
    var expiredCount = <?php echo count($expired_ids); ?>;
    var expiredList = "<?php echo implode(',', $expired_ids); ?>";

    if(expiredCount > 0) {
        document.getElementById('clearForm').style.display = 'block';
        document.getElementById('remove_ids_input').value = expiredList;
    }

    // ฟังก์ชันยืนยันการล้างทั้งหมด
    function confirmClearExpired() {
        Swal.fire({
            title: 'ยืนยันการล้างข้อมูล?',
            text: "พบ User หมดอายุ " + expiredCount + " รายการ ต้องการลบทั้งหมดหรือไม่?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            confirmButtonText: 'ลบเกลี้ยง!',
            cancelButtonText: 'เอาไว้ก่อน'
        }).then((result) => {
            if (result.isConfirmed) {
                // สร้าง element input hidden เพื่อ submit form หลัก
                var form = document.getElementById('clearForm');
                var hiddenInput = document.createElement('input');
                hiddenInput.type = 'hidden';
                hiddenInput.name = 'btn_clear_expired';
                hiddenInput.value = 'yes';
                form.appendChild(hiddenInput);
                form.submit();
            }
        })
    }

    // ฟังก์ชันลบรายคน (ใช้ชื่อไม่ซ้ำกับหน้าอื่น)
    function confirmDeleteUser(hashId) {
        Swal.fire({
            title: 'ลบ User นี้?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            confirmButtonText: 'ลบ'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('del-exp-' + hashId).submit();
            }
        })
    }
</script>