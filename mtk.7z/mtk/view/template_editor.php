<?php
// view/template_editor.php

$template_dir = 'templates/';
$current_file = isset($_GET['file']) ? $_GET['file'] : 'thermal_blue.html'; 
$file_path = $template_dir . $current_file;

// -- 1. ส่วนบันทึกไฟล์ --
if (isset($_POST['btn_save'])) {
    $content = $_POST['file_content'];
    $save_file = $_POST['file_name'];
    
    if (strpos($save_file, '..') !== false || strpos($save_file, '/') !== false) {
        $_SESSION['swal_icon'] = 'error';
        $_SESSION['swal_title'] = 'ไม่ปลอดภัย';
        $_SESSION['swal_text'] = 'ชื่อไฟล์ไม่ถูกต้อง';
    } else {
        if (file_put_contents($template_dir . $save_file, $content)) {
            $_SESSION['swal_icon'] = 'success';
            $_SESSION['swal_title'] = 'บันทึกเรียบร้อย';
            $_SESSION['swal_text'] = 'แก้ไขไฟล์ Template สำเร็จแล้ว';
        } else {
            $_SESSION['swal_icon'] = 'error';
            $_SESSION['swal_title'] = 'บันทึกไม่ได้';
            $_SESSION['swal_text'] = 'กรุณาตรวจสอบ Permission ของโฟลเดอร์ templates';
        }
    }
    header("Location: index.php?page=template_editor&file=" . $save_file);
    exit;
}

// -- 2. อ่านรายชื่อไฟล์ --
$files = [];
if (is_dir($template_dir)) {
    $scan = scandir($template_dir);
    foreach($scan as $f) {
        if($f != '.' && $f != '..' && pathinfo($f, PATHINFO_EXTENSION) == 'html') {
            $files[] = $f;
        }
    }
}

// -- 3. อ่านเนื้อหา --
$content = "";
if (file_exists($file_path)) {
    $content = file_get_contents($file_path);
} else {
    $content = "";
}
?>

<div class="card">
    <div class="card-header" style="display:flex; justify-content:space-between; align-items:center;">
        <h3><i class="fas fa-code"></i> แก้ไขบัตรคูปอง (Template Editor)</h3>
        
        <form method="get" style="margin:0;">
            <input type="hidden" name="page" value="template_editor">
            <select name="file" onchange="this.form.submit()" class="form-control" style="display:inline-block; width:auto;">
                <?php foreach($files as $f): ?>
                    <option value="<?php echo $f; ?>" <?php echo ($f == $current_file)?'selected':''; ?>>
                        📄 <?php echo $f; ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </form>
    </div>
    
    <div class="card-body">
        <div class="row">
            <div class="col-3" style="flex: 0 0 70%; max-width: 70%; padding-right:15px;">
                <form method="post">
                    <input type="hidden" name="file_name" value="<?php echo $current_file; ?>">
                    <div class="form-group">
                        <label>HTML Code:</label>
                        <textarea name="file_content" style="width:100%; height:500px; font-family:monospace; background:#2d3436; color:#dfe6e9; padding:15px; border-radius:5px; border:none; line-height:1.5; font-size:14px;"><?php echo htmlspecialchars($content); ?></textarea>
                    </div>
                    <button type="submit" name="btn_save" class="btn btn-primary">
                        <i class="fas fa-save"></i> บันทึกการแก้ไข
                    </button>
                </form>
            </div>

            <div class="col-3" style="flex: 0 0 30%; max-width: 30%;">
                <div class="card" style="background:#f8f9fa; border:1px solid #ddd;">
                    <div class="card-header" style="border-bottom:1px solid #ddd; background:#e9ecef; color:#333;">
                        <b>💡 ตัวแปรที่ใช้ได้</b>
                    </div>
                    <div class="card-body" style="font-size:14px;">
                        <p>ก๊อปปี้คำเหล่านี้ไปวางในโค้ดเพื่อแสดงข้อมูลจริง:</p>
                        <ul style="padding-left:20px;">
                            <li><code>{{user}}</code> : ชื่อผู้ใช้</li>
                            <li><code>{{pass}}</code> : รหัสผ่าน</li>
                            <li><code>{{profile}}</code> : ชื่อแพ็กเกจ</li>
                            <li><code>{{price}}</code> : ราคา</li>
                            <li><code>{{qrcode}}</code> : <b>QR Code Login</b></li>
                        </ul>
                        <hr>
                        <small style="color:gray;">
                            <b>Tips:</b><br>
                            - QR Code จะเป็นรูปภาพขนาด 120x120px<br>
                            - ใช้สแกนแล้ว Login ได้ทันที
                        </small>
                    </div>
                </div>
                
                <div style="margin-top:20px; text-align:center;">
                    <a href="print_voucher.php" target="_blank" class="btn" style="background:#6c5ce7; color:white; width:100%;">
                        <i class="fas fa-eye"></i> ดูตัวอย่างการพิมพ์
                    </a>
                    <small style="color:red; display:block; margin-top:5px;">*ต้องมีคูปองใน Session ก่อนนะ</small>
                </div>
            </div>
        </div>
    </div>
</div>