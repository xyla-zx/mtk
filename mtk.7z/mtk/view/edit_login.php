<?php
// view/edit_login.php

$json_file = 'config/settings.json';
$upload_dir = 'assets/img/';

// 1. โหลดค่าเดิม
$settings = json_decode(file_get_contents($json_file), true);

// ค่า Default เผื่อยังไม่มีใน JSON
if (!isset($settings['login_title'])) $settings['login_title'] = 'MikroTik Manager';
if (!isset($settings['login_subtitle'])) $settings['login_subtitle'] = 'Please login to continue';
if (!isset($settings['login_bg'])) $settings['login_bg'] = '';
if (!isset($settings['login_logo'])) $settings['login_logo'] = '';

// 2. บันทึกข้อมูล
if (isset($_POST['btn_save'])) {
    
    // รับค่าข้อความ
    $settings['login_title'] = $_POST['login_title'];
    $settings['login_subtitle'] = $_POST['login_subtitle'];

    // --- จัดการอัปโหลดภาพพื้นหลัง (Background) ---
    if (!empty($_FILES['bg_file']['name'])) {
        $bg_name = 'bg_' . time() . '.' . pathinfo($_FILES['bg_file']['name'], PATHINFO_EXTENSION);
        $target = $upload_dir . $bg_name;
        
        // เช็คว่าเป็นรูปจริงไหม
        $check = getimagesize($_FILES['bg_file']['tmp_name']);
        if($check !== false) {
            if (move_uploaded_file($_FILES['bg_file']['tmp_name'], $target)) {
                $settings['login_bg'] = $bg_name; // บันทึกชื่อไฟล์ใหม่
            }
        }
    }

    // --- จัดการอัปโหลดโลโก้ (Logo) ---
    if (!empty($_FILES['logo_file']['name'])) {
        $logo_name = 'logo_' . time() . '.' . pathinfo($_FILES['logo_file']['name'], PATHINFO_EXTENSION);
        $target = $upload_dir . $logo_name;
        
        $check = getimagesize($_FILES['logo_file']['tmp_name']);
        if($check !== false) {
            if (move_uploaded_file($_FILES['logo_file']['tmp_name'], $target)) {
                $settings['login_logo'] = $logo_name;
            }
        }
    }

    // บันทึกลง JSON
    if (file_put_contents($json_file, json_encode($settings, JSON_PRETTY_PRINT))) {
        $_SESSION['swal_icon'] = 'success';
        $_SESSION['swal_title'] = 'บันทึกเรียบร้อย';
        $_SESSION['swal_text'] = 'หน้า Login ของคุณถูกปรับแต่งแล้ว';
        header("Location: index.php?page=edit_login");
        exit;
    }
}
?>

<div class="row">
    <div class="col-3" style="flex: 0 0 40%; max-width: 40%;">
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-paint-brush"></i> ปรับแต่งหน้า Login</h3>
            </div>
            <div class="card-body">
                <form method="post" enctype="multipart/form-data"> <div class="form-group">
                        <label>หัวข้อหลัก (Main Title):</label>
                        <input type="text" name="login_title" value="<?php echo $settings['login_title']; ?>" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label>คำโปรย (Subtitle):</label>
                        <input type="text" name="login_subtitle" value="<?php echo $settings['login_subtitle']; ?>" class="form-control">
                    </div>

                    <div class="form-group">
                        <label>อัปโหลดโลโก้ (Logo):</label>
                        <input type="file" name="logo_file" class="form-control" accept="image/*">
                        <small class="text-muted">ไฟล์ .png หรือ .jpg (แนะนำพื้นใส)</small>
                    </div>

                    <div class="form-group">
                        <label>อัปโหลดพื้นหลัง (Background):</label>
                        <input type="file" name="bg_file" class="form-control" accept="image/*">
                        <small class="text-muted">แนะนำภาพขนาดใหญ่ (1920x1080)</small>
                    </div>

                    <hr>
                    <button type="submit" name="btn_save" class="btn btn-primary" style="width:100%">
                        <i class="fas fa-save"></i> บันทึกการเปลี่ยนแปลง
                    </button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-3" style="flex: 0 0 60%; max-width: 60%;">
        <div class="card">
            <div class="card-header">ตัวอย่างรูปภาพปัจจุบัน</div>
            <div class="card-body" style="text-align:center;">
                
                <h4>Current Logo:</h4>
                <?php if($settings['login_logo']): ?>
                    <img src="assets/img/<?php echo $settings['login_logo']; ?>" style="max-height: 100px; border:1px solid #ddd; padding:5px;">
                <?php else: ?>
                    <p style="color:#aaa;">(ยังไม่มีโลโก้)</p>
                <?php endif; ?>

                <hr>

                <h4>Current Background:</h4>
                <?php if($settings['login_bg']): ?>
                    <img src="assets/img/<?php echo $settings['login_bg']; ?>" style="width: 100%; border-radius:5px; border:1px solid #ddd;">
                <?php else: ?>
                    <p style="color:#aaa;">(ยังไม่มีพื้นหลัง ใช้สี Default)</p>
                <?php endif; ?>

            </div>
        </div>
    </div>
</div>