<?php
// view/interface.php

// -- สั่งเปิด/ปิด Interface --
if (isset($_POST['btn_toggle'])) {
    $id_hex = $_POST['iface_id'];
    $real_id = hex2bin($id_hex);
    $current_state = $_POST['current_state']; // true=disabled, false=enabled
    
    $cmd = ($current_state == 'false') ? 'disable' : 'enable'; // สลับสถานะ
    
    if ($API->connect($ip_router, $user_router, $pass_router)) {
        $API->comm("/interface/" . $cmd, array(".id" => $real_id));
        $API->disconnect();
        
        $_SESSION['swal_icon'] = 'success';
        $_SESSION['swal_title'] = 'สำเร็จ';
        $_SESSION['swal_text'] = 'เปลี่ยนสถานะ Interface เรียบร้อยแล้ว';
        header("Location: index.php?page=interface");
        exit;
    }
}

// -- ดึงข้อมูล Interface --
$interfaces = [];
if ($API->connect($ip_router, $user_router, $pass_router)) {
    $interfaces = $API->comm("/interface/print");
    $API->disconnect();
}

// ฟังก์ชันแปลงหน่วย
function formatBytesTotal($bytes, $precision = 2) { 
    $units = array('B', 'KB', 'MB', 'GB', 'TB'); 
    $bytes = max($bytes, 0); 
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024)); 
    $pow = min($pow, count($units) - 1); 
    $bytes /= pow(1024, $pow); 
    return round($bytes, $precision) . ' ' . $units[$pow]; 
}
?>

<div class="card">
    <div class="card-header" style="display:flex; justify-content:space-between; align-items:center;">
        <h3><i class="fas fa-sitemap"></i> รายการพอร์ตเชื่อมต่อ (Network Interfaces)</h3>
        <button onclick="window.location.reload();" class="btn btn-primary" style="font-size:14px;">
            <i class="fas fa-sync"></i> รีเฟรช
        </button>
    </div>

    <div style="overflow-x:auto;">
        <table>
            <thead>
                <tr>
                    <th width="5%">#</th>
                    <th>ชื่อพอร์ต (Name)</th>
                    <th>ชนิด (Type)</th>
                    <th>สถานะ (Status)</th>
                    <th style="text-align:right;">รับข้อมูล (Rx)</th>
                    <th style="text-align:right;">ส่งข้อมูล (Tx)</th>
                    <th width="10%">จัดการ</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $i = 0;
                foreach ($interfaces as $iface) {
                    $i++;
                    $id = $iface['.id'];
                    $id_safe = bin2hex($id);
                    $name = $iface['name'];
                    $type = $iface['type'];
                    $disabled = $iface['disabled']; // true / false
                    $running = isset($iface['running']) && $iface['running'] == 'true';
                    
                    // ไอคอนตามชนิด
                    $icon = "fas fa-ethernet";
                    if($type == 'wlan') $icon = "fas fa-wifi";
                    if($type == 'bridge') $icon = "fas fa-project-diagram";
                    if($type == 'pppoe-out') $icon = "fas fa-globe";

                    // สถานะ
                    $status_badge = "";
                    if ($disabled == 'true') {
                        $status_badge = "<span class='badge' style='background:#95a5a6;'>Disabled (ปิด)</span>";
                    } elseif ($running) {
                        $status_badge = "<span class='badge' style='background:#27ae60;'>Running (ใช้งาน)</span>";
                    } else {
                        $status_badge = "<span class='badge' style='background:#f39c12;'>No Link (สายหลุด)</span>";
                    }

                    // ข้อมูล Traffic รวม
                    $rx = formatBytesTotal(isset($iface['rx-byte']) ? $iface['rx-byte'] : 0);
                    $tx = formatBytesTotal(isset($iface['tx-byte']) ? $iface['tx-byte'] : 0);

                    echo "<tr>";
                    echo "<td>$i</td>";
                    echo "<td><i class='$icon' style='color:#555; margin-right:5px;'></i> <b>$name</b></td>";
                    echo "<td>$type</td>";
                    echo "<td>$status_badge</td>";
                    echo "<td style='text-align:right; color:#2980b9;'>$rx</td>";
                    echo "<td style='text-align:right; color:#27ae60;'>$tx</td>";
                    echo "<td>";
                    
                    // ปุ่มเปิด/ปิด
                    $btn_color = ($disabled == 'true') ? 'btn-primary' : 'btn-danger';
                    $btn_text = ($disabled == 'true') ? '<i class="fas fa-play"></i> เปิด' : '<i class="fas fa-stop"></i> ปิด';
                    $action_text = ($disabled == 'true') ? 'เปิดใช้งาน' : 'ปิดการทำงาน';
                    
                    // ป้องกันการปิด Ether1 (กันเหนียว เดี๋ยวเข้า Router ไม่ได้)
                    if($name != 'ether1') {
                        ?>
                        <form method="post" id="toggle-iface-<?php echo $i; ?>">
                            <input type="hidden" name="iface_id" value="<?php echo $id_safe; ?>">
                            <input type="hidden" name="current_state" value="<?php echo $disabled; ?>">
                            <input type="hidden" name="btn_toggle" value="yes">
                            
                            <button type="button" onclick="confirmToggle(<?php echo $i; ?>, '<?php echo $action_text; ?>', '<?php echo $name; ?>')" class="btn <?php echo $btn_color; ?>" style="padding:5px 10px; font-size:12px; min-width:60px;">
                                <?php echo $btn_text; ?>
                            </button>
                        </form>
                        <?php
                    } else {
                        echo "<small style='color:#aaa;'>System</small>";
                    }
                    
                    echo "</td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    function confirmToggle(index, action, name) {
        Swal.fire({
            title: 'ยืนยันการ' + action + '?',
            text: "คุณต้องการ " + action + " พอร์ต " + name + " ใช่หรือไม่?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'ใช่, ทำเลย',
            cancelButtonText: 'ยกเลิก'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('toggle-iface-' + index).submit();
            }
        })
    }
</script>