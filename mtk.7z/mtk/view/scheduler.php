<?php
// view/scheduler.php

// -- 1. สั่งเพิ่ม Scheduler --
if (isset($_POST['btn_add'])) {
    $name = $_POST['name'];
    $interval = $_POST['interval']; // เช่น 1d, 1h
    $on_event = $_POST['on_event'];
    
    // ถ้าเลือก Preset ให้ใช้ค่าจาก Preset แทน
    if($_POST['preset_script'] != 'custom') {
        $on_event = $_POST['preset_script'];
    }

    if ($API->connect($ip_router, $user_router, $pass_router)) {
        $API->comm("/system/scheduler/add", array(
            "name"      => $name,
            "interval"  => $interval,
            "on-event"  => $on_event,
            "start-time"=> "03:00:00" // Default เริ่มตี 3
        ));
        $API->disconnect();
        
        $_SESSION['swal_icon'] = 'success';
        $_SESSION['swal_title'] = 'เพิ่มงานสำเร็จ';
        $_SESSION['swal_text'] = 'ตั้งเวลา ' . $name . ' เรียบร้อยแล้ว';
        header("Location: index.php?page=scheduler");
        exit;
    }
}

// -- 2. สั่งลบ --
if (isset($_POST['btn_delete'])) {
    $id_hex = $_POST['del_id'];
    $real_id = hex2bin($id_hex);

    if ($API->connect($ip_router, $user_router, $pass_router)) {
        $API->comm("/system/scheduler/remove", array(".id" => $real_id));
        $API->disconnect();
        
        $_SESSION['swal_icon'] = 'success';
        $_SESSION['swal_title'] = 'ลบสำเร็จ';
        $_SESSION['swal_text'] = 'ลบตารางงานเรียบร้อย';
        header("Location: index.php?page=scheduler");
        exit;
    }
}

// -- 3. สั่งเปิด/ปิด (Toggle) --
if (isset($_POST['btn_toggle'])) {
    $id_hex = $_POST['toggle_id'];
    $real_id = hex2bin($id_hex);
    $state = $_POST['current_state']; // true=disabled
    $cmd = ($state == 'true') ? 'enable' : 'disable';

    if ($API->connect($ip_router, $user_router, $pass_router)) {
        $API->comm("/system/scheduler/" . $cmd, array(".id" => $real_id));
        $API->disconnect();
        header("Location: index.php?page=scheduler");
        exit;
    }
}

// -- 4. ดึงข้อมูล --
$schedulers = [];
if ($API->connect($ip_router, $user_router, $pass_router)) {
    $schedulers = $API->comm("/system/scheduler/print");
    $API->disconnect();
}
?>

<div class="row">
    <div class="col-3" style="flex: 0 0 35%; max-width: 35%;">
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-calendar-alt"></i> ตั้งเวลาทำงาน (Scheduler)</h3>
            </div>
            <div class="card-body">
                <form method="post">
                    
                    <div class="form-group">
                        <label>ชื่องาน (Name):</label>
                        <input type="text" name="name" class="form-control" placeholder="เช่น Auto Reboot" required>
                    </div>

                    <div class="form-group">
                        <label>ทำซ้ำทุกๆ (Interval):</label>
                        <input type="text" name="interval" class="form-control" placeholder="เช่น 1d (ทุกวัน), 12h (12ชม.)" value="1d" required>
                        <small class="text-muted">Format: 1d = 1 วัน, 1h = 1 ชั่วโมง</small>
                    </div>

                    <div class="form-group">
                        <label>เลือกคำสั่งด่วน (Preset):</label>
                        <select name="preset_script" id="presetSelect" class="form-control" onchange="toggleCustomScript()">
                            <option value="custom">-- เขียนเอง (Custom) --</option>
                            <option value="/system reboot">Auto Reboot (รีสตาร์ทเครื่อง)</option>
                            <option value="/ip hotspot user remove [find where limit-uptime &lt;= uptime]">Remove Expired Users (ลบคนหมดเวลา)</option>
                            <option value="/system script run user-limit-check">Check Limit (ตรวจสอบ Limit)</option>
                        </select>
                    </div>

                    <div class="form-group" id="customScriptBox">
                        <label>คำสั่ง (Script / On Event):</label>
                        <textarea name="on_event" class="form-control" rows="3" placeholder="/system reboot"></textarea>
                    </div>

                    <hr>
                    <button type="submit" name="btn_add" class="btn btn-primary" style="width:100%;">
                        <i class="fas fa-clock"></i> เพิ่มตารางงาน
                    </button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-3" style="flex: 0 0 65%; max-width: 65%; padding-left:15px;">
        <div class="card">
            <div class="card-header">
                รายการที่ตั้งไว้ (<?php echo count($schedulers); ?>)
            </div>
            <div style="overflow-x:auto;">
                <table>
                    <thead>
                        <tr>
                            <th>ชื่องาน</th>
                            <th>รอบเวลา (Interval)</th>
                            <th>ทำงานครั้งต่อไป</th>
                            <th>คำสั่ง</th>
                            <th>สถานะ</th>
                            <th>จัดการ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i = 0;
                        foreach ($schedulers as $sch) {
                            $i++;
                            $s_id = $sch['.id'];
                            $s_id_safe = bin2hex($s_id);
                            
                            $name = $sch['name'];
                            $interval = isset($sch['interval']) ? $sch['interval'] : '-';
                            $next_run = isset($sch['next-run']) ? $sch['next-run'] : '-';
                            $on_event = isset($sch['on-event']) ? $sch['on-event'] : '-';
                            $disabled = $sch['disabled']; // true / false
                            $run_count = isset($sch['run-count']) ? $sch['run-count'] : 0;

                            // สถานะ
                            $status_badge = ($disabled == 'true') 
                                ? "<span class='badge' style='background:#95a5a6;'>Disabled</span>" 
                                : "<span class='badge' style='background:#27ae60;'>Active</span>";

                            echo "<tr>";
                            echo "<td><b>$name</b><br><small style='color:#aaa;'>Run: $run_count ครั้ง</small></td>";
                            echo "<td>$interval</td>";
                            echo "<td style='color:#2980b9;'>$next_run</td>";
                            echo "<td><code style='font-size:11px; background:#eee; padding:2px;'>".substr($on_event, 0, 20)."...</code></td>";
                            echo "<td>$status_badge</td>";
                            echo "<td>";
                            
                            // ปุ่ม Toggle
                            $btn_icon = ($disabled == 'true') ? 'fa-play' : 'fa-pause';
                            $btn_cls = ($disabled == 'true') ? 'btn-success' : 'btn-warning';
                            ?>
                            <div style="display:flex; gap:5px;">
                                <form method="post" style="margin:0;">
                                    <input type="hidden" name="toggle_id" value="<?php echo $s_id_safe; ?>">
                                    <input type="hidden" name="current_state" value="<?php echo $disabled; ?>">
                                    <input type="hidden" name="btn_toggle" value="yes">
                                    <button type="submit" class="btn <?php echo $btn_cls; ?>" style="padding:5px 8px; font-size:12px;">
                                        <i class="fas <?php echo $btn_icon; ?>"></i>
                                    </button>
                                </form>

                                <form method="post" id="del-sch-<?php echo $i; ?>" style="margin:0;">
                                    <input type="hidden" name="del_id" value="<?php echo $s_id_safe; ?>">
                                    <input type="hidden" name="btn_delete" value="yes">
                                    <button type="button" onclick="confirmDeleteSch(<?php echo $i; ?>)" class="btn btn-danger" style="padding:5px 8px; font-size:12px;">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                            <?php
                            echo "</td>";
                            echo "</tr>";
                        }
                        
                        if(count($schedulers) == 0) {
                            echo "<tr><td colspan='6' style='text-align:center; padding:20px; color:#999;'>-- ไม่มีการตั้งเวลา --</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    function confirmDeleteSch(index) {
        Swal.fire({
            title: 'ลบตารางงาน?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            confirmButtonText: 'ลบเลย'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('del-sch-' + index).submit();
            }
        })
    }

    // ซ่อน/แสดงช่องเขียนโค้ดตาม Preset
    function toggleCustomScript() {
        var select = document.getElementById('presetSelect');
        var box = document.getElementById('customScriptBox');
        if(select.value === 'custom') {
            box.style.display = 'block';
        } else {
            box.style.display = 'none';
        }
    }
</script>