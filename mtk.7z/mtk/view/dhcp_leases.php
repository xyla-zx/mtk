<?php
// view/dhcp_leases.php

// -- สั่งลบ Lease (เคลียร์ IP) --
if (isset($_POST['btn_remove'])) {
    if ($API->connect($ip_router, $user_router, $pass_router)) {
        $id = $_POST['del_id'];
        $API->comm("/ip/dhcp-server/lease/remove", array(".id" => $id));
        $API->disconnect();
        
        $_SESSION['swal_icon'] = 'success';
        $_SESSION['swal_title'] = 'ลบรายการแล้ว';
        $_SESSION['swal_text'] = 'เคลียร์ IP เรียบร้อย (อุปกรณ์จะขอ IP ใหม่)';
        header("Location: index.php?page=dhcp_leases");
        exit;
    }
}

// -- ดึงข้อมูล DHCP Leases --
$leases = [];
if ($API->connect($ip_router, $user_router, $pass_router)) {
    $leases = $API->comm("/ip/dhcp-server/lease/print");
    $API->disconnect();
}
?>

<div class="card">
    <div class="card-header" style="display:flex; justify-content:space-between; align-items:center;">
        <h3><i class="fas fa-network-wired"></i> อุปกรณ์ที่เชื่อมต่อ (DHCP Leases)</h3>
        <button onclick="window.location.reload();" class="btn btn-primary" style="font-size:14px;">
            <i class="fas fa-sync"></i> รีเฟรช
        </button>
    </div>

    <div style="overflow-x:auto;">
        <table>
            <thead>
                <tr>
                    <th>IP Address</th>
                    <th>MAC Address</th>
                    <th>ชื่อเครื่อง (Host Name)</th>
                    <th>สถานะ</th>
                    <th>จัดการ</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $count = 0;
                // เรียงข้อมูลเอาล่าสุดขึ้นก่อน (คร่าวๆ)
                $leases = array_reverse($leases);

                foreach ($leases as $lease) {
                    $count++;
                    $l_id = $lease['.id'];
                    $ip = isset($lease['address']) ? $lease['address'] : '-';
                    $mac = isset($lease['mac-address']) ? $lease['mac-address'] : '-';
                    $server = isset($lease['server']) ? $lease['server'] : '-';
                    $host = isset($lease['host-name']) ? $lease['host-name'] : '<i>(ไม่ระบุ)</i>';
                    $status = isset($lease['status']) ? $lease['status'] : '-';
                    $comment = isset($lease['comment']) ? $lease['comment'] : '';

                    // สีสถานะ
                    $st_color = ($status == 'bound') ? '#27ae60' : '#95a5a6';
                    
                    echo "<tr>";
                    echo "<td><b style='color:#2980b9;'>$ip</b></td>";
                    echo "<td style='font-family:monospace;'>$mac</td>";
                    echo "<td>$host <br><small style='color:gray;'>$comment</small></td>";
                    echo "<td><span class='badge' style='background:$st_color;'>$status</span></td>";
                    echo "<td>";
                    ?>
                    
                    <div style="display:flex; gap:5px;">
                        <a href="index.php?page=binding&auto_mac=<?php echo $mac; ?>&auto_comment=<?php echo $host; ?>" 
                           class="btn" style="background:#f39c12; color:white; padding:5px 10px; font-size:12px; text-decoration:none;"
                           title="กดเพื่อ Bypass เครื่องนี้">
                            <i class="fas fa-shield-alt"></i> Bypass
                        </a>

                        <form method="post" id="del-lease-<?php echo $count; ?>" style="margin:0;">
                            <input type="hidden" name="del_id" value="<?php echo bin2hex($l_id); ?>"> <input type="hidden" name="btn_remove" value="yes">
                            <button type="button" onclick="confirmRemoveLease(<?php echo $count; ?>)" class="btn btn-danger" style="padding:5px 10px; font-size:12px;">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                    </div>

                    <?php
                    echo "</td>";
                    echo "</tr>";
                }

                if ($count == 0) {
                    echo "<tr><td colspan='5' style='text-align:center; padding:20px;'>-- ไม่มีอุปกรณ์เชื่อมต่อ --</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    function confirmRemoveLease(index) {
        Swal.fire({
            title: 'ดีดอุปกรณ์นี้?',
            text: "ต้องการลบ Lease นี้หรือไม่? (เครื่องลูกข่ายจะต้องขอ IP ใหม่)",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            confirmButtonText: 'ลบเลย'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('del-lease-' + index).submit();
            }
        })
    }
</script>