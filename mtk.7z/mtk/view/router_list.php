<?php
// view/router_list.php
require_once 'config/database.php';

// ดึงรายการ Router ของ User นี้
$user_id = $_SESSION['cloud_user_id'];
$role = $_SESSION['cloud_role'];

if ($role == 'superadmin') {
    // Superadmin เห็นทุกเครื่อง
    $stmt = $pdo->query("SELECT * FROM tb_routers");
} else {
    // Manager/Staff เห็นแค่ของตัวเอง
    $stmt = $pdo->prepare("SELECT * FROM tb_routers WHERE owner_id = :id");
    $stmt->execute(['id' => $user_id]);
}
$routers = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Select Router</title>
    <link rel="stylesheet" href="assets/css/style.css"> <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background-color: #f4f6f9; font-family: 'Sarabun', sans-serif; }
        .container { max-width: 900px; margin: 50px auto; padding: 20px; }
        .router-card { 
            background: white; border-radius: 10px; padding: 20px; 
            box-shadow: 0 4px 6px rgba(0,0,0,0.05); transition: 0.2s; 
            border: 1px solid #eee; display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 15px;
        }
        .router-card:hover { transform: translateY(-3px); box-shadow: 0 8px 15px rgba(0,0,0,0.1); border-color: #3498db; }
        .r-info h4 { margin: 0 0 5px 0; color: #2c3e50; }
        .r-info p { margin: 0; color: #7f8c8d; font-size: 14px; }
        .btn-connect { background: #27ae60; color: white; border: none; padding: 10px 20px; border-radius: 50px; cursor: pointer; font-weight: bold; text-decoration: none; display: inline-block;}
        .top-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; }
    </style>
</head>
<body>

<div class="container">
    <div class="top-bar">
        <div>
            <h2><i class="fas fa-server"></i> เลือก Router ที่ต้องการจัดการ</h2>
            <span style="color:#666;">สวัสดี, <?php echo $_SESSION['cloud_name']; ?> (<?php echo ucfirst($role); ?>)</span>
        </div>
        <div>
            <?php if($role == 'superadmin' || $role == 'manager'): ?>
                <a href="index.php?page=add_router" class="btn-connect" style="background:#3498db;"><i class="fas fa-plus"></i> เพิ่ม Router</a>
            <?php endif; ?>
            <a href="index.php?action=logout" class="btn-connect" style="background:#e74c3c;"><i class="fas fa-sign-out-alt"></i> ออกจากระบบ</a>
        </div>
    </div>

    <?php if(count($routers) > 0): ?>
        <?php foreach($routers as $r): ?>
        <div class="router-card">
            <div class="r-info">
                <h4><i class="fas fa-wifi" style="color:#3498db; margin-right:10px;"></i> <?php echo $r['router_name']; ?></h4>
                <p>IP: <b><?php echo $r['ip_address']; ?></b> (User: <?php echo $r['api_user']; ?>)</p>
            </div>
            <div>
                <form action="core/handler_router.php" method="post">
                    <input type="hidden" name="action" value="select_router">
                    <input type="hidden" name="router_id" value="<?php echo $r['router_id']; ?>">
                    <button type="submit" class="btn-connect">จัดการ <i class="fas fa-arrow-right"></i></button>
                </form>
            </div>
        </div>
        <?php endforeach; ?>
    <?php else: ?>
        <div style="text-align:center; padding: 50px; color:#aaa;">
            <i class="fas fa-cube" style="font-size:50px; margin-bottom:10px;"></i><br>
            ยังไม่มี Router ในระบบ
        </div>
    <?php endif; ?>
</div>

</body>
</html>