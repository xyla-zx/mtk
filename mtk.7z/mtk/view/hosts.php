<?php
// view/hosts.php

// -- 1. สั่งลบ Host (เตะให้เชื่อมต่อใหม่) --
if (isset($_POST['btn_delete'])) {
    $id_hex = $_POST['del_id'];
    $real_id = hex2bin($id_hex);

    if ($API->connect($ip_router, $user_router, $pass_router)) {
        $API->comm("/ip/hotspot/host/remove", array(".id" => $real_id));
        $API->disconnect();
        
        $_SESSION['swal_icon'] = 'success';
        $_SESSION['swal_title'] = 'ลบสำเร็จ';
        $_SESSION['swal_text'] = 'รีเซ็ตการเชื่อมต่ออุปกรณ์นี้แล้ว';
        header("Location: index.php?page=hosts");
        exit;
    }
}

// -- 2. ดึงข้อมูล Hosts --
$hosts = [];
if ($API->connect($ip_router, $user_router, $pass_router)) {
    $hosts = $API->comm("/ip/hotspot/host/print");
    $API->disconnect();
}
?>

<div class="card">
    <div class="card-header" style="display:flex; justify-content:space-between; align-items:center;">
        <h3><i class="fas fa-laptop-house"></i> อุปกรณ์ในระบบ Hotspot (Hosts)</h3>
        <button onclick="window.location.reload();" class="btn btn-primary" style="font-size:14px;">
            <i class="fas fa-sync"></i> รีเฟรช
        </button>
    </div>

    <div class="card-body" style="background:#e8f4f8; color:#2c3e50; font-size:13px; padding:10px;">
        <i class="fas fa-info-circle"></i> <b>หน้านี้คืออะไร?</b> แสดงอุปกรณ์ทั้งหมดที่ระบบ Hotspot มองเห็น (ทั้งที่ Login แล้ว และยังไม่ Login) <br>
        ใช้สำหรับเช็คว่าลูกค้าเชื่อมต่อ WiFi ได้จริงไหม หรือกด <b>Bypass</b> ให้ลูกค้าที่เข้าหน้า Login ไม่ได้
    </div>

    <div style="overflow-x:auto;">
        <table>
            <thead>
                <tr>
                    <th>MAC Address</th>
                    <th>IP Address</th>
                    <th>สถานะ (Flag)</th>
                    <th>Idle Time</th>
                    <th>จัดการ</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $i = 0;
                foreach ($hosts as $h) {
                    $i++;
                    $h_id = $h['.id'];
                    $h_id_safe = bin2hex($h_id);
                    
                    $mac = isset($h['mac-address']) ? $h['mac-address'] : '-';
                    $ip = isset($h['address']) ? $h['address'] : '-';
                    $server = isset($h['server']) ? $h['server'] : '-';
                    $idle = isset($h['idle-time']) ? $h['idle-time'] : '-';
                    $comment = isset($h['comment']) ? $h['comment'] : '';
                    
                    // สถานะ (Authorized / Bypassed)
                    $is_auth = isset($h['authorized']) && $h['authorized'] == 'true';
                    $is_bypassed = isset($h['bypassed']) && $h['bypassed'] == 'true';
                    
                    $status_badge = "<span class='badge' style='background:#95a5a6;'>Guest (ยังไม่ Login)</span>";
                    
                    if ($is_auth) {
                        $status_badge = "<span class='badge' style='background:#27ae60;'>Login แล้ว</span>";
                    } elseif ($is_bypassed) {
                        $status_badge = "<span class='badge' style='background:#f39c12;'>Bypassed (IP Binding)</span>";
                    }

                    echo "<tr>";
                    echo "<td style='font-family:monospace;'>$mac</td>";
                    echo "<td><b style='color:#2980b9;'>$ip</b> <br><small style='color:gray;'>$server</small></td>";
                    echo "<td>$status_badge <br><small style='color:gray;'>$comment</small></td>";
                    echo "<td>$idle</td>";
                    echo "<td>";
                    ?>
                    
                    <div style="display:flex; gap:5px;">
                        <?php if(!$is_bypassed && !$is_auth): ?>
                        <a href="index.php?page=binding&auto_mac=<?php echo $mac; ?>&auto_comment=Device_<?php echo $ip; ?>" 
                           class="btn" style="background:#8e44ad; color:white; padding:5px 10px; font-size:12px; text-decoration:none;"
                           title="Bypass เครื่องนี้">
                            <i class="fas fa-shield-alt"></i>
                        </a>
                        <?php endif; ?>

                        <form method="post" id="del-host-<?php echo $i; ?>" style="margin:0;">
                            <input type="hidden" name="del_id" value="<?php echo $h_id_safe; ?>">
                            <input type="hidden" name="btn_delete" value="yes">
                            <button type="button" onclick="confirmDeleteHost(<?php echo $i; ?>)" class="btn btn-danger" style="padding:5px 10px; font-size:12px;">
                                <i class="fas fa-times"></i>
                            </button>
                        </form>
                    </div>

                    <?php
                    echo "</td>";
                    echo "</tr>";
                }
                
                if(count($hosts) == 0) {
                    echo "<tr><td colspan='5' style='text-align:center; padding:20px; color:#999;'>-- ไม่มีอุปกรณ์เชื่อมต่อ --</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    function confirmDeleteHost(index) {
        Swal.fire({
            title: 'ลบอุปกรณ์นี้?',
            text: "ระบบจะลบสถานะการเชื่อมต่อ (เครื่องลูกข่ายจะถูกบังคับให้เชื่อมต่อใหม่)",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            confirmButtonText: 'ลบเลย'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('del-host-' + index).submit();
            }
        })
    }
</script>