<?php
// view/binding.php

// --- 1. ส่วนจัดการคำสั่ง (Action Handler) ---
if (isset($_POST['action'])) {
    
    // 1.1 เพิ่ม Binding (Add)
    if ($_POST['action'] == 'add') {
        $mac = $_POST['mac'];
        $type = $_POST['type'];
        $comment = $_POST['comment'];
        
        if ($API->connect($ip_router, $user_router, $pass_router)) {
            // เช็คก่อนว่ามี MAC นี้หรือยัง (กัน Error)
            $check = $API->comm("/ip/hotspot/ip-binding/print", array(
                "?mac-address" => $mac
            ));
            
            if (count($check) == 0) {
                $API->comm("/ip/hotspot/ip-binding/add", array(
                    "mac-address" => $mac,
                    "type"        => $type,
                    "comment"     => $comment
                ));
                $_SESSION['swal_icon'] = 'success';
                $_SESSION['swal_title'] = 'เพิ่มสำเร็จ';
                $_SESSION['swal_text'] = 'เพิ่มอุปกรณ์ ' . $comment . ' เรียบร้อย';
            } else {
                $_SESSION['swal_icon'] = 'warning';
                $_SESSION['swal_title'] = 'ซ้ำซ้อน';
                $_SESSION['swal_text'] = 'MAC Address นี้มีอยู่ในระบบแล้ว';
            }
            $API->disconnect();
        }
        // Redirect ล้างค่า POST
        header("Location: index.php?page=binding");
        exit;
    }

    // 1.2 ลบ Binding (Delete)
    elseif ($_POST['action'] == 'delete') {
        $id = $_POST['id'];
        if ($API->connect($ip_router, $user_router, $pass_router)) {
            $API->comm("/ip/hotspot/ip-binding/remove", array(".id" => $id));
            $API->disconnect();
            
            $_SESSION['swal_icon'] = 'success';
            $_SESSION['swal_title'] = 'ลบสำเร็จ';
        }
        header("Location: index.php?page=binding");
        exit;
    }
}

// --- 2. ส่วนดึงข้อมูล (Fetch Data) ---
$bindings = [];
$arp_list = [];
$bound_macs = []; // เอาไว้เก็บ MAC ที่ทำ Binding ไปแล้ว เพื่อไม่ให้โชว์ซ้ำในหน้า Scan

if ($API->connect($ip_router, $user_router, $pass_router)) {
    // 2.1 ดึงรายการ Binding ทั้งหมด
    $bindings = $API->comm("/ip/hotspot/ip-binding/print");
    
    // เก็บ MAC ลง Array ไว้เช็ค (Key = MAC, Value = Type)
    foreach($bindings as $b) {
        if(isset($b['mac-address'])) {
            $bound_macs[$b['mac-address']] = $b['type'];
        }
    }

    // 2.2 ดึง ARP List (อุปกรณ์ที่เชื่อมต่ออยู่)
    // กรองเอาเฉพาะ Interface ที่เป็น Hotspot (แก้ ether1 เป็น Bridge หรือ Interface ที่ใช้จริงถ้าไม่ขึ้น)
    $arp_list = $API->comm("/ip/arp/print");
    
    $API->disconnect();
}
?>

<style>
    /* Page-scoped layout fixes for binding page to avoid card collisions */
    .binding-row {
        display: flex;
        flex-wrap: wrap;
        gap: 20px;
        align-items: stretch;
    }
    .binding-row > [class*="col-"] {
        display: flex;
        flex-direction: column;
    }
    /* Ensure cards expand to fill column height and keep spacing consistent */
    .binding-row .card {
        width: 100%;
        box-sizing: border-box;
    }
    @media (max-width: 768px) {
        .binding-row { gap: 12px; }
    }
</style>

<div class="row binding-row">
    <div class="col-md-4 mb-3">
        <div class="card h-100">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="fas fa-plus-circle"></i> เพิ่มเอง (Manual)</h5>
            </div>
            <div class="card-body">
                <form method="post">
                    <input type="hidden" name="action" value="add">
                    <div class="form-group mb-3">
                        <label>MAC Address:</label>
                        <input type="text" name="mac" class="form-control" placeholder="XX:XX:XX:XX:XX:XX" required>
                    </div>

                    <div class="form-group mb-3">
                        <label>Type:</label>
                        <select name="type" class="form-control">
                            <option value="bypassed">✅ Bypassed (เล่นฟรี)</option>
                            <option value="blocked">❌ Blocked (บล็อก)</option>
                            <option value="regular">⚠️ Regular (ต้อง Login)</option>
                        </select>
                    </div>

                    <div class="form-group mb-3">
                        <label>Comment:</label>
                        <input type="text" name="comment" class="form-control" placeholder="ชื่ออุปกรณ์..." required>
                    </div>

                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-save"></i> บันทึกข้อมูล
                    </button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-8 mb-3">
        <div class="card h-100">
            <div class="card-header">
                <h5 class="mb-0"><i class="fas fa-list"></i> รายการที่บันทึกไว้ (<?php echo count($bindings); ?>)</h5>
            </div>
            <div class="table-responsive p-0">
                <table class="table table-hover mb-0">
                    <thead class="thead-light">
                        <tr>
                            <th>ชื่ออุปกรณ์</th>
                            <th>MAC Address</th>
                            <th>สถานะ</th>
                            <th>จัดการ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($bindings) > 0): ?>
                            <?php foreach ($bindings as $b): 
                                $b_id = $b['.id'];
                                $mac = isset($b['mac-address']) ? $b['mac-address'] : '-';
                                $comment = isset($b['comment']) ? $b['comment'] : '-';
                                $type = isset($b['type']) ? $b['type'] : 'regular';
                                
                                // สีสถานะ
                                $badge = 'secondary';
                                if($type == 'bypassed') $badge = 'success';
                                if($type == 'blocked') $badge = 'danger';
                            ?>
                            <tr>
                                <td><?php echo $comment; ?></td>
                                <td style="font-family:monospace;"><?php echo $mac; ?></td>
                                <td><span class="badge badge-<?php echo $badge; ?>"><?php echo ucfirst($type); ?></span></td>
                                <td>
                                    <form method="post" onsubmit="return confirm('ยืนยันการลบ?');">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?php echo $b_id; ?>">
                                        <button type="submit" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="4" class="text-center text-muted py-3">ยังไม่มีข้อมูล</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="card mt-3 border-info">
    <div class="card-header bg-info text-white d-flex justify-content-between align-items-center">
        <h5 class="mb-0"><i class="fas fa-satellite-dish"></i> Quick Scan (เจออุปกรณ์ <?php echo count($arp_list); ?> เครื่อง)</h5>
        <button onclick="window.location.reload();" class="btn btn-sm btn-light"><i class="fas fa-sync"></i> Refresh</button>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-striped mb-0">
                <thead>
                    <tr>
                        <th>IP Address</th>
                        <th>MAC Address</th>
                        <th>Interface</th>
                        <th>สถานะปัจจุบัน</th>
                        <th class="text-right">Action (ทางลัด)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $found_new = false;
                    foreach($arp_list as $arp): 
                        $arp_mac = isset($arp['mac-address']) ? $arp['mac-address'] : '';
                        $arp_ip = isset($arp['address']) ? $arp['address'] : '';
                        $arp_int = isset($arp['interface']) ? $arp['interface'] : '';
                        
                        // ข้ามถ้าไม่มี MAC
                        if($arp_mac == '') continue;

                        // เช็คว่า MAC นี้มีใน Binding หรือยัง?
                        $is_bound = array_key_exists($arp_mac, $bound_macs);
                        
                        // ถ้าอยากโชว์เฉพาะเครื่องที่ยังไม่ Bind ให้เปิดบรรทัดนี้
                        // if ($is_bound) continue; 
                    ?>
                    <tr>
                        <td><?php echo $arp_ip; ?></td>
                        <td style="font-family:monospace; font-weight:bold;"><?php echo $arp_mac; ?></td>
                        <td><small class="text-muted"><?php echo $arp_int; ?></small></td>
                        <td>
                            <?php if($is_bound): ?>
                                <span class="badge badge-light border">
                                    <i class="fas fa-check-circle text-success"></i> มีในระบบแล้ว (<?php echo $bound_macs[$arp_mac]; ?>)
                                </span>
                            <?php else: ?>
                                <span class="badge badge-warning">ยังไม่ได้บันทึก</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-right">
                            <?php if(!$is_bound): ?>
                                <form method="post" style="display:inline-block;">
                                    <input type="hidden" name="action" value="add">
                                    <input type="hidden" name="mac" value="<?php echo $arp_mac; ?>">
                                    <input type="hidden" name="type" value="bypassed">
                                    <input type="hidden" name="comment" value="Auto: <?php echo $arp_ip; ?>">
                                    <button type="submit" class="btn btn-sm btn-success" title="กดเพื่อ Bypass ทันที">
                                        <i class="fas fa-bolt"></i> Bypass
                                    </button>
                                </form>

                                <form method="post" style="display:inline-block;">
                                    <input type="hidden" name="action" value="add">
                                    <input type="hidden" name="mac" value="<?php echo $arp_mac; ?>">
                                    <input type="hidden" name="type" value="blocked">
                                    <input type="hidden" name="comment" value="Auto Block: <?php echo $arp_ip; ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="กดเพื่อ Block ทันที">
                                        <i class="fas fa-ban"></i>
                                    </button>
                                </form>
                            <?php else: ?>
                                <button class="btn btn-sm btn-secondary" disabled>บันทึกแล้ว</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php 
                        $found_new = true;
                    endforeach; 
                    
                    if(!$found_new):
                    ?>
                    <tr><td colspan="5" class="text-center py-3">ไม่พบอุปกรณ์ใน ARP Table</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>