<?php
// view/header.php

// 1. โหลดค่า Settings
$json_file = 'config/settings.json';
$sys_conf = [
    'app_name' => 'MyHotspot',
    'theme'    => 'blue'
];

if (file_exists($json_file)) {
    $load_conf = json_decode(file_get_contents($json_file), true);
    if ($load_conf) {
        $sys_conf = $load_conf;
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $sys_conf['app_name']; ?> - Manager</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

    <style>
        /* --- Style: Modern Gradient (Hidden Scrollbar) --- */
        
        body {
            background-color: #f4f6f9;
        }

        .sidebar {
            /* พื้นหลังไล่สี Modern */
            background: linear-gradient(180deg, #2c3e50 0%, #000000 100%);
            box-shadow: 4px 0 15px rgba(0,0,0,0.2);
            border-right: 1px solid rgba(255,255,255,0.05);
            
            /* การจัดการ Scrollbar */
            overflow-y: auto; /* ให้เลื่อนได้ */
            max-height: 100vh; 
            padding-bottom: 50px;
            
            /* --- เทคนิคซ่อน Scrollbar แต่ยังเลื่อนได้ --- */
            -ms-overflow-style: none;  /* IE and Edge */
            scrollbar-width: none;  /* Firefox */
        }
        
        /* ซ่อน Scrollbar สำหรับ Chrome, Safari, Opera */
        .sidebar::-webkit-scrollbar {
            display: none;
        }

        .sidebar h2 {
            text-align: center; 
            padding: 25px 0; 
            margin: 0 0 10px 0;
            font-size: 24px; 
            font-weight: 800;
            /* โลโก้ไล่สี */
            background: -webkit-linear-gradient(#3498db, #2ecc71);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            letter-spacing: 1px;
        }

        /* --- สไตล์ปุ่มเมนูหลัก (Head Button) --- */
        .menu-btn {
            padding: 15px 25px;
            width: 100%;
            background: none;
            border: none;
            color: #bdc3c7;
            text-align: left;
            font-size: 13px;
            font-weight: 700;
            text-transform: uppercase;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-left: 4px solid transparent;
            outline: none;
            transition: all 0.3s;
        }

        .menu-btn:hover {
            color: #fff;
            background: rgba(255,255,255,0.05);
        }

        .menu-btn.active-group {
            color: #fff;
            background: rgba(255,255,255,0.05);
            border-left-color: #3498db;
        }

        .dropdown-icon {
            font-size: 10px;
            transition: transform 0.3s;
        }

        .menu-btn.active-group .dropdown-icon {
            transform: rotate(180deg);
        }

        /* --- กล่องเมนูย่อย (Submenu) --- */
        .submenu-container {
            display: none; /* ซ่อนไว้ก่อน */
            background: rgba(0,0,0,0.3); /* สีพื้นหลังเข้มขึ้น */
        }

        /* ลิงก์ย่อย */
        .sidebar a {
            padding: 12px 20px 12px 40px; /* ย่อหน้าเข้าไป */
            text-decoration: none;
            font-size: 14px;
            color: #95a5a6;
            display: block;
            transition: 0.2s;
            border-left: 4px solid transparent;
        }

        .sidebar a:hover {
            color: #fff;
            padding-left: 45px; /* ขยับเล็กน้อยตอนชี้ */
            background: rgba(255,255,255,0.02);
        }

        .sidebar a.active {
            color: #3498db;
            background: linear-gradient(90deg, rgba(52,152,219,0.1) 0%, rgba(0,0,0,0) 100%);
            border-left-color: #3498db;
            font-weight: 500;
        }

        .sidebar a i {
            width: 25px;
            text-align: center;
            margin-right: 5px;
        }

        /* ลิงก์เดี่ยว (Dashboard) */
        .single-link {
            padding: 15px 25px;
            color: #bdc3c7;
            font-weight: 700;
            text-transform: uppercase;
            font-size: 13px;
            display: block;
            text-decoration: none;
            border-left: 4px solid transparent;
        }
        .single-link:hover { color: #fff; background: rgba(255,255,255,0.05); }
        .single-link.active { color: #2ecc71; border-left-color: #2ecc71; background: rgba(46, 204, 113, 0.1); }

    </style>
</head>

<body>

    <div class="sidebar" id="sidebar">
        <h2><i class="fas fa-wifi"></i> <?php echo $sys_conf['app_name']; ?></h2>
        
        <?php $p = isset($_GET['page']) ? $_GET['page'] : 'dashboard'; ?>

        <a href="index.php?page=dashboard" class="single-link <?php echo ($p == 'dashboard') ? 'active' : ''; ?>">
            <i class="fas fa-chart-pie"></i> DASHBOARD
        </a>

        <button class="menu-btn">
            <span><i class="fas fa-users-cog"></i> User Management</span>
            <i class="fas fa-chevron-down dropdown-icon"></i>
        </button>
        <div class="submenu-container">
            <a href="index.php?page=list_users" class="<?php echo ($p == 'list_users') ? 'active' : ''; ?>">
                <i class="fas fa-list"></i> รายชื่อผู้ใช้
            </a>
            <a href="index.php?page=add_user" class="<?php echo ($p == 'add_user') ? 'active' : ''; ?>">
                <i class="fas fa-user-plus"></i> เพิ่ม User ใหม่
            </a>
            <a href="index.php?page=gen_users" class="<?php echo ($p == 'gen_users') ? 'active' : ''; ?>">
                <i class="fas fa-magic"></i> สร้างคูปอง (Batch)
            </a>
            <a href="index.php?page=profiles" class="<?php echo ($p == 'profiles' || $p == 'add_profile') ? 'active' : ''; ?>">
                <i class="fas fa-tags"></i> แพ็กเกจเน็ต
            </a>
            <a href="index.php?page=active_users" class="<?php echo ($p == 'active_users') ? 'active' : ''; ?>">
                <i class="fas fa-signal"></i> ออนไลน์อยู่
            </a>
            <a href="index.php?page=binding" class="<?php echo ($p == 'binding') ? 'active' : ''; ?>">
                <i class="fas fa-shield-alt"></i> บายพาส (Binding)
            </a>
            <a href="index.php?page=expire_mon" class="<?php echo ($p == 'expire_mon') ? 'active' : ''; ?>">
                <i class="fas fa-clock"></i> เช็ควันหมดอายุ
            </a>
        </div>

        <button class="menu-btn">
            <span><i class="fas fa-network-wired"></i> Network System</span>
            <i class="fas fa-chevron-down dropdown-icon"></i>
        </button>
        <div class="submenu-container">
            <a href="index.php?page=servers" class="<?php echo ($p == 'servers') ? 'active' : ''; ?>">
                <i class="fas fa-server"></i> Server Setup
            </a>
            <a href="index.php?page=server_profile" class="<?php echo ($p == 'server_profile') ? 'active' : ''; ?>">
                <i class="fas fa-cogs"></i> Server Profile
            </a>
            <a href="index.php?page=interface" class="<?php echo ($p == 'interface') ? 'active' : ''; ?>">
                <i class="fas fa-sitemap"></i> Interface
            </a>
            <a href="index.php?page=dhcp_leases" class="<?php echo ($p == 'dhcp_leases') ? 'active' : ''; ?>">
                <i class="fas fa-project-diagram"></i> DHCP Leases
            </a>
            <a href="index.php?page=hosts" class="<?php echo ($p == 'hosts') ? 'active' : ''; ?>">
                <i class="fas fa-laptop-house"></i> Hotspot Hosts
            </a>
            <a href="index.php?page=queues" class="<?php echo ($p == 'queues') ? 'active' : ''; ?>">
                <i class="fas fa-tachometer-alt"></i> Queues Monitor
            </a>
            <a href="index.php?page=dns" class="<?php echo ($p == 'dns') ? 'active' : ''; ?>">
                <i class="fas fa-globe-asia"></i> DNS Static
            </a>
            <a href="index.php?page=firewall" class="<?php echo ($p == 'firewall') ? 'active' : ''; ?>">
                <i class="fas fa-fire-alt"></i> Firewall / NAT
            </a>
            <a href="index.php?page=pool" class="<?php echo ($p == 'pool') ? 'active' : ''; ?>">
                <i class="fas fa-swimming-pool"></i> IP Pools
            </a>
        </div>

        <button class="menu-btn">
            <span><i class="fas fa-tools"></i> Admin Tools</span>
            <i class="fas fa-chevron-down dropdown-icon"></i>
        </button>
        <div class="submenu-container">
            <a href="index.php?page=walled_garden" class="<?php echo ($p == 'walled_garden') ? 'active' : ''; ?>">
                <i class="fas fa-globe"></i> เว็บยกเว้น (WG)
            </a>
            <a href="index.php?page=report" class="<?php echo ($p == 'report') ? 'active' : ''; ?>">
                <i class="fas fa-chart-line"></i> รายงานรายได้
            </a>
            <a href="index.php?page=log" class="<?php echo ($p == 'log') ? 'active' : ''; ?>">
                <i class="fas fa-history"></i> Logs
            </a>
            <a href="index.php?page=backup" class="<?php echo ($p == 'backup') ? 'active' : ''; ?>">
                <i class="fas fa-save"></i> Backup & Restore
            </a>
            <a href="index.php?page=edit_login" class="<?php echo ($p == 'edit_login') ? 'active' : ''; ?>">
                <i class="fas fa-paint-brush"></i> หน้า Login
            </a>
            <a href="index.php?page=template_editor" class="<?php echo ($p == 'template_editor') ? 'active' : ''; ?>">
                <i class="fas fa-code"></i> แก้ไขบัตรคูปอง
            </a>
            <a href="index.php?page=system" class="<?php echo ($p == 'system') ? 'active' : ''; ?>">
                <i class="fas fa-hdd"></i> System Tools
            </a>
            <a href="index.php?page=settings" class="<?php echo ($p == 'settings') ? 'active' : ''; ?>">
                <i class="fas fa-cog"></i> ตั้งค่าเว็บไซต์
            </a>
        </div>

        <a href="index.php?action=logout" style="margin-top: 30px; margin-bottom: 20px; color: #e74c3c; border-top: 1px solid rgba(255,255,255,0.1); padding: 15px 20px; display:block; text-decoration:none; text-align:center;">
            <i class="fas fa-sign-out-alt"></i> ออกจากระบบ
        </a>
    </div>

    <div class="main-content" id="main-content">
        <div style="background:white; padding:15px; border-radius:8px; margin-bottom:20px; display:flex; justify-content:space-between; align-items:center; box-shadow: 0 2px 5px rgba(0,0,0,0.05);">
            <span style="font-weight:bold; color:#333; cursor:pointer;" id="menu-toggle">
                <i class="fas fa-bars"></i> เมนู
            </span>
            <span style="font-size:14px; color:#666;">
                <i class="fas fa-server"></i> IP: <b><?php echo isset($_SESSION['router_ip']) ? $_SESSION['router_ip'] : '-'; ?></b>
            </span>
        </div>

        <script>
            // 1. Mobile Toggle
            document.getElementById('menu-toggle').addEventListener('click', function() {
                document.getElementById('sidebar').classList.toggle('toggled');
                document.getElementById('main-content').classList.toggle('toggled');
            });

            // 2. Accordion Logic
            var acc = document.getElementsByClassName("menu-btn");
            var i;
            for (i = 0; i < acc.length; i++) {
                acc[i].addEventListener("click", function() {
                    this.classList.toggle("active-group");
                    var panel = this.nextElementSibling;
                    if (panel.style.display === "block") {
                        panel.style.display = "none";
                    } else {
                        panel.style.display = "block";
                    }
                });
            }

            // 3. Auto Open Active Menu
            var activeLink = document.querySelector('.sidebar a.active');
            if(activeLink) {
                var parentPanel = activeLink.closest('.submenu-container');
                if(parentPanel) {
                    parentPanel.style.display = 'block';
                    parentPanel.previousElementSibling.classList.add('active-group');
                }
            }
        </script>