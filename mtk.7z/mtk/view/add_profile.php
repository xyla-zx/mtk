<?php
// view/add_profile.php

$price_file = 'config/prices.json';

if (isset($_POST['btn_save'])) {
    $p_name = $_POST['p_name'];
    $p_rx = $_POST['p_rx'];
    $p_tx = $_POST['p_tx'];
    $p_time = $_POST['p_time']; 
    $p_shared = $_POST['p_shared'];
    $p_price = $_POST['p_price'];

    $rate_limit = $p_tx . "/" . $p_rx;

    if ($API->connect($ip_router, $user_router, $pass_router)) {
        
        // 1. สั่ง MikroTik สร้าง Profile (เฉพาะข้อมูลเทคนิค)
        $result = $API->comm("/ip/hotspot/user/profile/add", array(
            "name"            => $p_name,
            "rate-limit"      => $rate_limit,
            "session-timeout" => $p_time,
            "shared-users"    => $p_shared
        ));

        $API->disconnect();

        // เช็ค Error
        if (isset($result['!trap'])) {
            $_SESSION['swal_icon'] = 'error';
            $_SESSION['swal_title'] = 'สร้างไม่สำเร็จ';
            $_SESSION['swal_text'] = 'Router แจ้งว่า: ' . $result['!trap'][0]['message'];
        } else {
            
            // ✅ 2. บันทึกราคาลงไฟล์ JSON ของเรา (ระบบ Data Separation)
            $prices = [];
            // โหลดข้อมูลเก่ามาก่อน (ถ้ามี)
            if (file_exists($price_file)) {
                $prices = json_decode(file_get_contents($price_file), true);
            }
            
            // เพิ่มราคาใหม่เข้าไป (Key = ชื่อแพ็กเกจ)
            $prices[$p_name] = $p_price;
            
            // เซฟกลับลงไฟล์
            file_put_contents($price_file, json_encode($prices, JSON_PRETTY_PRINT));

            $_SESSION['swal_icon'] = 'success';
            $_SESSION['swal_title'] = 'สร้างสำเร็จ';
            $_SESSION['swal_text'] = 'เพิ่มแพ็กเกจเรียบร้อย (ราคาบันทึกในระบบเว็บ)';
            header("Location: index.php?page=profiles");
            exit;
        }

    } else {
        $_SESSION['swal_icon'] = 'error';
        $_SESSION['swal_title'] = 'เชื่อมต่อไม่ได้';
    }
}
?>

<div class="card">
    <div class="card-header">
        <h3><i class="fas fa-plus-circle"></i> สร้างแพ็กเกจใหม่ (Add Profile)</h3>
    </div>
    
    <div class="card-body">
        <form method="post">
            
            <div class="form-group">
                <label>ชื่อแพ็กเกจ (Name):</label>
                <input type="text" name="p_name" class="form-control" placeholder="เช่น 1Hour-10Baht" required>
            </div>

            <div style="display:flex; gap:15px;">
                <div class="form-group" style="flex:1;">
                    <label>ความเร็ว Download:</label>
                    <select name="p_rx" class="form-control">
                        <option value="1M">1 Mbps</option>
                        <option value="5M">5 Mbps</option>
                        <option value="10M" selected>10 Mbps</option>
                        <option value="20M">20 Mbps</option>
                        <option value="50M">50 Mbps</option>
                        <option value="100M">100 Mbps</option>
                    </select>
                </div>
                <div class="form-group" style="flex:1;">
                    <label>ความเร็ว Upload:</label>
                    <select name="p_tx" class="form-control">
                        <option value="1M">1 Mbps</option>
                        <option value="2M">2 Mbps</option>
                        <option value="5M" selected>5 Mbps</option>
                        <option value="10M">10 Mbps</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label>จำกัดเวลาใช้งาน (Session Timeout):</label>
                <input type="text" name="p_time" class="form-control" placeholder="เช่น 1h, 1d" required>
            </div>

            <div class="form-group">
                <label>ราคา (บาท):</label>
                <input type="number" name="p_price" class="form-control" placeholder="เช่น 10" required>
            </div>

            <div class="form-group">
                <label>Shared Users:</label>
                <input type="number" name="p_shared" class="form-control" value="1" min="1">
            </div>

            <hr>
            <button type="submit" name="btn_save" class="btn btn-primary">บันทึก</button>
            <a href="index.php?page=profiles" class="btn" style="background:#ccc; color:#333; text-decoration:none;">ยกเลิก</a>
        </form>
    </div>
</div>