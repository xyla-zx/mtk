<?php
// get/get_system_health.php
session_start();
header('Content-Type: application/json');
require_once('../core/routeros_api.class.php');

// ฟังก์ชันแปลงหน่วย Byte
function formatBytes($bytes, $precision = 2) { 
    $units = array('B', 'KB', 'MB', 'GB', 'TB'); 
    $bytes = max($bytes, 0); 
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024)); 
    $pow = min($pow, count($units) - 1); 
    $bytes /= pow(1024, $pow); 
    return round($bytes, $precision) . ' ' . $units[$pow]; 
}

$response = ['status' => 'error'];

if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    
    $API = new RouterosAPI();
    $API->debug = false;

    if ($API->connect($_SESSION['router_ip'], $_SESSION['router_user'], $_SESSION['router_pass'])) {
        
        // 1. ดึง Resource
        $res = $API->comm("/system/resource/print");
        // 2. ดึง Identity
        $ident = $API->comm("/system/identity/print");
        
        $API->disconnect();

        if (isset($res[0])) {
            $r = $res[0];
            $response['status'] = 'success';
            
            // ข้อมูลทั่วไป
            $response['uptime'] = isset($r['uptime']) ? $r['uptime'] : '-';
            $response['identity'] = isset($ident[0]['name']) ? $ident[0]['name'] : 'MikroTik';
            $response['board_name'] = isset($r['board-name']) ? $r['board-name'] : '-';
            $response['version'] = isset($r['version']) ? $r['version'] : '-';
            $response['arch'] = isset($r['architecture-name']) ? $r['architecture-name'] : '-';
            
            // CPU
            $response['cpu_load'] = isset($r['cpu-load']) ? $r['cpu-load'] : 0;
            $response['cpu_info'] = (isset($r['cpu']) ? $r['cpu'] : '-') . " (" . (isset($r['cpu-count']) ? $r['cpu-count'] : '1') . " Core) @ " . (isset($r['cpu-frequency']) ? $r['cpu-frequency'] : '-') . " MHz";

            // RAM
            $total_mem = isset($r['total-memory']) ? $r['total-memory'] : 1;
            $free_mem = isset($r['free-memory']) ? $r['free-memory'] : 0;
            $used_mem = $total_mem - $free_mem;
            $response['mem_percent'] = round(($used_mem / $total_mem) * 100, 1);
            $response['mem_text'] = formatBytes($used_mem) . " / " . formatBytes($total_mem);

            // HDD
            $total_hdd = isset($r['total-hdd-space']) ? $r['total-hdd-space'] : 1;
            $free_hdd = isset($r['free-hdd-space']) ? $r['free-hdd-space'] : 0;
            $used_hdd = $total_hdd - $free_hdd;
            $response['hdd_percent'] = round(($used_hdd / $total_hdd) * 100, 1);
            $response['hdd_text'] = formatBytes($used_hdd) . " / " . formatBytes($total_hdd);
        }
    }
}

echo json_encode($response);
?>