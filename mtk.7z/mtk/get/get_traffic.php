<?php
// get/get_traffic.php
session_start();
header('Content-Type: application/json');
require_once('../core/routeros_api.class.php');

// ⚠️ สำคัญ: แก้ชื่อ Interface ให้ตรงกับของแชมป์ (เช่น ether1, pppoe-out1, หรือ bridge)
// ส่วนใหญ่ถ้าเสียบสายแลนเข้าช่อง 1 จะเป็น ether1 ครับ
$interface = "ether1"; 

$data = array('rx' => 0, 'tx' => 0);

if (isset($_SESSION['logged_in'])) {
    $API = new RouterosAPI();
    $API->debug = false;
    
    if ($API->connect($_SESSION['router_ip'], $_SESSION['router_user'], $_SESSION['router_pass'])) {
        // สั่ง Monitor Traffic แบบครั้งเดียว (once) เพื่อดูความเร็ว ณ ปัจจุบัน
        $result = $API->comm("/interface/monitor-traffic", array(
            "interface" => $interface,
            "once" => ""
        ));
        
        $API->disconnect();

        if (isset($result[0])) {
            // ได้ค่ามาเป็น bits/sec
            $data['rx'] = (int) $result[0]['rx-bits-per-second'];
            $data['tx'] = (int) $result[0]['tx-bits-per-second'];
        }
    }
}

echo json_encode($data);
?>