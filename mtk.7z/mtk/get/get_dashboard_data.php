<?php
// get/get_dashboard_data.php
session_start();
header('Content-Type: application/json'); // บอก Browser ว่านี่คือข้อมูล JSON นะ ไม่ใช่หน้าเว็บ

require_once('../core/routeros_api.class.php');

$response = array(
    'status' => 'error',
    'cpu' => '0',
    'uptime' => '-',
    'active' => '0',
    'users' => '0',
    'model' => '-'
);

// ตรวจสอบว่า Login หรือยัง
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    
    $API = new RouterosAPI();
    $API->debug = false;

    // เชื่อมต่อโดยใช้ Session ที่เก็บไว้ตอน Login
    if ($API->connect($_SESSION['router_ip'], $_SESSION['router_user'], $_SESSION['router_pass'])) {
        
        // 1. ดึง Resource (CPU, Uptime, Model)
        $res = $API->comm("/system/resource/print");
        
        // 2. ดึง Active Hotspot
        $act = $API->comm("/ip/hotspot/active/print", array("count-only" => ""));
        
        // 3. ดึง Total Users
        $usr = $API->comm("/ip/hotspot/user/print", array("count-only" => ""));

        $API->disconnect();

        // จัดรูปแบบข้อมูลส่งกลับ
        if (isset($res[0])) {
            $response['status'] = 'success';
            $response['cpu']    = $res[0]['cpu-load'];
            $response['uptime'] = $res[0]['uptime'];
            $response['model']  = $res[0]['board-name'];
            $response['active'] = $act;
            $response['users']  = $usr;
        }
    }
}

// ส่งค่าออกมาเป็น JSON string
echo json_encode($response);
?>