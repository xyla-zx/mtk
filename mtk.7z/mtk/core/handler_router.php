<?php
// core/handler_router.php
session_start();
require_once '../config/database.php';

if (isset($_POST['action']) && $_POST['action'] == 'select_router') {
    $r_id = $_POST['router_id'];
    
    // ดึงข้อมูล Router จาก DB
    $stmt = $pdo->prepare("SELECT * FROM tb_routers WHERE router_id = :id");
    $stmt->execute(['id' => $r_id]);
    $router = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($router) {
        // ยัดลง Session เพื่อให้โค้ดเก่า (dashboard.php, etc.) ทำงานต่อได้เลย!
        $_SESSION['router_ip']   = $router['ip_address'];
        $_SESSION['router_user'] = $router['api_user'];
        $_SESSION['router_pass'] = $router['api_pass']; // ถ้าเข้ารหัสต้องถอดรหัสก่อน
        $_SESSION['router_name'] = $router['router_name'];
        $_SESSION['router_port'] = $router['api_port'];

        // ส่งเข้าหน้า Dashboard
        header("Location: ../index.php?page=dashboard");
        exit;
    } else {
        echo "Router Not Found";
    }
}
?>