<?php
// view/print_voucher.php
session_start();

if (!isset($_SESSION['print_data']) || count($_SESSION['print_data']) == 0) {
    die("ไม่มีข้อมูลสำหรับพิมพ์ กรุณาสร้างคูปองก่อน");
}

$users = $_SESSION['print_data'];

// 1. โหลด Template
$template_path = 'templates/thermal_blue.html';
$template_content = "ไม่พบไฟล์ Template";
if(file_exists($template_path)){
    $template_content = file_get_contents($template_path);
}

// 2. โหลดราคาจาก JSON
$price_file = 'config/prices.json';
$local_prices = [];
if (file_exists($price_file)) {
    $local_prices = json_decode(file_get_contents($price_file), true);
}

// 3. กำหนด DNS Name หรือ IP ของ Hotspot (สำคัญ!)
// ถ้าแชมป์ตั้ง DNS Name ใน MikroTik ไว้ (เช่น login.net) ให้แก้ตรงนี้
// ถ้าไม่ได้ตั้ง ให้ใช้ IP Router ได้เลย
$hotspot_dns = isset($_SESSION['router_ip']) ? $_SESSION['router_ip'] : '192.168.88.1'; 

?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>Print Voucher</title>
    <style>
        body { margin: 0; padding: 10px; background: #ccc; font-family: sans-serif; }
        .sheet {
            background: white;
            width: 80mm; 
            min-height: 100vh;
            margin: 0 auto;
            padding: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.2);
        }
        @media print {
            body { background: none; padding: 0; }
            .sheet { width: 100%; box-shadow: none; margin: 0; padding: 0; }
            .no-print { display: none; }
            @page { margin: 0; size: auto; }
        }
        .btn { padding: 10px 20px; background: #2980b9; color: white; border: none; cursor: pointer; border-radius: 4px; }
        
        /* จัด Canvas ให้อยู่กึ่งกลาง */
        canvas { display: block; margin: 0 auto; }
    </style>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrious/4.0.2/qrious.min.js"></script>
</head>
<body>

    <div class="no-print" style="text-align:center; margin-bottom:10px;">
        <button onclick="window.print()" class="btn">🖨️ สั่งพิมพ์ (Print)</button>
    </div>

    <div class="sheet">
        <?php 
        $i = 0;
        foreach($users as $u) {
            $i++;
            // หาค่าราคา
            $price = isset($u['price']) ? $u['price'] : '-';
            if(($price == '-' || $price == '?') && isset($local_prices[$u['profile']])) {
                $price = $local_prices[$u['profile']] . ' บาท';
            }

            // --- สร้าง Login URL สำหรับ QR Code ---
            // รูปแบบ: http://DNS/login?username=user&password=pass
            $login_url = "http://{$hotspot_dns}/login?username={$u['user']}&password={$u['pass']}";

            // สร้าง Tag Canvas รอไว้ (ให้ JS มาวาด)
            // ใช้ class="qr-render" และฝัง url ไว้ใน data-value
            $qr_tag = '<canvas class="qr-render" data-value="'.$login_url.'" width="100" height="100"></canvas>';

            // แทนค่าลง Template
            $search = ['{{user}}', '{{pass}}', '{{profile}}', '{{price}}', '{{qrcode}}'];
            $replace = [$u['user'], $u['pass'], $u['profile'], $price, $qr_tag];

            echo str_replace($search, $replace, $template_content);
            
            echo '<div style="border-bottom: 1px dotted #ccc; margin: 10px 0;"></div>';
        } 
        ?>
        
        <div style="text-align:center; font-size:10px; margin-top:20px;">
            --- End of Batch ---
        </div>
    </div>

    <script>
        // วนลูปหา canvas ทุกตัวที่มี class "qr-render"
        var qrs = document.querySelectorAll('.qr-render');
        qrs.forEach(function(canvas) {
            var url = canvas.getAttribute('data-value');
            new QRious({
                element: canvas,
                value: url,
                size: 120, // ขนาด QR Code
                level: 'M' // ระดับความชัด (L, M, Q, H)
            });
        });
    </script>

</body>
</html>