<?php
/**
 * Handler: Firewall Management
 * หน้าที่: รับค่าจาก Form เพื่อ Add, Remove, Enable, Disable, Move Filter Rules
 */
session_start();
require_once('../core/routeros_api.class.php');
require_once('../config/connect.php');

// ตรวจสอบสิทธิ์การเข้าถึง
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: ../index.php");
    exit;
}

$API = new RouterosAPI();
$API->debug = false;

if ($API->connect($ip_router, $user_router, $pass_router)) {
    
    $action = isset($_POST['action']) ? $_POST['action'] : '';
    $id = isset($_POST['id']) ? $_POST['id'] : '';

    try {
        // --- 1. Add Rule (เพิ่มกฎ) ---
        if ($action == 'add_rule') {
            $cmd = array(
                "chain"     => $_POST['chain'],
                "action"    => $_POST['action_type'],
                "comment"   => $_POST['comment']
            );
            
            // Optional Fields
            if(!empty($_POST['protocol'])) $cmd['protocol'] = $_POST['protocol'];
            if(!empty($_POST['dst_port'])) $cmd['dst-port'] = $_POST['dst_port'];
            if(!empty($_POST['src_address'])) $cmd['src-address'] = $_POST['src_address'];

            $API->comm("/ip/firewall/filter/add", $cmd);
            
            $_SESSION['swal_icon'] = "success";
            $_SESSION['swal_title'] = "เพิ่มกฎสำเร็จ";
        }

        // --- 2. Delete Rule (ลบกฎ) ---
        elseif ($action == 'delete_rule') {
            $API->comm("/ip/firewall/filter/remove", array(".id" => $id));
            $_SESSION['swal_icon'] = "success";
            $_SESSION['swal_title'] = "ลบรายการเรียบร้อย";
        }

        // --- 3. Enable/Disable (เปิด/ปิดกฎ) ---
        elseif ($action == 'toggle_rule') {
            $status = $_POST['current_status']; // true=disabled, false=enabled
            $cmd_type = ($status == 'true') ? 'enable' : 'disable'; // สลับค่ากัน
            
            $API->comm("/ip/firewall/filter/" . $cmd_type, array(".id" => $id));
            
            // ไม่ต้องแจ้งเตือนใหญ่ แค่รีเฟรชหน้า
        }

        // --- 4. Move Rule (ย้ายลำดับ) ---
        elseif ($action == 'move_rule') {
            // การย้ายใน MikroTik API ใช้ command /move พร้อม id ปลายทาง
            // แต่เพื่อความง่ายใน PHP มักใช้การ Drag & Drop (ซึ่งซับซ้อน)
            // ในที่นี้ขอทำเป็น Move to Top/Bottom ง่ายๆ ก่อน หรือรับค่าลำดับถ้าต้องการ
            // (ฟีเจอร์นี้ต้องใช้ Logic ซับซ้อนถ้าจะเลื่อนทีละขั้น ขอละไว้ก่อนเพื่อความเสถียรครับ)
        }

    } catch (Exception $e) {
        $_SESSION['swal_icon'] = "error";
        $_SESSION['swal_title'] = "เกิดข้อผิดพลาด";
        $_SESSION['swal_text'] = $e->getMessage();
    }

    $API->disconnect();
} else {
    $_SESSION['swal_icon'] = "error";
    $_SESSION['swal_title'] = "Connection Failed";
}

header("Location: ../index.php?page=firewall");
exit;
?>